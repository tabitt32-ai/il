import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, MessageSquare, Bell, ChefHat, X, 
  ExternalLink, Volume2, VolumeX, Sparkles, Clock, AlertTriangle
} from 'lucide-react';
import { AppNotification } from '../types';

interface NotificationToasterProps {
  notifications: AppNotification[];
  onDismiss: (id: string) => void;
  onActionClick?: (notification: AppNotification) => void;
  isSoundEnabled?: boolean;
  onToggleSound?: () => void;
}

// Synthesize gentle acoustic chimes natively using Web Audio API (no external asset needed)
export function playAlertChime(type: AppNotification['type'] = 'order_confirmed') {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Check state and resume if suspended
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const now = ctx.currentTime;

    if (type === 'whatsapp_sent') {
      // Crisp 2-tone pop for WhatsApp
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.12); // G5
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === 'new_order' || type === 'order_confirmed') {
      // Warm welcoming 3-tone harmonic chime
      const freqs = [440, 554.37, 659.25]; // A4, C#5, E5
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const startTime = now + idx * 0.08;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);
        gain.gain.setValueAtTime(0.12, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.4);
      });
    } else {
      // Subtle single tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch {
    // Gracefully handle any browser audio policies without error
  }
}

export default function NotificationToaster({
  notifications,
  onDismiss,
  onActionClick,
  isSoundEnabled = true,
  onToggleSound
}: NotificationToasterProps) {
  // Auto dismiss after 6 seconds
  useEffect(() => {
    if (notifications.length === 0) return;
    const latest = notifications[notifications.length - 1];
    const timer = setTimeout(() => {
      onDismiss(latest.id);
    }, 6000);
    return () => clearTimeout(timer);
  }, [notifications, onDismiss]);

  const getNotificationIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'order_confirmed':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />;
      case 'whatsapp_sent':
        return <MessageSquare className="w-5 h-5 text-emerald-400 shrink-0" />;
      case 'new_order':
        return <Bell className="w-5 h-5 text-amber-400 shrink-0 animate-bounce" />;
      case 'status_updated':
        return <ChefHat className="w-5 h-5 text-orange-400 shrink-0" />;
      default:
        return <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />;
    }
  };

  const getBorderColor = (type: AppNotification['type']) => {
    switch (type) {
      case 'order_confirmed':
        return 'border-emerald-500/40 shadow-[0_0_25px_-5px_rgba(16,185,129,0.3)]';
      case 'whatsapp_sent':
        return 'border-emerald-500/40 shadow-[0_0_25px_-5px_rgba(16,185,129,0.3)]';
      case 'new_order':
        return 'border-amber-500/50 shadow-[0_0_30px_-5px_rgba(245,158,11,0.35)]';
      default:
        return 'border-amber-500/30 shadow-[0_0_20px_-5px_rgba(217,119,6,0.25)]';
    }
  };

  if (notifications.length === 0) return null;

  return (
    <div 
      dir="rtl"
      className="fixed bottom-6 left-4 sm:left-6 z-50 flex flex-col-reverse gap-3 max-w-sm sm:max-w-md w-full pointer-events-none"
    >
      <AnimatePresence>
        {notifications.map((item) => (
          <motion.div
            key={item.id}
            layout
            initial={{ opacity: 0, y: 30, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
            className={`pointer-events-auto bg-[#140E0A]/95 backdrop-blur-md border ${getBorderColor(
              item.type
            )} rounded-2xl p-4 text-stone-100 shadow-2xl relative overflow-hidden transition-all`}
          >
            {/* Animated accent top bar */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-emerald-500 to-orange-500 animate-[pulse_3s_infinite]" />

            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1">
                <div className="p-2 rounded-xl bg-stone-900/80 border border-stone-800">
                  {getNotificationIcon(item.type)}
                </div>

                <div className="flex-1 text-right">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-xs sm:text-sm text-stone-100 font-serif">
                      {item.title}
                    </h4>
                    {item.orderId && (
                      <span className="text-[10px] bg-amber-950/60 text-amber-300 font-mono px-1.5 py-0.5 rounded border border-amber-500/30">
                        #{item.orderId.slice(-6)}
                      </span>
                    )}
                  </div>

                  <p className="text-stone-300 text-xs mt-1 leading-relaxed">
                    {item.message}
                  </p>

                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-stone-800/80">
                    <div className="flex items-center gap-1.5 text-[10px] text-stone-400 font-sans">
                      <Clock className="w-3 h-3 text-stone-500" />
                      <span>{item.timestamp}</span>
                    </div>

                    {item.actionLabel && onActionClick && (
                      <button
                        onClick={() => onActionClick(item)}
                        className="inline-flex items-center gap-1 text-xs font-bold text-amber-400 hover:text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 px-2.5 py-1 rounded-lg border border-amber-500/30 transition-colors cursor-pointer"
                      >
                        <span>{item.actionLabel}</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Close button */}
              <button
                onClick={() => onDismiss(item.id)}
                className="text-stone-400 hover:text-stone-100 p-1 hover:bg-stone-800/50 rounded-lg transition-colors cursor-pointer"
                title="إغلاق التنبيه"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Sound toggle hint if provided */}
            {onToggleSound && (
              <div className="absolute top-2 left-2">
                <button
                  onClick={onToggleSound}
                  className="text-stone-500 hover:text-stone-300 p-1 rounded transition-colors"
                  title={isSoundEnabled ? 'كتم صوت التنبيهات' : 'تفعيل صوت التنبيهات'}
                >
                  {isSoundEnabled ? (
                    <Volume2 className="w-3.5 h-3.5 text-stone-400" />
                  ) : (
                    <VolumeX className="w-3.5 h-3.5 text-stone-600" />
                  )}
                </button>
              </div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
