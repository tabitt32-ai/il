import React, { useState, useEffect } from 'react';
import { X, Trash2, MapPin, Truck, ShoppingBag, CreditCard, Landmark, DollarSign, CheckCircle, ArrowRight, Upload, Copy, Check, Sparkles, AlertCircle, MessageSquare } from 'lucide-react';
import { CartItem, OrderDetails, PaymentMethod, DeliveryMethod, SiteSettings, AppNotification } from '../types';
import { MOROCCAN_CITIES } from '../data';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onAddOrder: (order: OrderDetails) => void;
  siteSettings?: SiteSettings;
  onNotify?: (notification: AppNotification) => void;
}

export default function CheckoutModal({ 
  isOpen, 
  onClose, 
  cart, 
  onRemoveItem, 
  onClearCart, 
  onAddOrder,
  siteSettings,
  onNotify 
}: CheckoutModalProps) {
  const [step, setStep] = useState<1 | 2>(1); // Step 1: Cart & Delivery, Step 2: Payment
  const [isCompleted, setIsCompleted] = useState(false);
  const [lastOrder, setLastOrder] = useState<OrderDetails | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('0717301089');
  const [address, setAddress] = useState('الشارع محمد الخامس إبن جرير');
  const [cityId, setCityId] = useState('benguerir');
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>('delivery');

  // Determine available payment methods based on siteSettings
  const isCodAvailable = siteSettings?.codEnabled !== false;
  const isCardAvailable = siteSettings?.cardEnabled !== false;
  const isTransferAvailable = siteSettings?.transferEnabled !== false;

  const defaultPayment: PaymentMethod = isCodAvailable ? 'cod' : isTransferAvailable ? 'transfer' : 'card';
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(defaultPayment);

  useEffect(() => {
    // If selected payment becomes disabled, switch to available
    if (paymentMethod === 'cod' && !isCodAvailable) {
      setPaymentMethod(isTransferAvailable ? 'transfer' : 'card');
    } else if (paymentMethod === 'transfer' && !isTransferAvailable) {
      setPaymentMethod(isCodAvailable ? 'cod' : 'card');
    } else if (paymentMethod === 'card' && !isCardAvailable) {
      setPaymentMethod(isCodAvailable ? 'cod' : 'transfer');
    }
  }, [isCodAvailable, isCardAvailable, isTransferAvailable, paymentMethod]);

  // Credit Card Fields
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardName, setCardName] = useState('');

  // Bank Transfer Fields
  const [transferRef, setTransferRef] = useState('');
  const [transferReceipt, setTransferReceipt] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(false);
  const [copiedRib, setCopiedRib] = useState(false);

  // Subtotals
  const [subtotal, setSubtotal] = useState(0);
  const [deliveryFee, setDeliveryFee] = useState(0);
  const [total, setTotal] = useState(0);

  // Bank Info from settings or fallback
  const bankName = siteSettings?.bankName || 'CIH BANK';
  const bankBeneficiary = siteSettings?.bankBeneficiary || 'ش.م.م شواء الأطلس الأصيل';
  const bankRib = siteSettings?.bankRib || '230 201 4244758211030701 95';
  const cleanRib = bankRib.replace(/\s+/g, '');

  useEffect(() => {
    const sub = cart.reduce((sum, item) => sum + item.totalPrice, 0);
    setSubtotal(sub);

    const selectedCity = MOROCCAN_CITIES.find(c => c.id === cityId);
    const fee = deliveryMethod === 'delivery' && selectedCity ? selectedCity.fee : 0;
    setDeliveryFee(fee);

    setTotal(sub + fee);
  }, [cart, cityId, deliveryMethod]);

  if (!isOpen) return null;

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || (deliveryMethod === 'delivery' && !address)) {
      alert('المرجو ملء جميع البيانات الأساسية لمتابعة الدفع.');
      return;
    }
    setStep(2);
  };

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (paymentMethod === 'card') {
      if (!cardNumber || !cardExpiry || !cardCvv || !cardName) {
        alert('المرجو تعبئة بيانات البطاقة البنكية بالكامل.');
        return;
      }
    }

    const selectedCity = MOROCCAN_CITIES.find(c => c.id === cityId);

    const order: OrderDetails = {
      id: `shw_${Date.now()}`,
      customerName: name,
      customerPhone: phone,
      customerAddress: deliveryMethod === 'delivery' ? address : 'استلام من المحل',
      city: deliveryMethod === 'delivery' && selectedCity ? selectedCity.name : 'استلام من المحل',
      deliveryMethod,
      paymentMethod,
      transferRef: paymentMethod === 'transfer' ? (transferRef || '') : '',
      notes: '',
      cartItems: [...cart],
      subtotal,
      deliveryFee,
      total,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    onAddOrder(order);
    setLastOrder(order);
    setIsCompleted(true);
    onClearCart();

    if (onNotify) {
      onNotify({
        id: `notif_${Date.now()}`,
        type: 'order_confirmed',
        title: 'تم تأكيد طلبك بنجاح! 🍖',
        message: `تم تسجيل الطلب #${order.id.slice(-6)} بمبلغ ${order.total} د.م. بنجاح في النظام.`,
        timestamp: 'الآن',
        orderId: order.id,
        customerName: order.customerName,
        actionLabel: 'تأكيد عبر واتساب',
        actionType: 'open_whatsapp'
      });
    }
  };

  const handleWhatsAppSend = () => {
    if (!lastOrder) return;

    let itemsStr = '';
    lastOrder.cartItems.forEach((item, index) => {
      itemsStr += `*${index + 1}. ${item.name}*\n` +
                 `   الكمية: ${item.quantityKg ? item.quantityKg + ' كجم' : item.quantityItem + ' حبة'}\n` +
                 (item.cookingPreference ? `   الطهي: ${item.cookingPreference}\n` : '') +
                 (item.seasoningPreference && item.seasoningPreference.length > 0 ? `   البهارات: ${item.seasoningPreference.join(', ')}\n` : '');
      
      if (item.sides && item.sides.length > 0) {
        itemsStr += `   المقبلات:\n`;
        item.sides.forEach(s => {
          itemsStr += `    - ${s.side.name} (عدد: ${s.quantity})\n`;
        });
      }
      itemsStr += `   السعر: ${item.totalPrice} د.م.\n\n`;
    });

    const text = `السلام عليكم، لقد قمت بتقديم طلب شواء عبر الموقع:\n\n` +
                 `*رقم الطلب:* ${lastOrder.id}\n` +
                 `*الزبون:* ${lastOrder.customerName}\n` +
                 `*الهاتف:* ${lastOrder.customerPhone}\n` +
                 `*طريقة الاستلام:* ${lastOrder.deliveryMethod === 'delivery' ? 'توصيل للمنزل' : 'استلام من المحل'}\n` +
                 (lastOrder.deliveryMethod === 'delivery' ? `*العنوان:* ${lastOrder.customerAddress} - ${lastOrder.city}\n` : '') +
                 `*طريقة الدفع:* ${
                   lastOrder.paymentMethod === 'cod' ? 'الدفع نقداً عند الاستلام' :
                   lastOrder.paymentMethod === 'card' ? 'بطاقة بنكية (تم الدفع)' : `تحويل بنكي (${bankName})`
                 }\n` +
                 (lastOrder.transferRef ? `*رقم مرجع التحويل:* ${lastOrder.transferRef}\n` : '') +
                 `\n*تفاصيل الطلب:*\n${itemsStr}` +
                 `---------------------------\n` +
                 `*المجموع الفرعي:* ${lastOrder.subtotal} د.م.\n` +
                 `*رسوم التوصيل:* ${lastOrder.deliveryFee} د.م.\n` +
                 `*المجموع الإجمالي:* *${lastOrder.total} درهم مغربي*\n\n` +
                 `المرجو مراجعة الطلب وتأكيده للبدء في الشواء فوراً. شكراً لكم!`;

    const encodedText = encodeURIComponent(text);
    const targetPhone = (siteSettings?.whatsappPhone || '212717301089').replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${targetPhone}?text=${encodedText}`, '_blank');

    if (onNotify) {
      onNotify({
        id: `notif_${Date.now()}`,
        type: 'whatsapp_sent',
        title: 'تم فتح محادثة الواتساب 📱',
        message: 'تم إعداد كافة تفاصيل طلبك وعنوان التوصيل. يرجى الضغط على "إرسال" داخل واتساب لتفادي أي ضياع للطلب.',
        timestamp: 'الآن',
        orderId: lastOrder.id,
        actionLabel: 'إعادة فتح المحادثة',
        actionType: 'open_whatsapp'
      });
    }
  };

  const handleFileUploadMock = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadProgress(true);
      setTransferReceipt(e.target.files[0]);
      setTimeout(() => {
        setUploadProgress(false);
      }, 1500);
    }
  };

  const selectedCityInfo = MOROCCAN_CITIES.find(c => c.id === cityId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in font-sans">
      <div className="bg-[#0B0806] border border-[#2D1B12] rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl relative">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#2D1B12]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-amber-500" />
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-stone-100">
              {isCompleted ? 'تم تأكيد طلبك بنجاح' : 'سلة التسوق وإتمام الطلب'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white rounded-full hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
          
          {isCompleted && lastOrder ? (
            /* Thank You / Confirmation Screen */
            <div className="text-center py-8 max-w-lg mx-auto animate-fade-in">
              <div className="w-20 h-20 bg-emerald-950/40 border border-emerald-500 rounded-full flex items-center justify-center text-emerald-400 mx-auto mb-6">
                <CheckCircle className="w-10 h-10" />
              </div>
              <h3 className="font-serif text-3xl font-bold text-stone-100 mb-2">
                بارك الله فيكم، تم استلام طلبكم!
              </h3>
              <p className="text-stone-300 text-sm mb-6 leading-relaxed">
                رقم الطلب الخاص بكم هو <span className="text-amber-400 font-mono font-bold">#{lastOrder.id.slice(-6)}</span>. تم حفظ الطلب بقاعدة البيانات وجاري تحضيره في الفرن البلدي.
              </p>

              {lastOrder.paymentMethod === 'transfer' && (
                <div className="bg-[#140E0A] border border-[#2D1B12] p-4 rounded-2xl mb-6 text-right text-xs text-stone-300">
                  <span className="text-amber-500 font-bold block mb-1">تعليمات التحويل البنكي:</span>
                  <p>المرجو إتمام التحويل إلى حسابنا في <b className="text-white">{bankName}</b>:</p>
                  <p className="font-mono text-amber-400 font-bold mt-1 text-center bg-stone-900 p-2 rounded tracking-wider select-all">
                    {bankRib}
                  </p>
                  <p className="text-[11px] text-stone-400 mt-2 text-center">
                    المستفيد: {bankBeneficiary}
                  </p>
                </div>
              )}

              <div className="bg-[#140E0A] border border-[#2D1B12] p-5 rounded-2xl mb-8 text-right text-xs text-stone-300 space-y-2">
                <div className="flex justify-between">
                  <span className="text-stone-400">الاسم:</span>
                  <span className="font-bold text-stone-100">{lastOrder.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">الهاتف:</span>
                  <span className="font-bold text-stone-100 font-mono">{lastOrder.customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">العنوان:</span>
                  <span className="font-bold text-stone-100">{lastOrder.customerAddress} ({lastOrder.city})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">طريقة الدفع:</span>
                  <span className="font-bold text-amber-400">
                    {lastOrder.paymentMethod === 'cod' ? 'نقداً عند الاستلام' : lastOrder.paymentMethod === 'card' ? 'بطاقة بنكية' : `تحويل بنكي (${bankName})`}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-stone-850 font-bold text-sm">
                  <span className="text-stone-200">المجموع الكلي:</span>
                  <span className="text-amber-400 font-sans text-base">{lastOrder.total} د.م.</span>
                </div>
              </div>

              {/* Visual Prevention Alert Banner */}
              <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-4 mb-6 text-right flex items-start gap-3">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0 mt-0.5">
                  <AlertCircle className="w-5 h-5 text-amber-400 animate-pulse" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-bold text-amber-300">
                    تنبيه هام لمنع تأخر أو ضياع الطلب:
                  </h4>
                  <p className="text-[11px] text-amber-100/80 mt-1 leading-relaxed">
                    يرجى الضغط على الزر الأخضر أدناه لإرسال تفاصيل الوجبات وعنوانك مباشرة لمعلم الشواء عبر الواتساب لتأكيد موعد خروج الطلب من الفرن البلدي فوراً.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => {
                    window.dispatchEvent(new CustomEvent('open_live_chat', {
                      detail: {
                        orderId: lastOrder.id,
                        customerName: lastOrder.customerName,
                        customerPhone: lastOrder.customerPhone
                      }
                    }));
                  }}
                  className="flex-1 py-3.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-stone-950 font-bold rounded-xl shadow-lg transition-all text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>دردشة مباشرة مع المشرف بخصوص طلبي 💬</span>
                </button>
                <button
                  onClick={handleWhatsAppSend}
                  className="flex-1 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-teal-600 hover:to-emerald-600 text-white font-bold rounded-xl shadow-lg transition-all text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>تأكيد الطلب عبر الواتساب فوراً</span>
                </button>
                <button
                  onClick={onClose}
                  className="py-3.5 px-6 bg-stone-900 hover:bg-stone-850 text-stone-300 rounded-xl text-xs font-bold transition-all border border-stone-800 cursor-pointer"
                >
                  إغلاق ومتابعة التصفح
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Panel: Items List & Customer Info Form */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* 1. Cart Items Review */}
                <div className="bg-[#140E0A] p-5 rounded-2xl border border-[#2D1B12]">
                  <div className="flex items-center justify-between mb-4 pb-2 border-b border-stone-850">
                    <h3 className="text-stone-100 font-serif font-bold text-sm">الأطباق المختارة بالسلة</h3>
                    <span className="text-xs text-stone-400">{cart.length} وجبات/طلبات</span>
                  </div>

                  {cart.length === 0 ? (
                    <div className="text-center py-6 text-stone-400 text-xs">
                      سلتك فارغة حالياً. أضف الشواء أو الأطباق المفضلة أولاً.
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-48 overflow-y-auto pr-1">
                      {cart.map((item) => (
                        <div key={item.id} className="flex items-start justify-between bg-[#18110D] p-3 rounded-xl border border-stone-850 text-xs">
                          <div>
                            <div className="font-bold text-stone-100 text-sm flex items-center gap-2">
                              <span>{item.name}</span>
                              {item.quantityKg && (
                                <span className="text-[11px] bg-amber-950/40 text-amber-400 px-2 py-0.5 rounded font-mono">
                                  {item.quantityKg} كجم
                                </span>
                              )}
                            </div>
                            
                            {item.cookingPreference && (
                              <p className="text-[11px] text-stone-400 mt-1">الطهي: {item.cookingPreference}</p>
                            )}
                            
                            {item.sides && item.sides.length > 0 && (
                              <div className="text-[10px] text-stone-400 mt-1">
                                إضافات: {item.sides.map(s => `${s.side.name} (${s.quantity})`).join(', ')}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-bold text-amber-400 font-sans text-sm">{item.totalPrice} د.م.</span>
                            <button
                              onClick={() => onRemoveItem(item.id)}
                              className="text-stone-500 hover:text-red-400 p-1 transition-colors cursor-pointer"
                              title="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* 2. Customer & Address Form */}
                {cart.length > 0 && (
                  <form onSubmit={handleNextStep} className="bg-[#140E0A] p-5 rounded-2xl border border-[#2D1B12] space-y-4">
                    <h3 className="text-stone-100 font-serif font-bold text-sm border-b border-stone-850 pb-2">
                      بيانات التوصيل والتواصل
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-stone-300 text-xs block mb-1 font-bold">الاسم الكامل *</label>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="الاسم واللقب"
                          className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-stone-300 text-xs block mb-1 font-bold">رقم الهاتف للاتصال والواتساب *</label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="06 XX XX XX XX"
                          className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none font-mono"
                        />
                      </div>
                    </div>

                    {/* Delivery Method Toggle */}
                    <div>
                      <label className="text-stone-300 text-xs block mb-2 font-bold">طريقة الاستلام المطلوبة</label>
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          type="button"
                          onClick={() => setDeliveryMethod('delivery')}
                          className={`p-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 transition-all cursor-pointer ${
                            deliveryMethod === 'delivery'
                              ? 'border-amber-500 bg-amber-950/30 text-amber-400'
                              : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                          }`}
                        >
                          <Truck className="w-4 h-4" />
                          <span>توصيل ساخن للمنزل</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeliveryMethod('pickup')}
                          className={`p-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 transition-all cursor-pointer ${
                            deliveryMethod === 'pickup'
                              ? 'border-amber-500 bg-amber-950/30 text-amber-400'
                              : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                          }`}
                        >
                          <MapPin className="w-4 h-4" />
                          <span>استلام شخصي من المحل</span>
                        </button>
                      </div>
                    </div>

                    {/* Address / City */}
                    <div>
                      {deliveryMethod === 'delivery' && (
                        <div className="space-y-3">
                          <div>
                            <label className="text-stone-300 text-xs block mb-1 font-bold">المدينة أو المنطقة *</label>
                            <select
                              value={cityId}
                              onChange={(e) => setCityId(e.target.value)}
                              className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                            >
                              {MOROCCAN_CITIES.map(city => (
                                <option key={city.id} value={city.id}>
                                  {city.name} (+{city.fee} د.م.)
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="text-stone-300 text-xs block mb-1 font-bold">عنوان المنزل بالكامل *</label>
                            <input
                              type="text"
                              required={deliveryMethod === 'delivery'}
                              value={address}
                              onChange={(e) => setAddress(e.target.value)}
                              placeholder="اسم الشارع، رقم الشقة/الفيلا"
                              className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                            />
                          </div>
                        </div>
                      )}

                      {deliveryMethod === 'pickup' && (
                        <div className="p-3 bg-[#18110D] rounded-xl border border-[#2D1B12] text-xs text-stone-300 leading-relaxed">
                          📌 عنوان الفرع الرئيسي للاستلام: <span className="text-amber-400 font-bold">الشارع محمد الخامس إبن جرير</span>. يرجى الحضور بعد ساعة من تأكيد الطلب لاستلام الشواء وهو ساخن جداً.
                        </div>
                      )}
                    </div>

                    {step === 1 && cart.length > 0 && (
                      <button
                        type="submit"
                        className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl shadow-lg shadow-orange-950/20 transition-all text-xs flex items-center justify-center gap-2 mt-4 cursor-pointer"
                      >
                        <span>متابعة لاختيار طريقة الدفع</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </form>
                )}

              </div>

              {/* Right Panel: Checkout Price Summary & Interactive Payment options */}
              <div className="lg:col-span-5 space-y-6">
                
                {/* Price Receipt */}
                <div className="bg-[#140E0A] p-6 rounded-2xl border border-[#2D1B12]">
                  <h3 className="text-stone-100 font-serif font-bold text-sm border-b border-stone-850 pb-3 mb-4">كشف الحساب الإجمالي</h3>
                  
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between text-stone-400">
                      <span>المجموع الفرعي للشواء والمقبلات:</span>
                      <span className="font-sans">{subtotal} د.م.</span>
                    </div>
                    
                    {deliveryMethod === 'delivery' && (
                      <div className="flex justify-between text-stone-400">
                        <span>رسوم التوصيل السريع ({selectedCityInfo?.name}):</span>
                        <span className="font-sans">{deliveryFee} د.م.</span>
                      </div>
                    )}
                    
                    <div className="border-t border-stone-850 pt-3 flex justify-between font-bold text-sm text-amber-400">
                      <span>الإجمالي الكلي المستحق:</span>
                      <span className="font-sans text-lg">{total} درهم مغربي</span>
                    </div>
                  </div>

                  {deliveryMethod === 'delivery' && selectedCityInfo && (
                    <div className="mt-4 p-3 bg-[#18110D] rounded-xl border border-[#2D1B12] text-[10px] text-stone-400 text-center">
                      ⏱️ وقت التوصيل المقدر لـ {selectedCityInfo.name}: <span className="text-stone-100 font-bold">{selectedCityInfo.deliveryTime}</span>
                    </div>
                  )}

                  {/* Customer Live Chat Trigger During Order */}
                  <div className="mt-4 p-3.5 bg-gradient-to-r from-amber-950/40 to-stone-900/60 rounded-xl border border-amber-500/30 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div className="text-right">
                        <p className="text-[11px] font-bold text-amber-300">هل لديك استفسار أو طلب خاص؟</p>
                        <p className="text-[10px] text-stone-400">تحدث مع معلم الشواء مباشرة الآن</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        window.dispatchEvent(new CustomEvent('open_live_chat', {
                          detail: {
                            customerName: name || 'زبون شواية الأصالة',
                            customerPhone: phone || ''
                          }
                        }));
                      }}
                      className="bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer shrink-0 shadow"
                    >
                      <span>دردش الآن 💬</span>
                    </button>
                  </div>
                </div>

                {/* Step 2: Payment options shown only when step is 2 */}
                {step === 2 && (
                  <div className="bg-[#140E0A] p-6 rounded-2xl border border-[#2D1B12] shadow-xl space-y-4 animate-fade-in">
                    <h3 className="text-stone-100 font-serif font-bold text-sm border-b border-stone-850 pb-3">حدد طريقة الدفع الآمنة</h3>
                    
                    <div className="grid grid-cols-3 gap-2">
                      {isCodAvailable && (
                        <button
                          type="button"
                          onClick={() => setPaymentMethod('cod')}
                          className={`py-3 px-1 rounded-xl border text-[10px] sm:text-xs font-bold flex flex-col items-center gap-2 transition-all cursor-pointer ${
                            paymentMethod === 'cod'
                              ? 'border-amber-500 bg-amber-950/30 text-amber-400'
                              : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                          }`}
                        >
                          <DollarSign className="w-5 h-5" />
                          <span>عند الاستلام</span>
                        </button>
                      )}

                      {isCardAvailable && (
                        <button
                          type="button"
                          onClick={() => setPaymentMethod('card')}
                          className={`py-3 px-1 rounded-xl border text-[10px] sm:text-xs font-bold flex flex-col items-center gap-2 transition-all cursor-pointer ${
                            paymentMethod === 'card'
                              ? 'border-amber-500 bg-amber-950/30 text-amber-400'
                              : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                          }`}
                        >
                          <CreditCard className="w-5 h-5" />
                          <span>بطاقة بنكية</span>
                        </button>
                      )}

                      {isTransferAvailable && (
                        <button
                          type="button"
                          onClick={() => setPaymentMethod('transfer')}
                          className={`py-3 px-1 rounded-xl border text-[10px] sm:text-xs font-bold flex flex-col items-center gap-2 transition-all cursor-pointer ${
                            paymentMethod === 'transfer'
                              ? 'border-amber-500 bg-amber-950/30 text-amber-400'
                              : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                          }`}
                        >
                          <Landmark className="w-5 h-5" />
                          <span>تحويل بنكي</span>
                        </button>
                      )}
                    </div>

                    {/* PAYMENT METHOD DETAILED PANELS */}
                    <div className="pt-3">
                      
                      {/* 1. CASH ON DELIVERY */}
                      {paymentMethod === 'cod' && (
                        <div className="space-y-3 text-xs leading-relaxed text-stone-300">
                          <p>✓ الدفع نقداً (كاش) لـسائق التوصيل عند استلام الوجبة ساخنة في منزلك.</p>
                          <p>✓ لا توجد أي رسوم إضافية مخفية.</p>
                          <p className="text-[10px] text-amber-500 font-bold">المرجو تحضير المبلغ المحدد ({total} درهم) لتسهيل الفك مع السائق.</p>
                        </div>
                      )}

                      {/* 2. CREDIT CARD */}
                      {paymentMethod === 'card' && (
                        <div className="space-y-4">
                          <div className="relative rounded-2xl bg-gradient-to-tr from-[#5a2e12] via-[#753b17] to-[#994e1d] p-5 text-white font-mono shadow-xl overflow-hidden">
                            <div className="absolute top-0 right-0 -mr-6 -mt-6 w-24 h-24 rounded-full bg-white/10 blur-xl"></div>
                            
                            <div className="flex justify-between items-start mb-6">
                              <span className="text-white font-bold italic text-sm">{bankName}</span>
                              <div className="w-8 h-6 bg-amber-400/80 rounded-md"></div>
                            </div>

                            <div className="text-sm tracking-widest text-center py-2 font-bold select-none text-white">
                              {cardNumber ? cardNumber : '••••  ••••  ••••  ••••'}
                            </div>

                            <div className="flex justify-between items-end mt-4">
                              <div>
                                <span className="text-[8px] text-white/70 block uppercase font-sans">اسم صاحب البطاقة</span>
                                <span className="text-xs font-bold font-sans uppercase">
                                  {cardName ? cardName : 'MR OWNER NAME'}
                                </span>
                              </div>
                              <div className="text-left">
                                <span className="text-[8px] text-white/70 block uppercase font-sans">تاريخ الصلاحية</span>
                                <span className="text-xs font-bold">{cardExpiry ? cardExpiry : 'MM/YY'}</span>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-3 pt-2 text-xs">
                            <div>
                              <input
                                type="text"
                                maxLength={19}
                                value={cardNumber}
                                onChange={(e) => {
                                  const val = e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim();
                                  setCardNumber(val);
                                }}
                                placeholder="رقم البطاقة (16 رقماً)"
                                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 focus:border-amber-500 focus:outline-none"
                              />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-3">
                              <input
                                type="text"
                                maxLength={5}
                                value={cardExpiry}
                                onChange={(e) => setCardExpiry(e.target.value)}
                                placeholder="تاريخ الصلاحية (MM/YY)"
                                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 focus:border-amber-500 focus:outline-none text-center"
                              />
                              <input
                                type="password"
                                maxLength={3}
                                value={cardCvv}
                                onChange={(e) => setCardCvv(e.target.value)}
                                placeholder="الرمز السري (CVV)"
                                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 focus:border-amber-500 focus:outline-none text-center"
                              />
                            </div>

                            <input
                              type="text"
                              value={cardName}
                              onChange={(e) => setCardName(e.target.value)}
                              placeholder="الاسم الكامل المكتوب على البطاقة"
                              className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 focus:border-amber-500 focus:outline-none"
                            />
                            
                            <p className="text-[10px] text-stone-400 leading-normal text-right">
                              🔐 معالجة آمنة ومشفرة 100% متوافقة مع معايير الأمان المغربية.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* 3. BANK TRANSFER */}
                      {paymentMethod === 'transfer' && (
                        <div className="space-y-4 text-xs">
                          <div className="bg-[#18110D] border border-[#2D1B12] p-4 rounded-xl space-y-2 text-right">
                            <span className="text-[10px] text-stone-400 block">تفاصيل الحساب البنكي (RIB)</span>
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-stone-300">اسم البنك:</span>
                              <span className="text-stone-100 font-bold">{bankName}</span>
                            </div>
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-stone-300">اسم المستفيد:</span>
                              <span className="text-stone-100 font-bold">{bankBeneficiary}</span>
                            </div>
                            <div className="flex flex-col border-t border-stone-850 pt-2 mt-2">
                              <div className="flex justify-between items-center mb-1">
                                <span className="text-stone-300">رقم الحساب الكامل (RIB):</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard.writeText(cleanRib);
                                    setCopiedRib(true);
                                    setTimeout(() => setCopiedRib(false), 2000);
                                  }}
                                  className="text-[10px] text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors cursor-pointer"
                                >
                                  {copiedRib ? (
                                    <>
                                      <Check className="w-3 h-3 text-emerald-400" />
                                      <span className="text-emerald-400 font-bold">تم النسخ!</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3 h-3" />
                                      <span>نسخ الرقم</span>
                                    </>
                                  )}
                                </button>
                              </div>
                              <span 
                                onClick={() => {
                                  navigator.clipboard.writeText(cleanRib);
                                  setCopiedRib(true);
                                  setTimeout(() => setCopiedRib(false), 2000);
                                }}
                                title="اضغط لنسخ رقم الحساب"
                                className="text-amber-400 font-sans font-bold text-center tracking-wider text-xs select-all bg-stone-900 p-2.5 rounded mt-1 border border-stone-800 hover:border-amber-500/50 cursor-pointer transition-colors"
                              >
                                {bankRib}
                              </span>
                            </div>
                          </div>

                          {/* Reference input & upload file */}
                          <div className="space-y-3">
                            <div>
                              <label className="text-stone-300 text-[10px] block mb-1 font-bold">الرقم المرجعي للتحويل (أو اسم المودع)</label>
                              <input
                                type="text"
                                value={transferRef}
                                onChange={(e) => setTransferRef(e.target.value)}
                                placeholder="مثال: TRX987213"
                                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 focus:border-amber-500 focus:outline-none"
                              />
                            </div>

                            <div>
                              <span className="text-stone-300 text-[10px] block mb-1.5 font-bold">إرفاق لقطة شاشة لوصل التحويل (اختياري)</span>
                              <label className="border border-dashed border-stone-800 bg-stone-900/50 hover:bg-stone-900 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all">
                                <input
                                  type="file"
                                  accept="image/*"
                                  className="hidden"
                                  onChange={handleFileUploadMock}
                                />
                                <Upload className="w-6 h-6 text-stone-400 mb-1" />
                                <span className="text-xs text-stone-300">
                                  {transferReceipt ? transferReceipt.name : 'اسحب الصورة هنا أو اختر الملف'}
                                </span>
                                <span className="text-[9px] text-stone-500 mt-0.5">JPG، PNG أقل من 5 ميجابايت</span>
                              </label>

                              {uploadProgress && (
                                <div className="mt-2 text-center text-amber-500 text-[10px] animate-pulse">
                                  جاري تحميل وقراءة وصل التحويل...
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Step 2 Actions */}
                    <div className="flex gap-3 pt-4">
                      <button
                        type="button"
                        onClick={() => setStep(1)}
                        className="flex-1 py-3 border border-stone-800 hover:bg-stone-900 text-stone-300 hover:text-stone-100 font-bold rounded-xl transition-all text-xs cursor-pointer"
                      >
                        رجوع للعنوان
                      </button>
                      <button
                        type="button"
                        onClick={handleCompleteOrder}
                        className="flex-1 py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl shadow-lg shadow-orange-950/20 transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>تأكيد وطبخ الطلب</span>
                      </button>
                    </div>

                  </div>
                )}

              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
