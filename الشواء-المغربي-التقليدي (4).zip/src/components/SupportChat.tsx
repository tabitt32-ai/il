import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  X, 
  BadgeCheck, 
  CheckCircle2, 
  ExternalLink,
  Sparkles,
  Phone,
  Clock,
  Flame
} from 'lucide-react';
import { AppNotification, ChatMessage } from '../types';
import { subscribeChatMessages, sendChatMessage, markChatAsRead } from '../firebase';

interface SupportChatProps {
  phone?: string;
  onNotify?: (notification: AppNotification) => void;
}

export default function SupportChat({ phone = '212717301089', onNotify }: SupportChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [chatMode, setChatMode] = useState<'live' | 'whatsapp'>('live');
  const [inputText, setInputText] = useState('');
  const [sentFeedback, setSentFeedback] = useState<string | null>(null);

  // Customer identity
  const [customerName, setCustomerName] = useState(() => {
    return localStorage.getItem('shw_chat_name') || 'زبون شواية الأصالة';
  });
  const [customerPhone, setCustomerPhone] = useState(() => {
    return localStorage.getItem('shw_chat_phone') || '';
  });
  const [activeOrderId, setActiveOrderId] = useState<string | undefined>(undefined);

  // Chat thread ID
  const [chatId, setChatId] = useState<string>(() => {
    let saved = localStorage.getItem('shw_customer_chat_id');
    if (!saved) {
      saved = `chat_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      localStorage.setItem('shw_customer_chat_id', saved);
    }
    return saved;
  });

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [hasNewAdminReply, setHasNewAdminReply] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const cleanPhone = phone.replace(/[^0-9]/g, '') || '212717301089';

  // Listen for custom trigger event to open chat from Checkout or elsewhere
  useEffect(() => {
    const handleOpenChat = (event: any) => {
      const detail = event?.detail || {};
      if (detail.chatId) setChatId(detail.chatId);
      if (detail.customerName) {
        setCustomerName(detail.customerName);
        localStorage.setItem('shw_chat_name', detail.customerName);
      }
      if (detail.customerPhone) {
        setCustomerPhone(detail.customerPhone);
        localStorage.setItem('shw_chat_phone', detail.customerPhone);
      }
      if (detail.orderId) setActiveOrderId(detail.orderId);
      setIsOpen(true);
      setChatMode('live');
    };

    window.addEventListener('open_live_chat', handleOpenChat);
    return () => window.removeEventListener('open_live_chat', handleOpenChat);
  }, []);

  // Subscribe to live messages
  useEffect(() => {
    if (!chatId) return;

    const unsub = subscribeChatMessages(chatId, (msgs) => {
      // Check if there's a new admin reply
      const lastMsg = msgs[msgs.length - 1];
      if (lastMsg && lastMsg.sender === 'admin' && !isOpen) {
        setHasNewAdminReply(true);
      }

      setMessages(msgs);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => unsub();
  }, [chatId, isOpen]);

  // When opening chat, mark as read
  useEffect(() => {
    if (isOpen) {
      setHasNewAdminReply(false);
      markChatAsRead(chatId, 'customer');
    }
  }, [isOpen, chatId]);

  const quickQuestions = [
    { text: 'كم يستغرق تجهيز الطلب والشواء؟ ⏱️', msg: 'السلام عليكم، كم يستغرق تجهيز طلب الشواء البلدي على الفحم ومتى يصلني؟' },
    { text: 'هل يمكن زيادة كمية الكمون والتوابل؟ 🌶️', msg: 'السلام عليكم، أود التأكيد على إضافة بهارات وتوابل مغربية إضافية مع طلبي.' },
    { text: 'استفسار عن التحويل البنكي CIH 💳', msg: 'السلام عليكم، أود الاستفسار عن تأكيد الدفع عبر التحويل البنكي لحسابكم في CIH.' },
    { text: 'أود حجز خدمة الشواء لمناسبة/عرس 💍', msg: 'السلام عليكم، أريد الاستفسار عن حجز خرفان مشوية كاملة لمناسبة عائلية خاصة.' }
  ];

  const handleSendLive = async (textToSend: string) => {
    if (!textToSend.trim() || isSending) return;

    try {
      setIsSending(true);
      await sendChatMessage(chatId, {
        sender: 'customer',
        senderName: customerName,
        text: textToSend.trim(),
        customerPhone,
        orderId: activeOrderId
      });
      setInputText('');
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsSending(false);
    }
  };

  const handleSendWhatsApp = (textToSend: string) => {
    if (!textToSend.trim()) return;
    const encodedText = encodeURIComponent(textToSend);
    window.open(`https://wa.me/${cleanPhone}?text=${encodedText}`, '_blank');
    setInputText('');
    setSentFeedback('تم فتح تطبيق واتساب بنجاح!');

    if (onNotify) {
      onNotify({
        id: `notif_${Date.now()}`,
        type: 'whatsapp_sent',
        title: 'تم تجهيز رسالة الواتساب 💬',
        message: 'تم فتح المحادثة مع معلم الشواء عبر تطبيق واتساب.',
        timestamp: 'الآن',
        actionLabel: 'فتح الواتساب مجدداً',
        actionType: 'open_whatsapp'
      });
    }

    setTimeout(() => {
      setSentFeedback(null);
    }, 4000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 font-sans text-right">
      
      {/* Floating Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl shadow-orange-950/40 transition-all duration-300 hover:scale-105 active:scale-95 group cursor-pointer border border-amber-400/30"
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
            {(hasNewAdminReply || messages.length > 0) && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-stone-950 animate-ping"></span>
            )}
          </div>
          <span className="text-xs sm:text-sm tracking-wide flex items-center gap-1.5 font-bold">
            <span>دردش مع معلم الشواء</span>
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400"></span>
          </span>
        </button>
      )}

      {/* Main Interactive Chat Panel */}
      {isOpen && (
        <div className="bg-[#0B0806] border border-[#2D1B12] rounded-3xl w-[340px] sm:w-[380px] shadow-2xl shadow-black/80 flex flex-col overflow-hidden animate-fade-in relative max-h-[580px] h-[540px]">
          
          {/* Header */}
          <div className="bg-[#142312] border-b border-[#2D1B12] p-3.5 text-white flex justify-between items-center relative">
            <div className="flex items-center gap-2.5 relative z-10">
              <div className="relative">
                <div className="w-9 h-9 rounded-full bg-[#18110D] flex items-center justify-center text-lg border border-[#2D1B12]">
                  👨‍🍳
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-[#142312]"></span>
              </div>
              <div>
                <h4 className="font-serif text-xs sm:text-sm font-bold flex items-center gap-1 text-white">
                  <span>المشرف (الحاج العيدي)</span>
                  <BadgeCheck className="w-4 h-4 text-emerald-300 fill-emerald-600" />
                </h4>
                <p className="text-[10px] text-emerald-200">متصل الآن • يجيبك فوراً أثناء الطلب</p>
              </div>
            </div>
            
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-stone-950/30 text-emerald-100 hover:text-white rounded-full relative z-10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex bg-stone-950 border-b border-stone-800 text-xs">
            <button
              onClick={() => setChatMode('live')}
              className={`flex-1 py-2 text-center font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                chatMode === 'live' 
                  ? 'bg-amber-600 text-stone-950' 
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>دردشة حية فورية</span>
            </button>
            <button
              onClick={() => setChatMode('whatsapp')}
              className={`flex-1 py-2 text-center font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                chatMode === 'whatsapp' 
                  ? 'bg-emerald-600 text-white' 
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>واتساب مباشر</span>
            </button>
          </div>

          {/* Chat Body - LIVE MODE */}
          {chatMode === 'live' && (
            <div className="flex-1 flex flex-col bg-[#0B0806] overflow-hidden">
              
              {/* Messages scroll area */}
              <div className="flex-1 p-3 overflow-y-auto space-y-3">
                {/* Initial Welcome message from merchant */}
                <div className="bg-[#18110D] border border-[#2D1B12] p-3 rounded-2xl rounded-tr-none text-xs text-stone-100 leading-relaxed max-w-[90%] mr-0 ml-auto text-right">
                  <p className="font-bold text-amber-400 mb-1 flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-amber-500" />
                    مرحباً بك في شواية الأصالة!
                  </p>
                  <p>أنا متواجد هنا لمساعدتك والإجابة على أي استفسار حول اللحم، التوابل، أو تأكيد موعد الشواء والتوصيل.</p>
                  {activeOrderId && (
                    <p className="mt-1 text-[11px] text-amber-300 font-sans">
                      مرتبط بالطلب: #{activeOrderId.slice(-6)}
                    </p>
                  )}
                </div>

                {/* Firestore messages */}
                {messages.map((msg) => {
                  const isCustomer = msg.sender === 'customer';
                  const time = msg.createdAt 
                    ? new Date(msg.createdAt).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })
                    : '';

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isCustomer ? 'items-end' : 'items-start'}`}
                    >
                      <div className="flex items-center gap-1 mb-0.5 px-1 text-[9px] text-stone-500 font-sans">
                        <span>{isCustomer ? 'أنت' : 'المشرف'}</span>
                        <span>•</span>
                        <span>{time}</span>
                      </div>
                      <div
                        className={`max-w-[85%] p-2.5 rounded-2xl text-xs leading-relaxed ${
                          isCustomer
                            ? 'bg-amber-600 text-stone-950 font-medium rounded-tl-none shadow'
                            : 'bg-stone-800 text-stone-100 rounded-tr-none border border-stone-700'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                      </div>
                    </div>
                  );
                })}

                <div ref={messagesEndRef} />
              </div>

              {/* Quick suggestion chips */}
              <div className="p-2 bg-stone-950/80 border-t border-stone-900 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-1">
                {quickQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendLive(q.msg)}
                    className="text-[10px] bg-[#18110D] hover:bg-stone-800 border border-[#2D1B12] text-stone-300 hover:text-white px-2.5 py-1 rounded-full shrink-0 transition-colors cursor-pointer"
                  >
                    {q.text}
                  </button>
                ))}
              </div>

              {/* Input Area */}
              <div className="p-2.5 bg-[#140E0A] border-t border-[#2D1B12] flex gap-2 items-center">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendLive(inputText);
                    }
                  }}
                  placeholder="اكتب استفسارك لمعلم الشواء هنا..."
                  className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  onClick={() => handleSendLive(inputText)}
                  disabled={!inputText.trim() || isSending}
                  className="p-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-stone-950 font-bold disabled:opacity-30 cursor-pointer shadow-md transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Chat Body - WHATSAPP MODE */}
          {chatMode === 'whatsapp' && (
            <div className="flex-1 flex flex-col bg-[#0B0806] p-4 overflow-y-auto space-y-4">
              <div className="bg-[#18110D] border border-[#2D1B12] p-3.5 rounded-2xl text-xs text-stone-200 leading-relaxed">
                <p className="font-bold text-emerald-400 mb-1 flex items-center gap-1.5">
                  <ExternalLink className="w-4 h-4 text-emerald-400" />
                  محادثة مباشرة عبر واتساب
                </p>
                <p>يمكنك التحدث مباشرة مع معلم الشواء على الواتساب لمشاركة صور المكان، إرسال موقع GPS، أو إرسال وصل التحويل البنكي.</p>
              </div>

              <div className="space-y-2">
                <span className="text-[11px] text-stone-400 font-bold block">اختر سؤالاً سريعاً للإرسال عبر واتساب:</span>
                <div className="flex flex-col gap-1.5">
                  {quickQuestions.map((q, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSendWhatsApp(q.msg)}
                      className="bg-[#140E0A] hover:bg-[#18110D] border border-[#2D1B12] hover:border-emerald-500/40 text-stone-200 text-xs px-3 py-2.5 rounded-xl text-right transition-all cursor-pointer flex justify-between items-center"
                    >
                      <span>{q.text}</span>
                      <ExternalLink className="w-3 h-3 text-emerald-400 opacity-60" />
                    </button>
                  ))}
                </div>
              </div>

              {sentFeedback && (
                <div className="bg-emerald-950/80 border border-emerald-600/40 p-2.5 rounded-xl text-xs text-emerald-200 flex items-center gap-2 animate-fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{sentFeedback}</span>
                </div>
              )}

              <div className="mt-auto pt-3 border-t border-stone-800 flex gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendWhatsApp(inputText)}
                  placeholder="رسالة مخصصة لواتساب..."
                  className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-emerald-500"
                />
                <button
                  onClick={() => handleSendWhatsApp(inputText)}
                  disabled={!inputText.trim()}
                  className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs disabled:opacity-30 transition-all cursor-pointer flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                  <span>إرسال</span>
                </button>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
