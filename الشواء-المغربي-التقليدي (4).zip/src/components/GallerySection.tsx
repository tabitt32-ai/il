import React, { useState } from 'react';
import { Sparkles, ZoomIn, X, Camera, Flame } from 'lucide-react';
import { GalleryImage } from '../types';

interface GallerySectionProps {
  images?: GalleryImage[];
  onOrderClick?: () => void;
}

const DEFAULT_GALLERY: GalleryImage[] = [
  {
    id: 'gal_1',
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
    title: 'شواء لحم الغنمي المحمر على الفحم البلدي',
    category: 'مشوي بلدي'
  },
  {
    id: 'gal_2',
    url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1200&q=80',
    title: 'قطبان لحم الغنمي المتبل بالبهارات والكمون',
    category: 'قطبان وكباب'
  },
  {
    id: 'gal_3',
    url: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=1200&q=80',
    title: 'ضيافة الأعراس وطهي الخرفان الكاملة بالأواني الفضية',
    category: 'أعراس ومناسبات'
  },
  {
    id: 'gal_4',
    url: 'https://images.unsplash.com/photo-1574484284002-952d92456975?auto=format&fit=crop&w=1200&q=80',
    title: 'طاجين اللحم البلدي المحمر باللوز والبرقوق المعسل',
    category: 'أطباق فاخرة'
  },
  {
    id: 'gal_5',
    url: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=1200&q=80',
    title: 'طنجية مراكشية فخارية متبلة بالزعفران والليمون المصير',
    category: 'مشوي بلدي'
  },
  {
    id: 'gal_6',
    url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=1200&q=80',
    title: 'صينية أتاي مغربي بالنعناع والرزة العالية للترحيب بالضيوف',
    category: 'ضيافة ومشروبات'
  }
];

export default function GallerySection({ images, onOrderClick }: GallerySectionProps) {
  const displayImages = images && images.length > 0 ? images : DEFAULT_GALLERY;
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [lightboxImage, setLightboxImage] = useState<GalleryImage | null>(null);

  // Extract unique categories
  const categories = ['all', ...Array.from(new Set(displayImages.map(img => img.category || 'أطباق فاخرة')))];

  const filteredImages = selectedTag === 'all' 
    ? displayImages 
    : displayImages.filter(img => (img.category || 'أطباق فاخرة') === selectedTag);

  return (
    <section id="gallery" className="py-24 bg-[#090503] border-t border-[#1C1009] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-amber-500 font-bold text-xs tracking-widest uppercase bg-amber-950/40 px-3 py-1.5 rounded-full border border-amber-900/40 inline-flex items-center gap-1.5">
            <Camera className="w-3.5 h-3.5 text-amber-400" />
            معرض صور الشواء والضيافة
          </span>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-100 mt-4 mb-4">
            روائع المشوي المغربي في صور حية
          </h2>
          <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
            شاهد لذة الشواء المغربي، قطبان اللحم الطرية، وولائم الأعراس الملكية التي نعدها بكل فخر وحرفية.
          </p>
        </div>

        {/* Filter Tabs */}
        {categories.length > 2 && (
          <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedTag(cat)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
                  selectedTag === cat
                    ? 'bg-amber-600 text-white font-bold shadow-lg shadow-amber-950/50'
                    : 'bg-[#140E0A] text-stone-400 hover:text-stone-200 border border-[#2D1B12] hover:border-amber-900/40'
                }`}
              >
                {cat === 'all' ? 'جميع الصور' : cat}
              </button>
            ))}
          </div>
        )}

        {/* Images Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredImages.map((img) => (
            <div
              key={img.id}
              onClick={() => setLightboxImage(img)}
              className="group relative bg-[#140E0A] rounded-3xl overflow-hidden border border-[#2D1B12] hover:border-amber-500/50 transition-all duration-500 shadow-xl cursor-pointer flex flex-col justify-end aspect-[4/3]"
            >
              <img
                src={img.url}
                alt={img.title}
                className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent group-hover:via-black/40 transition-colors"></div>

              {/* Tag & Zoom indicator */}
              <div className="relative z-10 p-5 flex flex-col justify-between h-full">
                <div className="flex justify-between items-start">
                  {img.category && (
                    <span className="bg-amber-950/80 backdrop-blur-md text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-amber-800/40 shadow-sm">
                      {img.category}
                    </span>
                  )}
                  <div className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white/80 group-hover:text-amber-400 group-hover:scale-110 transition-all">
                    <ZoomIn className="w-4 h-4" />
                  </div>
                </div>

                <div>
                  <h3 className="font-serif text-base sm:text-lg font-bold text-white drop-shadow-md group-hover:text-amber-300 transition-colors">
                    {img.title}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA banner under gallery */}
        {onOrderClick && (
          <div className="mt-14 text-center">
            <button
              onClick={onOrderClick}
              className="px-8 py-3.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl shadow-xl transition-all text-xs sm:text-sm inline-flex items-center gap-2 cursor-pointer"
            >
              <Flame className="w-4 h-4" />
              <span>اطلب وجبتك وشوائك المفضل الآن</span>
            </button>
          </div>
        )}

      </div>

      {/* Fullscreen Lightbox Modal */}
      {lightboxImage && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div 
            className="relative max-w-4xl w-full bg-[#140E0A] rounded-3xl overflow-hidden border border-amber-900/50 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-4 left-4 z-20 w-10 h-10 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="max-h-[75vh] overflow-hidden bg-black flex items-center justify-center">
              <img
                src={lightboxImage.url}
                alt={lightboxImage.title}
                className="w-full h-full max-h-[75vh] object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="p-6 bg-[#140E0A] border-t border-stone-850 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-right">
              <div>
                {lightboxImage.category && (
                  <span className="text-[11px] text-amber-500 font-bold block mb-1">
                    {lightboxImage.category}
                  </span>
                )}
                <h4 className="font-serif text-lg sm:text-xl font-bold text-stone-100">
                  {lightboxImage.title}
                </h4>
              </div>

              {onOrderClick && (
                <button
                  onClick={() => {
                    setLightboxImage(null);
                    onOrderClick();
                  }}
                  className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap"
                >
                  طلب الشواء الآن
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </section>
  );
}
