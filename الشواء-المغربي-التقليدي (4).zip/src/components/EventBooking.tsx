import React, { useState } from 'react';
import { Calendar, Users, Calculator, Gift, Sparkles, Check, CheckCircle2, AlertCircle, MessageSquare } from 'lucide-react';
import { EventBookingRequest, AppNotification, SiteSettings } from '../types';
import cateringImage from '../assets/images/moroccan_wedding_catering_1783196853669.jpg';

interface EventBookingProps {
  onAddBooking: (booking: EventBookingRequest) => void;
  onNotify?: (notification: AppNotification) => void;
  whatsappPhone?: string;
  siteSettings?: SiteSettings;
}

export default function EventBooking({ 
  onAddBooking, 
  onNotify, 
  whatsappPhone = '212717301089',
  siteSettings 
}: EventBookingProps) {
  const [guests, setGuests] = useState<number>(50);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('0717301089');
  const [eventType, setEventType] = useState<'wedding' | 'aqeeqah' | 'family' | 'corporate' | 'other'>('wedding');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('الشارع محمد الخامس إبن جرير');
  const [meatPref, setMeatPref] = useState<'sheep' | 'goat' | 'beef_skewers' | 'mixed'>('sheep');
  const [additionalServices, setAdditionalServices] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [lastSubmittedBooking, setLastSubmittedBooking] = useState<EventBookingRequest | null>(null);

  // Estimations logic
  // 1 Lamb serves ~10 guests (standard Moroccan wedding table)
  const lambsNeeded = Math.ceil(guests / 10);
  const basePricePerLamb = 3400; // MAD including premium whole sheep, spices, charcoal, and 2 professional chefs
  
  const addServiceOptions = [
    { id: 'waiters', name: 'خدمة نادلين بزي تقليدي', price: 500, desc: 'نادلون محترفون بالجابادور لخدمة الضيوف' },
    { id: 'tea_service', name: 'جلسة أتاي وحلويات بلدية', price: 800, desc: 'نحاسيات الشاي الفاخرة مع تشكيلة دواز أتاي فاسي' },
    { id: 'music', name: 'مجموعة الدقة المراكشية للترحيب', price: 1500, desc: 'ترحيب فلكلوري تقليدي أصيل عند دخول الضيوف' },
    { id: 'tent', name: 'خيام مغربية تقليدية فاخرة', price: 2500, desc: 'تجهيز قعدة مخزنية بـالزرابي والصالونات التقليدية' }
  ];

  const handleServiceToggle = (id: string) => {
    if (additionalServices.includes(id)) {
      setAdditionalServices(additionalServices.filter(s => s !== id));
    } else {
      setAdditionalServices([...additionalServices, id]);
    }
  };

  const servicesTotal = additionalServices.reduce((sum, id) => {
    const s = addServiceOptions.find(opt => opt.id === id);
    return sum + (s ? s.price : 0);
  }, 0);

  const totalEstimatedPrice = (lambsNeeded * basePricePerLamb) + servicesTotal;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !date || !location) {
      alert('المرجو ملء جميع الحقول المطلوبة لتمكين معلم الشواء من الاتصال بك.');
      return;
    }

    const booking: EventBookingRequest = {
      id: `evt_${Date.now()}`,
      customerName: name,
      customerPhone: phone,
      eventType,
      eventDate: date,
      eventLocation: location,
      guestCount: guests,
      meatPreference: meatPref,
      estimatedLambsNeeded: lambsNeeded,
      additionalServices: additionalServices.map(id => addServiceOptions.find(o => o.id === id)?.name || ''),
      notes,
      totalEstimatedPrice,
      status: 'pending',
      createdAt: new Date().toLocaleString('ar-MA')
    };

    onAddBooking(booking);
    setLastSubmittedBooking(booking);
    setIsSubmitted(true);

    if (onNotify) {
      onNotify({
        id: `notif_${Date.now()}`,
        type: 'booking_created',
        title: 'تم تسجيل طلب حجز المناسبة 💍',
        message: `تم تسجيل حجز لـ ${booking.guestCount} ضيف بتكلفة تقديرية ${booking.totalEstimatedPrice} د.م. المرجو تأكيد الموعد عبر الواتساب.`,
        timestamp: 'الآن',
        actionLabel: 'تأكيد عبر واتساب',
        actionType: 'open_whatsapp'
      });
    }

    // Clear form
    setName('');
    setPhone('');
    setDate('');
    setLocation('');
    setAdditionalServices([]);
    setNotes('');
  };

  const handleWhatsAppShare = () => {
    if (!lastSubmittedBooking) return;
    
    const serviceList = lastSubmittedBooking.additionalServices.length > 0 
      ? `\n*الخدمات الإضافية:* ${lastSubmittedBooking.additionalServices.join(' - ')}`
      : '';

    const text = `السلام عليكم ورحمة الله، أريد حجز خدمة الشواء التقليدي للمناسبات:\n\n` +
                 `*الاسم:* ${lastSubmittedBooking.customerName}\n` +
                 `*الهاتف:* ${lastSubmittedBooking.customerPhone}\n` +
                 `*نوع المناسبة:* ${
                   lastSubmittedBooking.eventType === 'wedding' ? 'زفاف/عرس' :
                   lastSubmittedBooking.eventType === 'aqeeqah' ? 'عقيقة' :
                   lastSubmittedBooking.eventType === 'family' ? 'لمة عائلية/حفل خاص' :
                   lastSubmittedBooking.eventType === 'corporate' ? 'مأدبة عمل/شركات' : 'مناسبة أخرى'
                 }\n` +
                 `*التاريخ:* ${lastSubmittedBooking.eventDate}\n` +
                 `*المدينة والعنوان:* ${lastSubmittedBooking.eventLocation}\n` +
                 `*عدد الضيوف المقدر:* ${lastSubmittedBooking.guestCount} شخص\n` +
                 `*الخرفان المطلوبة (تقديرياً):* ${lastSubmittedBooking.estimatedLambsNeeded} خروف مشوي كامل\n` +
                 `${serviceList}\n` +
                 `*المجموع التقريبي:* ${lastSubmittedBooking.totalEstimatedPrice} درهم مغربي\n` +
                 (lastSubmittedBooking.notes ? `*ملاحظات:* ${lastSubmittedBooking.notes}\n` : '') +
                 `\nالمرجو تأكيد الحجز وإرسال تفاصيل العربون لتثبيت التاريخ. شكراً لكم!`;

    const encodedText = encodeURIComponent(text);
    const targetPhone = whatsappPhone.replace(/[^0-9]/g, '') || '212717301089';
    // Open WhatsApp
    window.open(`https://wa.me/${targetPhone}?text=${encodedText}`, '_blank');

    if (onNotify) {
      onNotify({
        id: `notif_${Date.now()}`,
        type: 'whatsapp_sent',
        title: 'تم فتح محادثة الحجز في واتساب 📱',
        message: 'تم إعداد تفاصيل حجز المناسبة وعربونها على واتساب. اضغط "إرسال" لتثبيت التاريخ دون تأخير.',
        timestamp: 'الآن',
        actionLabel: 'فتح الواتساب مجدداً',
        actionType: 'open_whatsapp'
      });
    }
  };

  return (
    <section id="events-catering" className="py-20 bg-[#030101] border-t border-[#2C1A10] relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,_var(--tw-gradient-stops))] from-[#2C1A10]/20 via-transparent to-transparent opacity-50"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Intro */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-amber-500 font-bold tracking-widest text-xs uppercase bg-amber-950/30 px-3 py-1.5 rounded-full border border-amber-900/30">خدمات الأعراس والحفلات الفاخرة</span>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-100 mt-4 mb-6 leading-tight">
            {siteSettings?.eventsTitle || 'المشوي المغربي للأعراس والمناسبات'}
          </h2>
          <p className="text-stone-300 text-lg leading-relaxed font-sans">
            {siteSettings?.eventsSubtitle || 'نجعل مناسباتكم حكايات لا تُنسى. نوفر طاقماً متكاملاً من أمهر معلمي الشواء لطهي الخرفان الكاملة على الطريقة التقليدية (المشوي البلدي) مباشرة في مكان حفلكم أو داخل أفراننا الطينية مع التوصيل الملكي الفاخر.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left: Event Details & Planner */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-[#140E0A] p-6 sm:p-8 rounded-3xl border border-[#2D1B12] shadow-xl">
            <div>
              <div className="flex items-center gap-3 border-b border-stone-850 pb-4 mb-6">
                <Calculator className="w-6 h-6 text-amber-500" />
                <h3 className="font-serif text-xl font-bold text-stone-100">حاسبة ضيافة المناسبات</h3>
              </div>

              <div className="space-y-6">
                {/* Guest Slider */}
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <label className="text-stone-300 text-xs font-bold">عدد ضيوفك المقدر:</label>
                    <span className="text-amber-400 font-sans font-bold text-lg bg-amber-950/30 px-3 py-1 rounded-lg border border-amber-900/30">
                      {guests} ضيفاً
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="500"
                    step="5"
                    value={guests}
                    onChange={(e) => setGuests(parseInt(e.target.value))}
                    className="w-full accent-amber-500 h-2 bg-stone-850 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-stone-400 font-sans mt-1">
                    <span>10 ضيوف</span>
                    <span>250 ضيفاً</span>
                    <span>500 ضيف</span>
                  </div>
                </div>

                {/* Estimate output cards */}
                <div className="grid grid-cols-2 gap-3 mt-6">
                  <div className="bg-[#18110D]/50 p-4 rounded-2xl border border-[#2D1B12] text-center">
                    <Users className="w-5 h-5 text-amber-500 mx-auto mb-2" />
                    <span className="text-[10px] text-stone-400 block">الخرفان المطلوبة</span>
                    <span className="text-xl font-sans font-bold text-stone-100 mt-1 block">
                      {lambsNeeded} {lambsNeeded > 10 ? 'خروفاً' : 'خرفان'}
                    </span>
                    <span className="text-[9px] text-stone-500 block mt-1">(خروف لكل طاولة ضيافة)</span>
                  </div>

                  <div className="bg-[#18110D]/50 p-4 rounded-2xl border border-[#2D1B12] text-center">
                    <Sparkles className="w-5 h-5 text-amber-500 mx-auto mb-2" />
                    <span className="text-[10px] text-stone-400 block">طاقم الخدمة المقدر</span>
                    <span className="text-xl font-sans font-bold text-stone-100 mt-1 block">
                      {Math.max(2, Math.floor(lambsNeeded * 1.5))} معلمين
                    </span>
                    <span className="text-[9px] text-stone-500 block mt-1">(للطهي، الإشراف والتقطيع)</span>
                  </div>
                </div>

                {/* Detail Box */}
                <div className="bg-[#18110D] border border-[#2D1B12] p-4 rounded-2xl">
                  <h4 className="text-xs font-bold text-amber-500 flex items-center gap-1.5">
                    <Gift className="w-4 h-4" />
                    ما الذي يشمله الحجز؟
                  </h4>
                  <ul className="text-xs text-stone-300 space-y-2 mt-3 list-disc list-inside">
                    <li>خرفان غنمي بلدية ممتازة من السلالة الحرة (الصردي أو التيمحضيت).</li>
                    <li>توابل المشوي الملكية الفاخرة (كامون مغربي بلدي، سمن حار، بهارات سرية).</li>
                    <li>حطب الكروش عالي الكثافة وفحم صلب مخصص للشواء البطيء.</li>
                    <li>صواني النحاس الكبيرة وبطانات التقديم الفخمة لإبهار ضيوفكم.</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Event total estimation */}
            <div className="border-t border-stone-850 pt-6 mt-6">
              <div className="flex justify-between items-center bg-[#18110D] p-4 rounded-xl border border-[#2D1B12]">
                <div>
                  <span className="text-[10px] text-stone-400 block">التكلفة التقديرية الإجمالية</span>
                  <span className="text-xs text-stone-300 font-bold block mt-1">المشوي + الخدمة</span>
                </div>
                <div className="text-left">
                  <span className="text-2xl font-sans font-extrabold text-amber-400">
                    {totalEstimatedPrice} د.م.
                  </span>
                  <span className="text-[9px] text-stone-450 block mt-0.5">(عربون الحجز: 20%)</span>
                </div>
              </div>
            </div>

          </div>

          {/* Center: Wedding Banner */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            
            {/* Form & Image tabs */}
            <div className="bg-[#140E0A] border border-[#2D1B12] p-6 sm:p-8 rounded-3xl shadow-xl flex-1">
              
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="border-b border-stone-850 pb-4">
                    <h3 className="font-serif text-xl font-bold text-stone-100">طلب استشارة وتأكيد تاريخ الحفل</h3>
                    <p className="text-stone-400 text-xs mt-1">املأ الاستمارة وسيتواصل معك معلم الضيافة لترتيب تفاصيل العربون</p>
                  </div>

                  {/* Personal info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-stone-300 text-xs block mb-1.5 font-bold">اسم صاحب الحفل *</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="مثال: مولاي رشيد"
                        className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-3 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-stone-300 text-xs block mb-1.5 font-bold">رقم الهاتف (الواتساب) *</label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="مثال: 0612345678"
                        className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-3 text-stone-100 text-sm focus:border-amber-500 focus:outline-none font-sans text-right"
                      />
                    </div>
                  </div>

                  {/* Date & Location */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-stone-300 text-xs block mb-1.5 font-bold">تاريخ المناسبة السعيد *</label>
                      <input
                        type="date"
                        required
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-3 text-stone-100 text-sm focus:border-amber-500 focus:outline-none font-sans text-right cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="text-stone-300 text-xs block mb-1.5 font-bold">المدينة والعنوان بالكامل *</label>
                      <input
                        type="text"
                        required
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="مثال: الرباط، فيلا الرياض"
                        className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-3 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Event type & Meat choice */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-stone-300 text-xs block mb-1.5 font-bold">نوع المناسبة السعيدة</label>
                      <select
                        value={eventType}
                        onChange={(e) => setEventType(e.target.value as any)}
                        className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-3 text-stone-100 text-sm focus:border-amber-500 focus:outline-none cursor-pointer"
                      >
                        <option value="wedding">حفل زفاف / عرس مغربي</option>
                        <option value="aqeeqah">سبوع / عقيقة مباركة</option>
                        <option value="family">لمة عائلية / خطوبة</option>
                        <option value="corporate">حفل شركات / مأدبة رسمية</option>
                        <option value="other">مناسبات أخرى</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-stone-300 text-xs block mb-1.5 font-bold">نوع اللحم المفضل</label>
                      <select
                        value={meatPref}
                        onChange={(e) => setMeatPref(e.target.value as any)}
                        className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-3 text-stone-100 text-sm focus:border-amber-500 focus:outline-none cursor-pointer"
                      >
                        <option value="sheep">غنمي صردي كامل (مشوي بلدي)</option>
                        <option value="goat">ماعزي جبلي صغير (الماعز البلدي)</option>
                        <option value="beef_skewers">قطبان بقري وغنمي مشكل</option>
                        <option value="mixed">تشكيلة مختلطة متميزة</option>
                      </select>
                    </div>
                  </div>

                  {/* Additional traditional services */}
                  <div>
                    <label className="text-stone-300 text-xs block mb-2 font-bold">خدمات إضافية ترغب بدمجها:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {addServiceOptions.map((opt) => {
                        const isChecked = additionalServices.includes(opt.id);
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => handleServiceToggle(opt.id)}
                            className={`p-3 text-right rounded-xl border text-xs flex items-start gap-2.5 transition-all cursor-pointer ${
                              isChecked
                                ? 'border-amber-500 bg-amber-950/35 text-amber-400'
                                : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                            }`}
                          >
                            <div className={`w-4 h-4 rounded mt-0.5 border flex items-center justify-center ${
                              isChecked ? 'bg-amber-500 border-amber-500 text-stone-900' : 'border-stone-800 bg-[#140E0A]'
                            }`}>
                              {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                            </div>
                            <div className="flex-1">
                              <span className="font-bold block">{opt.name}</span>
                              <span className="text-[10px] text-stone-400 block mt-0.5">+{opt.price} د.م. ({opt.desc})</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="text-stone-300 text-xs block mb-1.5 font-bold">طلبات خاصة وملاحظات إضافية (اختياري)</label>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="اكتب هنا أي شروط خاصة، تعديل في بهارات المشوي، أو ترتيبات مكان الحفل..."
                      rows={2}
                      className="w-full bg-stone-900 border border-stone-800 rounded-xl p-4 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl shadow-lg shadow-orange-950/30 transition-all text-sm cursor-pointer"
                  >
                    إرسال طلب الحجز وتأكيد التفاصيل
                  </button>
                </form>
              ) : (
                <div className="flex flex-col items-center justify-center text-center p-8 animate-fade-in">
                  <div className="w-20 h-20 rounded-full bg-emerald-950/30 border border-emerald-500 flex items-center justify-center text-emerald-400 mb-6">
                    <CheckCircle2 className="w-12 h-12" />
                  </div>
                  
                  <h3 className="font-serif text-2xl font-bold text-stone-100">هنيئاً لكم! تم استلام طلب الحجز</h3>
                  <p className="text-stone-300 text-sm mt-3 max-w-md leading-relaxed font-sans">
                    لقد قمنا بتسجيل طلب المناسبة السعيدة الخاص بك في نظام الحجوزات المحلي. المرجو تأكيد الحجز وإرسال تفاصيل العربون مباشرة لمعلم الشواء عبر الواتساب لتأمين التاريخ المختار بنجاح.
                  </p>

                  <div className="w-full max-w-md bg-[#18110D] border border-[#2D1B12] p-5 rounded-2xl mt-6 text-right font-sans">
                    <div className="flex justify-between items-center border-b border-stone-800 pb-2 mb-3">
                      <span className="text-xs text-stone-400">رقم الحجز:</span>
                      <span className="text-xs text-amber-400 font-bold">{lastSubmittedBooking?.id}</span>
                    </div>
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-xs text-stone-400">التاريخ المختار:</span>
                      <span className="text-xs text-stone-100 font-bold">{lastSubmittedBooking?.eventDate}</span>
                    </div>
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-xs text-stone-400">عدد الضيوف:</span>
                      <span className="text-xs text-stone-100 font-bold">{lastSubmittedBooking?.guestCount} ضيف</span>
                    </div>
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-xs text-stone-400">الخرفان التقديرية:</span>
                      <span className="text-xs text-stone-100 font-bold">{lastSubmittedBooking?.estimatedLambsNeeded} خروف مشوي</span>
                    </div>
                    <div className="flex justify-between items-center border-t border-stone-800 pt-2 mt-3 font-bold">
                      <span className="text-sm text-stone-100">التكلفة التقديرية الإجمالية:</span>
                      <span className="text-sm text-amber-400">{lastSubmittedBooking?.totalEstimatedPrice} د.م.</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md mt-8">
                    <button
                      type="button"
                      onClick={handleWhatsAppShare}
                      className="flex-1 py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.003 5.156 5.151 0 11.483 0c3.066.001 5.95 1.193 8.113 3.358 2.162 2.164 3.352 5.045 3.351 8.113-.004 6.328-5.152 11.484-11.485 11.484-.001 0-.002 0-.003 0-2.001-.001-3.97-.521-5.717-1.508L0 24zm6.002-4.058c1.62.963 3.203 1.487 4.88 1.488 5.276 0 9.57-4.293 9.573-9.569.001-2.556-1.002-4.959-2.81-6.772C15.824 3.264 13.435 2.25 10.913 2.25c-5.273 0-9.569 4.293-9.572 9.569-.001 1.761.482 3.39 1.402 4.869l-.997 3.637 3.734-.979zm11.007-6.621c-.301-.15-1.785-.881-2.062-.982-.278-.1-.48-.15-.682.15-.201.3-.778.981-.954 1.182-.176.201-.352.226-.653.075-.301-.15-1.272-.469-2.423-1.496-.895-.798-1.5-1.784-1.276-2.16.226-.376.024-.58-.126-.73-.135-.135-.301-.351-.452-.527-.15-.176-.201-.301-.301-.502-.1-.201-.05-.376.025-.527.075-.15.682-1.657.934-2.26.246-.588.497-.508.682-.518l.502-.01c.176 0 .462.065.703.327.241.261.92 2.261.996 2.412.075.15.126.327.025.527-.1.201-.15.327-.301.502-.15.176-.316.392-.452.527-.15.15-.307.315-.131.616.176.3.779 1.282 1.67 2.075.15.132.285.253.4.364.717.689 1.348.814 1.854.739.503-.075 1.785-.73 2.036-1.432.252-.703.252-1.306.176-1.432-.075-.126-.277-.201-.578-.352z" />
                      </svg>
                      <span>تأكيد الحجز عبر الواتساب</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setIsSubmitted(false)}
                      className="flex-shrink-0 py-4 border border-stone-800 hover:bg-stone-900 text-stone-300 hover:text-stone-100 font-bold rounded-xl transition-all text-sm px-6 cursor-pointer"
                    >
                      تعديل البيانات
                    </button>
                  </div>
                </div>
              )}

            </div>
            
            {/* Elegant Image display */}
            <div className="relative rounded-3xl overflow-hidden h-[240px] border border-stone-850 group">
              <img
                src={siteSettings?.eventsImageUrl || cateringImage}
                alt="تقديم الشواء المغربي في الأعراس"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#140E0A] via-transparent to-transparent"></div>
              
              <div className="absolute bottom-6 right-6 left-6">
                <h4 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block animate-pulse"></span>
                  خبرة تتوارثها الأجيال في طهي المشوي البلدي
                </h4>
                <p className="text-stone-300 text-xs mt-1 leading-relaxed">
                  نحن نهتم بأدق التفاصيل من الذبح إلى التزيين باللوز المقلي والبيض المسلوق والبرقوق المعسل على النمط الملكي الفاخر.
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
