import React, { useState } from 'react';
import { X, Calendar, Flame, Truck, DollarSign, MessageCircle, ClipboardCheck, Timer } from 'lucide-react';
import { OrderDetails, EventBookingRequest } from '../types';

interface MyReservationsProps {
  isOpen: boolean;
  onClose: () => void;
  orders: OrderDetails[];
  bookings: EventBookingRequest[];
}

export default function MyReservations({ isOpen, onClose, orders, bookings }: MyReservationsProps) {
  const [activeTab, setActiveTab] = useState<'orders' | 'bookings'>('orders');

  if (!isOpen) return null;

  const handleWhatsAppOrderInquiry = (order: OrderDetails) => {
    const text = `السلام عليكم، أريد الاستفسار عن حالة طلبي ذو المعرف *${order.id}*.\n` +
                 `*الاسم:* ${order.customerName}\n` +
                 `*التكلفة الإجمالية:* ${order.total} درهم مغربي.\n` +
                 `هل الطلب قيد التحضير حالياً؟ شكراً لكم!`;
    window.open(`https://wa.me/212717301089?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleWhatsAppBookingInquiry = (booking: EventBookingRequest) => {
    const text = `السلام عليكم، أريد الاستفسار عن حالة طلبي لحجز مناسبة السعيدة (زفاف/عرس/عقيقة) ذو المعرف *${booking.id}*.\n` +
                 `*التاريخ المقدر:* ${booking.eventDate}\n` +
                 `*المدينة:* ${booking.eventLocation}\n` +
                 `*عدد الخرفان:* ${booking.estimatedLambsNeeded} خروف مشوي\n` +
                 `هل التاريخ متاح وهل تم التحقق من العربون؟ شكراً لكم!`;
    window.open(`https://wa.me/212717301089?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end p-0 bg-black/85 backdrop-blur-md animate-fade-in font-sans text-right">
      <div className="bg-[#0B0806] border-l border-[#2D1B12] w-full max-w-lg h-full flex flex-col shadow-2xl animate-slide-in">
        
        {/* Header */}
        <div className="p-6 border-b border-[#2D1B12] flex items-center justify-between">
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-amber-400 rounded-full hover:bg-stone-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-amber-500" />
            <h2 className="font-serif text-lg sm:text-xl font-bold text-stone-100">سجل طلباتي وحجوزاتي</h2>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-2 bg-[#18110D] p-1 border-b border-[#2D1B12]">
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 text-center text-xs font-bold transition-all relative cursor-pointer ${
              activeTab === 'orders'
                ? 'text-amber-500 font-extrabold'
                : 'text-stone-400 hover:text-stone-100'
            }`}
          >
            <span>طلبات الشواء الساخن ({orders.length})</span>
            {activeTab === 'orders' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500"></span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('bookings')}
            className={`py-3 text-center text-xs font-bold transition-all relative cursor-pointer ${
              activeTab === 'bookings'
                ? 'text-amber-500 font-extrabold'
                : 'text-stone-400 hover:text-stone-100'
            }`}
          >
            <span>حجوزات الأعراس والمناسبات ({bookings.length})</span>
            {activeTab === 'bookings' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500"></span>
            )}
          </button>
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          
          {activeTab === 'orders' ? (
            /* ORDERS TAB */
            orders.length === 0 ? (
              <div className="text-center py-20">
                <Flame className="w-12 h-12 text-stone-800 mx-auto mb-3" />
                <p className="text-stone-300 text-xs">لا توجد طلبات شواء سابقة حالياً.</p>
                <p className="text-stone-500 text-[10px] mt-1">عند شرائك اللحم بالكيلو ستظهر تفاصيل الطبخ والتوصيل هنا.</p>
              </div>
            ) : (
              orders.map((order) => (
                <div key={order.id} className="bg-[#140E0A] border border-[#2D1B12] rounded-2xl p-5 space-y-3 shadow-sm text-right">
                  <div className="flex justify-between items-start border-b border-stone-850 pb-2 mb-2">
                    <div>
                      <span className="text-[10px] text-stone-450 block">رقم طلب الشواء</span>
                      <span className="text-stone-100 font-sans font-bold block">{order.id}</span>
                    </div>
                    <span className="bg-amber-950/30 text-amber-500 text-[10px] px-2 py-1 rounded-full flex items-center gap-1 font-bold">
                      <Timer className="w-3.5 h-3.5 animate-spin" />
                      جاري التحضير
                    </span>
                  </div>

                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-stone-400">التاريخ:</span>
                      <span className="text-stone-100 font-sans">{order.createdAt}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">طريقة التوصيل:</span>
                      <span className="text-stone-100">
                        {order.deliveryMethod === 'delivery' ? `توصيل منزلي لـ ${order.city}` : 'استلام من الفرع الرئيسي'}
                      </span>
                    </div>
                    <div className="flex justify-between font-bold border-t border-stone-850 pt-2 mt-2">
                      <span className="text-stone-400">القيمة الإجمالية:</span>
                      <span className="text-amber-400 font-sans">{order.total} درهم</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleWhatsAppOrderInquiry(order)}
                    className="w-full mt-3 py-2 bg-emerald-950/30 hover:bg-emerald-900/30 text-emerald-400 font-bold rounded-lg border border-emerald-500/30 hover:border-emerald-500/50 text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>تتبع الطلب مباشرة على الواتساب</span>
                  </button>
                </div>
              ))
            )
          ) : (
            /* EVENT BOOKINGS TAB */
            bookings.length === 0 ? (
              <div className="text-center py-20">
                <Calendar className="w-12 h-12 text-stone-800 mx-auto mb-3" />
                <p className="text-stone-300 text-xs">لا توجد حجوزات مناسبات سابقة حالياً.</p>
                <p className="text-stone-500 text-[10px] mt-1">عند تقديمك لطلب حجز عرس أو عقيقة سيتم حفظه ومتابعته هنا.</p>
              </div>
            ) : (
              bookings.map((booking) => (
                <div key={booking.id} className="bg-[#140E0A] border border-[#2D1B12] rounded-2xl p-5 space-y-3 shadow-sm text-right">
                  <div className="flex justify-between items-start border-b border-stone-850 pb-2 mb-2">
                    <div>
                      <span className="text-[10px] text-stone-450 block">رقم الحجز الفخم</span>
                      <span className="text-stone-100 font-sans font-bold block">{booking.id}</span>
                    </div>
                    <span className="bg-emerald-950/30 text-emerald-400 text-[10px] px-2 py-1 rounded-full flex items-center gap-1 font-bold">
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      مُسجل بالانتظار
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-stone-400">نوع الحفل السعيد:</span>
                      <span className="text-stone-100 font-bold">
                        {booking.eventType === 'wedding' && '💍 حفل زفاف / عرس مغربي'}
                        {booking.eventType === 'aqeeqah' && '👶 سبوع / عقيقة مباركة'}
                        {booking.eventType === 'family' && '🏡 لمة عائلية / خطوبة'}
                        {booking.eventType === 'corporate' && '👔 مأدبة شركات ورجال أعمال'}
                        {booking.eventType === 'other' && '✨ مناسبات خاصة أخرى'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">تاريخ الحفل:</span>
                      <span className="text-stone-100 font-sans">{booking.eventDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">عدد الضيوف والخدمة:</span>
                      <span className="text-stone-100 font-bold">
                        {booking.guestCount} شخص • {booking.estimatedLambsNeeded} خروف مشوي
                      </span>
                    </div>
                    <div className="flex justify-between font-bold border-t border-stone-850 pt-2 mt-2">
                      <span className="text-stone-400">السعر التقديري للمشوي:</span>
                      <span className="text-amber-400 font-sans">{booking.totalEstimatedPrice} درهم</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleWhatsAppBookingInquiry(booking)}
                    className="w-full mt-3 py-2 bg-emerald-950/30 hover:bg-emerald-900/30 text-emerald-400 font-bold rounded-lg border border-emerald-500/30 hover:border-emerald-500/50 text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>تأكيد تاريخ الحفل عبر الواتساب</span>
                  </button>
                </div>
              ))
            )
          )}

        </div>

        {/* Footer info inside portal */}
        <div className="p-4 bg-[#140E0A] border-t border-[#2D1B12] text-center text-[10px] text-stone-500 leading-relaxed font-sans">
          🔐 يتم حفظ هذه البيانات محلياً على متصفحك للحفاظ على خصوصيتك.
          <br />
          الشواء المغربي الأصيل © 2026
        </div>

      </div>
    </div>
  );
}
