import React, { useState } from 'react';
import { X, Upload, Check, Sparkles, Image as ImageIcon } from 'lucide-react';
import { SideItem } from '../../types';
import { MOROCCAN_FOOD_PRESETS } from '../../data';

interface AdminProductModalProps {
  isOpen: boolean;
  editingProduct: SideItem | null;
  productForm: Partial<SideItem>;
  setProductForm: React.Dispatch<React.SetStateAction<Partial<SideItem>>>;
  onSave: (e: React.FormEvent) => void;
  onClose: () => void;
  isSaving: boolean;
}

export default function AdminProductModal({
  isOpen,
  editingProduct,
  productForm,
  setProductForm,
  onSave,
  onClose,
  isSaving,
}: AdminProductModalProps) {
  const [uploadError, setUploadError] = useState('');

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setUploadError('حجم الصورة أكبر من 2 ميغابايت. يرجى اختيار صورة أصغر أو استخدام رابط مباشر.');
      return;
    }

    setUploadError('');
    const reader = new FileReader();
    reader.onloadend = () => {
      setProductForm(prev => ({ ...prev, image: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleApplyPreset = (preset: typeof MOROCCAN_FOOD_PRESETS[0]) => {
    setProductForm(prev => ({
      ...prev,
      name: preset.name,
      price: preset.price,
      category: preset.category as any,
      description: preset.desc,
      image: preset.url,
    }));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-stone-900 border border-stone-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-stone-800 mb-4">
          <div>
            <h4 className="text-base font-bold text-stone-100">
              {editingProduct ? 'تعديل طبق / منتوج' : 'إضافة طبق جديد للمنيو'}
            </h4>
            <p className="text-xs text-stone-400 mt-0.5">
              أدخل اسم الطبق، الثمن، صورته ووصفه ليظهر مباشرة للزبائن في الموقع
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Moroccan Preset Quick Fill */}
        <div className="mb-5 bg-amber-950/20 border border-amber-900/30 rounded-xl p-3">
          <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            اختيار سريع من أشهر أطباق المشوي والضيافة المغربية:
          </span>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
            {MOROCCAN_FOOD_PRESETS.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplyPreset(preset)}
                className="flex items-center gap-2 bg-[#18110D] hover:bg-amber-900/40 border border-[#2D1B12] hover:border-amber-700/60 rounded-lg px-2.5 py-1.5 text-xs text-stone-300 hover:text-amber-300 transition-all flex-shrink-0 cursor-pointer text-right"
              >
                <img 
                  src={preset.url} 
                  alt={preset.name} 
                  className="w-6 h-6 rounded-md object-cover flex-shrink-0"
                  referrerPolicy="no-referrer"
                />
                <span className="truncate max-w-[110px]">{preset.name}</span>
                <span className="text-amber-400 font-bold">{preset.price}د</span>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={onSave} className="space-y-4">
          <div>
            <label className="block text-xs text-stone-300 mb-1 font-bold">اسم الطبق أو المنتوج *:</label>
            <input
              type="text"
              required
              value={productForm.name || ''}
              onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
              placeholder="مثال: قطبان لحم الغنمي البلدي المتبل"
              className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-sm outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-stone-300 mb-1 font-bold">السعر بالدرهم (MAD) *:</label>
              <input
                type="number"
                required
                min="1"
                value={productForm.price || ''}
                onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-amber-400 font-bold text-sm outline-none font-sans"
              />
            </div>

            <div>
              <label className="block text-xs text-stone-300 mb-1 font-bold">التصنيف:</label>
              <select
                value={productForm.category || 'sides'}
                onChange={(e) => setProductForm({ ...productForm, category: e.target.value as any })}
                className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-200 text-sm outline-none"
              >
                <option value="meat">شواء ولحوم بلدية</option>
                <option value="platters">أطباق فاخرة وضيافة</option>
                <option value="sides">مقبلات ومرافقات</option>
                <option value="salads">سلطات مغربية</option>
                <option value="drinks">مشروبات وأتاي بالنعناع</option>
              </select>
            </div>
          </div>

          {/* Dish Image: File upload & URL input */}
          <div className="bg-stone-950/60 border border-stone-800 rounded-xl p-3.5 space-y-3">
            <label className="block text-xs text-stone-300 font-bold">
              صورة الطبق (رابط صورة أو رفع من هاتفك/حاسوبك):
            </label>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="url"
                value={productForm.image || ''}
                onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                placeholder="https://images.unsplash.com/... أو ارفع ملف أدناه"
                className="flex-1 bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-3 py-2 text-stone-200 text-xs outline-none"
              />

              <label className="inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium rounded-xl cursor-pointer transition-colors whitespace-nowrap">
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span>رفع من الجهاز</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {uploadError && (
              <p className="text-[11px] text-red-400">{uploadError}</p>
            )}

            {/* Image Preview */}
            {productForm.image ? (
              <div className="flex items-center gap-3 bg-[#120B08] p-2 rounded-xl border border-[#2D1B12]">
                <img
                  src={productForm.image}
                  alt="معاينة الطبق"
                  className="w-14 h-14 rounded-lg object-cover border border-amber-900/40"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    تم تحديد صورة الطبق بنجاح
                  </span>
                  <button
                    type="button"
                    onClick={() => setProductForm({ ...productForm, image: '' })}
                    className="text-[10px] text-red-400 hover:underline mt-1 cursor-pointer block"
                  >
                    إزالة الصورة
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-[10px] text-stone-500">
                ملاحظة: إذا تركت الصورة فارغة سيتم عرض أيقونة شواء مغربي افتراضية.
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs text-stone-300 mb-1 font-bold">الوصف والمكونات:</label>
            <textarea
              rows={2}
              value={productForm.description || ''}
              onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
              placeholder="وصف مكونات الطبق، التوابل، طريقة التقديم..."
              className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2 text-stone-200 text-xs outline-none resize-none"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="isAvailable"
              checked={productForm.isAvailable !== false}
              onChange={(e) => setProductForm({ ...productForm, isAvailable: e.target.checked })}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
            <label htmlFor="isAvailable" className="text-xs text-stone-300 cursor-pointer">
              المنتوج متوفر حالياً للطلب على الموقع
            </label>
          </div>

          <div className="pt-4 border-t border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-stone-400 hover:text-stone-200 text-xs transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{isSaving ? 'جاري الحفظ...' : 'حفظ الطبق في قاعدة البيانات'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
