import React, { useState } from 'react';
import { 
  Camera, Upload, Save, Check, Trash2, Plus, Sparkles, Image as ImageIcon, 
  ExternalLink, Eye, RefreshCw, Star
} from 'lucide-react';
import { SiteSettings, GalleryImage } from '../../types';
import { updateSiteSettings } from '../../firebase';
import heroImageDefault from '../../assets/images/moroccan_mechoui_hero_1783196824771.jpg';
import cateringImageDefault from '../../assets/images/moroccan_wedding_catering_1783196853669.jpg';
import skewersImageDefault from '../../assets/images/moroccan_skewers_grill_1783196840332.jpg';

interface AdminImagesTabProps {
  siteSettings: SiteSettings;
  onSettingsUpdated?: () => void;
}

const MOROCCAN_IMAGE_PRESETS = [
  {
    name: 'خروف مشوي بلدي كامل',
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
    category: 'مشوي بلدي'
  },
  {
    name: 'قطبان لحم على الفحم',
    url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1200&q=80',
    category: 'قطبان وكباب'
  },
  {
    name: 'وليمة أعراس بأواني فضية',
    url: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=1200&q=80',
    category: 'أعراس ومناسبات'
  },
  {
    name: 'طاجين اللحم بالبرقوق واللوز',
    url: 'https://images.unsplash.com/photo-1574484284002-952d92456975?auto=format&fit=crop&w=1200&q=80',
    category: 'أطباق فاخرة'
  },
  {
    name: 'طنجية مراكشية فخارية',
    url: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=1200&q=80',
    category: 'مشوي بلدي'
  },
  {
    name: 'شاي مغربي أصيل بالنعناع',
    url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=1200&q=80',
    category: 'مقبلات ومشروبات'
  }
];

export default function AdminImagesTab({ siteSettings, onSettingsUpdated }: AdminImagesTabProps) {
  // Main images local state
  const [heroUrl, setHeroUrl] = useState<string>(siteSettings.heroImageUrl || '');
  const [eventsUrl, setEventsUrl] = useState<string>(siteSettings.eventsImageUrl || '');
  const [skewersUrl, setSkewersUrl] = useState<string>(siteSettings.skewersImageUrl || '');

  // Add gallery image state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('مشوي بلدي');
  const [newUrl, setNewUrl] = useState('');

  // Status & loading state
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [previewModalUrl, setPreviewModalUrl] = useState<string | null>(null);

  // Sync when prop updates
  React.useEffect(() => {
    setHeroUrl(siteSettings.heroImageUrl || '');
    setEventsUrl(siteSettings.eventsImageUrl || '');
    setSkewersUrl(siteSettings.skewersImageUrl || '');
  }, [siteSettings]);

  const showNotification = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(''), 3500);
  };

  // Helper for file reader
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setter: (url: string) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2.5 * 1024 * 1024) {
      alert('حجم الصورة كبير جداً (أكثر من 2.5 ميغابايت). يرجى اختيار صورة بحجم أصغر أو استخدام رابط مباشر.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setter(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Save main site images
  const handleSaveMainImages = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const updated: SiteSettings = {
        ...siteSettings,
        heroImageUrl: heroUrl.trim(),
        eventsImageUrl: eventsUrl.trim(),
        skewersImageUrl: skewersUrl.trim(),
      };
      await updateSiteSettings(updated);
      showNotification('تم تحديث صور الموقع بنجاح!');
      if (onSettingsUpdated) onSettingsUpdated();
    } catch (err) {
      alert('حدث خطأ أثناء حفظ الصور في قاعدة البيانات');
    } finally {
      setIsSaving(false);
    }
  };

  // Add new image to gallery
  const handleAddGalleryImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUrl.trim()) {
      alert('المرجو كتابة رابط الصورة أو رفع ملف من جهازك.');
      return;
    }

    setIsSaving(true);
    try {
      const newImg: GalleryImage = {
        id: `gal_${Date.now()}`,
        url: newUrl.trim(),
        title: newTitle.trim() || 'شواء مغربي أصيل',
        category: newCategory,
      };

      const updatedGallery = [newImg, ...(siteSettings.galleryImages || [])];
      const updatedSettings: SiteSettings = {
        ...siteSettings,
        galleryImages: updatedGallery,
      };

      await updateSiteSettings(updatedSettings);
      setNewTitle('');
      setNewUrl('');
      showNotification('تمت إضافة الصورة بنجاح إلى المعرض!');
      if (onSettingsUpdated) onSettingsUpdated();
    } catch (err) {
      alert('حدث خطأ أثناء إضافة الصورة');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete image from gallery
  const handleDeleteGalleryImage = async (id: string) => {
    if (!window.confirm('هل أنت متأكد من حذف هذه الصورة من المعرض؟')) return;

    setIsSaving(true);
    try {
      const updatedGallery = (siteSettings.galleryImages || []).filter(img => img.id !== id);
      const updatedSettings: SiteSettings = {
        ...siteSettings,
        galleryImages: updatedGallery,
      };

      await updateSiteSettings(updatedSettings);
      showNotification('تم حذف الصورة من المعرض');
      if (onSettingsUpdated) onSettingsUpdated();
    } catch (err) {
      alert('حدث خطأ أثناء الحذف');
    } finally {
      setIsSaving(false);
    }
  };

  // Quick set image as Hero
  const handleSetAsHero = async (url: string) => {
    setHeroUrl(url);
    setIsSaving(true);
    try {
      const updatedSettings: SiteSettings = {
        ...siteSettings,
        heroImageUrl: url,
      };
      await updateSiteSettings(updatedSettings);
      showNotification('تم تعيين الصورة كخلفية رئيسية لواجهة الموقع (الهيرو)!');
      if (onSettingsUpdated) onSettingsUpdated();
    } catch (err) {
      alert('حدث خطأ أثناء التحديث');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-8">
      
      {/* Header banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-stone-900/80 border border-stone-800 p-6 rounded-2xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
            <Camera className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-stone-100">إدارة الصور والمعرض</h3>
            <p className="text-xs text-stone-400">تغيير صور الموقع الرئيسية، إضافة صور جديدة للشواء، وإدارة المعرض</p>
          </div>
        </div>

        {successMessage && (
          <div className="bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 text-xs px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 animate-fade-in">
            <Check className="w-4 h-4" />
            <span>{successMessage}</span>
          </div>
        )}
      </div>

      {/* SECTION 1: MAIN SITE IMAGES */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-6">
        <div className="border-b border-stone-800 pb-4 mb-6">
          <h4 className="text-base font-bold text-stone-100 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            الصور الأساسية للموقع (الهيرو، الأعراس، الشواء)
          </h4>
          <p className="text-xs text-stone-400 mt-1">
            يمكنك رفع صورة من هاتفك أو حاسوبك، أو وضع رابط مباشر، أو الاختيار من الصور المقترحة
          </p>
        </div>

        <form onSubmit={handleSaveMainImages} className="space-y-6">
          
          {/* Hero Background Image */}
          <div className="bg-stone-950/70 border border-stone-800/80 rounded-2xl p-4 sm:p-5">
            <div className="flex flex-col lg:flex-row items-start gap-5">
              <div className="relative w-full lg:w-48 h-32 rounded-xl overflow-hidden border border-amber-900/40 flex-shrink-0 group">
                <img
                  src={heroUrl || heroImageDefault}
                  alt="معاينة صورة الهيرو"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    type="button"
                    onClick={() => setPreviewModalUrl(heroUrl || heroImageDefault)}
                    className="p-1.5 bg-black/70 rounded-lg text-white hover:text-amber-400"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
                <span className="absolute bottom-2 right-2 text-[10px] bg-black/70 text-amber-400 px-2 py-0.5 rounded font-bold">
                  صورة الهيرو
                </span>
              </div>

              <div className="flex-1 w-full space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-stone-200">
                    صورة خلفية واجهة الموقع الرئيسية (الهيرو):
                  </label>
                  {heroUrl && (
                    <button
                      type="button"
                      onClick={() => setHeroUrl('')}
                      className="text-[11px] text-stone-400 hover:text-amber-400"
                    >
                      استعادة الصورة الافتراضية
                    </button>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={heroUrl}
                    onChange={(e) => setHeroUrl(e.target.value)}
                    placeholder="رابط الصورة (URL) أو ارفع ملف أدناه..."
                    className="flex-1 bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
                  />
                  <label className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium rounded-xl cursor-pointer transition-colors whitespace-nowrap">
                    <Upload className="w-3.5 h-3.5 text-amber-400" />
                    <span>رفع من الجهاز</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, setHeroUrl)}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Moroccan Presets Quick Pick for Hero */}
                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  <span className="text-[10px] text-stone-400">اقتراحات سريعة:</span>
                  {MOROCCAN_IMAGE_PRESETS.slice(0, 3).map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setHeroUrl(preset.url)}
                      className="text-[10px] bg-stone-900 hover:bg-amber-950/60 border border-stone-800 hover:border-amber-900/50 text-stone-300 hover:text-amber-300 px-2 py-1 rounded-lg transition-colors cursor-pointer"
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Events Catering Image */}
          <div className="bg-stone-950/70 border border-stone-800/80 rounded-2xl p-4 sm:p-5">
            <div className="flex flex-col lg:flex-row items-start gap-5">
              <div className="relative w-full lg:w-48 h-32 rounded-xl overflow-hidden border border-amber-900/40 flex-shrink-0 group">
                <img
                  src={eventsUrl || cateringImageDefault}
                  alt="معاينة صورة الأعراس"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-2 right-2 text-[10px] bg-black/70 text-amber-400 px-2 py-0.5 rounded font-bold">
                  قسم الأعراس
                </span>
              </div>

              <div className="flex-1 w-full space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-stone-200">
                    صورة قسم الأعراس والولائم الفاخرة:
                  </label>
                  {eventsUrl && (
                    <button
                      type="button"
                      onClick={() => setEventsUrl('')}
                      className="text-[11px] text-stone-400 hover:text-amber-400"
                    >
                      استعادة الصورة الافتراضية
                    </button>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={eventsUrl}
                    onChange={(e) => setEventsUrl(e.target.value)}
                    placeholder="رابط الصورة (URL) أو ارفع ملف أدناه..."
                    className="flex-1 bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
                  />
                  <label className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium rounded-xl cursor-pointer transition-colors whitespace-nowrap">
                    <Upload className="w-3.5 h-3.5 text-amber-400" />
                    <span>رفع من الجهاز</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, setEventsUrl)}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Skewers Barbecue Image */}
          <div className="bg-stone-950/70 border border-stone-800/80 rounded-2xl p-4 sm:p-5">
            <div className="flex flex-col lg:flex-row items-start gap-5">
              <div className="relative w-full lg:w-48 h-32 rounded-xl overflow-hidden border border-amber-900/40 flex-shrink-0 group">
                <img
                  src={skewersUrl || skewersImageDefault}
                  alt="معاينة صورة قسم الشواء"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-2 right-2 text-[10px] bg-black/70 text-amber-400 px-2 py-0.5 rounded font-bold">
                  قسم الشواء بالكيلو
                </span>
              </div>

              <div className="flex-1 w-full space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-stone-200">
                    صورة قسم طلب الشواء بالكيلوغرام والقطبان:
                  </label>
                  {skewersUrl && (
                    <button
                      type="button"
                      onClick={() => setSkewersUrl('')}
                      className="text-[11px] text-stone-400 hover:text-amber-400"
                    >
                      استعادة الصورة الافتراضية
                    </button>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={skewersUrl}
                    onChange={(e) => setSkewersUrl(e.target.value)}
                    placeholder="رابط الصورة (URL) أو ارفع ملف أدناه..."
                    className="flex-1 bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
                  />
                  <label className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium rounded-xl cursor-pointer transition-colors whitespace-nowrap">
                    <Upload className="w-3.5 h-3.5 text-amber-400" />
                    <span>رفع من الجهاز</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, setSkewersUrl)}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <button
              type="submit"
              disabled={isSaving}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-6 py-2.5 rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer text-xs sm:text-sm"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'جاري الحفظ...' : 'حفظ صور الموقع الرئيسية'}</span>
            </button>
          </div>

        </form>
      </div>

      {/* SECTION 2: ADD NEW IMAGE TO GALLERY */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-6">
        <div className="border-b border-stone-800 pb-4 mb-6">
          <h4 className="text-base font-bold text-stone-100 flex items-center gap-2">
            <Plus className="w-4 h-4 text-amber-400" />
            إضافة صورة جديدة إلى معرض الموقع
          </h4>
          <p className="text-xs text-stone-400 mt-1">
            أضف صور أطباقك وولائمك الجديدة لتظهر في المعرض الفاخر لجميع الزوار
          </p>
        </div>

        <form onSubmit={handleAddGalleryImage} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                عنوان أو وصف الصورة *:
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="مثال: خروف مشوي بلدي مزين باللوز والبيض"
                className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                تصنيف الصورة:
              </label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-200 text-xs outline-none"
              >
                <option value="مشوي بلدي">مشوي بلدي</option>
                <option value="قطبان وكباب">قطبان وكباب</option>
                <option value="أعراس ومناسبات">أعراس ومناسبات</option>
                <option value="أطباق فاخرة">أطباق فاخرة</option>
                <option value="مقبلات ومشروبات">مقبلات ومشروبات</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-bold text-stone-300">
              صورة المعرض (رابط مباشر أو رفع من الجهاز) *:
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                placeholder="https://... أو انقر رفع من الجهاز"
                className="flex-1 bg-stone-950 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
              <label className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium rounded-xl cursor-pointer transition-colors whitespace-nowrap">
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span>رفع من الجهاز</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileChange(e, setNewUrl)}
                  className="hidden"
                />
              </label>
            </div>

            {/* Presets to pick from */}
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <span className="text-[10px] text-stone-400">أو اختر من النماذج الجاهزة:</span>
              {MOROCCAN_IMAGE_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setNewUrl(preset.url);
                    setNewTitle(preset.name);
                    setNewCategory(preset.category);
                  }}
                  className="text-[10px] bg-stone-950 hover:bg-amber-950/60 border border-stone-800 text-stone-300 hover:text-amber-300 px-2 py-1 rounded-lg transition-colors cursor-pointer"
                >
                  {preset.name}
                </button>
              ))}
            </div>

            {/* Preview of new image */}
            {newUrl && (
              <div className="flex items-center gap-3 bg-stone-950 p-3 rounded-xl border border-stone-800 mt-2">
                <img
                  src={newUrl}
                  alt="معاينة الصورة الجديدة"
                  className="w-16 h-16 rounded-lg object-cover border border-amber-900/40"
                  referrerPolicy="no-referrer"
                />
                <div className="text-xs">
                  <span className="text-emerald-400 font-bold block">✓ الصورة جاهزة للإضافة</span>
                  <span className="text-stone-400 text-[11px]">{newTitle || 'بدون عنوان'} ({newCategory})</span>
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{isSaving ? 'جاري الإضافة...' : 'إضافة الصورة إلى المعرض الآن'}</span>
          </button>
        </form>
      </div>

      {/* SECTION 3: CURRENT GALLERY IMAGES LIST */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-6">
        <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-6">
          <div>
            <h4 className="text-base font-bold text-stone-100 flex items-center gap-2">
              <Camera className="w-4 h-4 text-amber-400" />
              صور المعرض الحالية في الموقع
            </h4>
            <p className="text-xs text-stone-400 mt-1">
              الصور المعروضة في قسم المعرض مع إمكانية حذف أي صورة أو تعيينها كصورة الهيرو
            </p>
          </div>
          <span className="text-xs bg-stone-800 text-stone-300 px-2.5 py-1 rounded-full font-bold">
            {(siteSettings.galleryImages || []).length} صورة
          </span>
        </div>

        {(siteSettings.galleryImages || []).length === 0 ? (
          <div className="text-center py-10 bg-stone-950/40 rounded-xl border border-dashed border-stone-800">
            <Camera className="w-10 h-10 text-stone-600 mx-auto mb-2" />
            <p className="text-stone-400 text-xs">لا توجد صور مخصصة حالياً. المعرض يستخدم الصور التراثية الافتراضية.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(siteSettings.galleryImages || []).map((img) => (
              <div
                key={img.id}
                className="bg-stone-950 rounded-2xl border border-stone-800 overflow-hidden flex flex-col justify-between group"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={img.url}
                    alt={img.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 right-2">
                    <span className="bg-black/75 text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-900/40">
                      {img.category || 'أطباق فاخرة'}
                    </span>
                  </div>
                </div>

                <div className="p-3.5 flex flex-col justify-between flex-1">
                  <h5 className="text-stone-100 font-bold text-xs truncate mb-3" title={img.title}>
                    {img.title}
                  </h5>

                  <div className="flex items-center justify-between pt-2 border-t border-stone-800/80 gap-2">
                    <button
                      type="button"
                      onClick={() => handleSetAsHero(img.url)}
                      className="text-[10px] bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800/40 text-amber-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      title="تعيين كخلفية الهيرو في الواجهة"
                    >
                      <Star className="w-3 h-3" />
                      <span>تعيين كهيرو</span>
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setPreviewModalUrl(img.url)}
                        className="p-1 text-stone-400 hover:text-white hover:bg-stone-800 rounded-lg transition-colors"
                        title="معاينة كاملة"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteGalleryImage(img.id)}
                        className="p-1 text-stone-400 hover:text-red-400 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
                        title="حذف من المعرض"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* Lightbox Preview Modal */}
      {previewModalUrl && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setPreviewModalUrl(null)}
        >
          <div className="relative max-w-3xl w-full bg-stone-900 rounded-2xl overflow-hidden border border-stone-800 p-2">
            <img
              src={previewModalUrl}
              alt="معاينة مكبرة"
              className="w-full max-h-[80vh] object-contain rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      )}

    </div>
  );
}
