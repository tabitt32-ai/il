import React, { useState } from 'react';
import { Settings, Save, Check, Type, Sparkles, MessageSquare, Phone, Info } from 'lucide-react';
import { SiteSettings } from '../../types';
import { updateSiteSettings } from '../../firebase';

interface AdminTextsTabProps {
  siteSettings: SiteSettings;
  onSettingsUpdated?: () => void;
}

export default function AdminTextsTab({ siteSettings, onSettingsUpdated }: AdminTextsTabProps) {
  const [form, setForm] = useState<SiteSettings>(siteSettings);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  React.useEffect(() => {
    setForm(siteSettings);
  }, [siteSettings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateSiteSettings(form);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3500);
      if (onSettingsUpdated) onSettingsUpdated();
    } catch (err) {
      alert('حدث خطأ أثناء حفظ نصوص وإعدادات الصفحة');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6">
      <div className="max-w-4xl bg-stone-900/80 border border-stone-800 rounded-2xl p-6">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-800 pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Type className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-100">تعديل نصوص وفقرات الموقع</h3>
              <p className="text-xs text-stone-400">
                تحكم في العناوين، الشارات، وفقرات الهيرو، المزايا، الأعراس، والتواصل
              </p>
            </div>
          </div>

          {saveSuccess && (
            <div className="bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 text-xs px-4 py-2 rounded-xl font-bold flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>تم حفظ جميع النصوص بنجاح!</span>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          
          {/* 1. HERO SECTION TEXTS */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-bold text-stone-200">نصوص واجهة الهيرو (القسم الرئيسي في أعلى الموقع)</h4>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                شارة الهيرو العلوية (Badge):
              </label>
              <input
                type="text"
                value={form.heroBadge || ''}
                onChange={(e) => setForm({ ...form, heroBadge: e.target.value })}
                placeholder="عراقة الضيافة والأصالة المغربية"
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                العنوان الرئيسي العريض للهيرو (Title):
              </label>
              <input
                type="text"
                value={form.heroTitle || ''}
                onChange={(e) => setForm({ ...form, heroTitle: e.target.value })}
                placeholder="المشوي المغربي التقليدي على أصوله الفاخرة"
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-sm font-serif font-bold outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                الفقرة التوضيحية للهيرو (Subtitle):
              </label>
              <textarea
                rows={3}
                value={form.heroSubtitle || ''}
                onChange={(e) => setForm({ ...form, heroSubtitle: e.target.value })}
                placeholder="تذوق طعم الفخامة البلدية في بيتك. نحضر لكم أجود خرفان الغنمي البلدية، مطبوخة ببطء على الجمر الهادئ..."
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl p-3 text-stone-200 text-xs outline-none resize-none leading-relaxed"
              />
            </div>
          </div>

          {/* 2. BENEFITS SECTION TEXTS */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
              <Info className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-bold text-stone-200">نصوص قسم سر المذاق ومزايا الشواء البلدي</h4>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                عنوان قسم المزايا:
              </label>
              <input
                type="text"
                value={form.benefitsTitle || ''}
                onChange={(e) => setForm({ ...form, benefitsTitle: e.target.value })}
                placeholder="لماذا يفضلنا عشاق الشواء المغربي؟"
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                وصف وشرح قسم المزايا:
              </label>
              <textarea
                rows={2}
                value={form.benefitsSubtitle || ''}
                onChange={(e) => setForm({ ...form, benefitsSubtitle: e.target.value })}
                placeholder="نلتزم بأدق التقاليد المغربية الأصيلة المتوارثة عن أجدادنا لنضمن لك لحماً غنياً بالنكهات ومطهواً بعناية فائقة."
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl p-3 text-stone-200 text-xs outline-none resize-none"
              />
            </div>
          </div>

          {/* 3. EVENTS CATERING SECTION TEXTS */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-bold text-stone-200">نصوص قسم الأعراس والمناسبات والولائم</h4>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                عنوان قسم الأعراس:
              </label>
              <input
                type="text"
                value={form.eventsTitle || ''}
                onChange={(e) => setForm({ ...form, eventsTitle: e.target.value })}
                placeholder="المشوي المغربي للأعراس والمناسبات"
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                وصف خدمات الأعراس والولائم:
              </label>
              <textarea
                rows={2}
                value={form.eventsSubtitle || ''}
                onChange={(e) => setForm({ ...form, eventsSubtitle: e.target.value })}
                placeholder="نجعل مناسباتكم حكايات لا تُنسى. نوفر طاقماً متكاملاً من أمهر معلمي الشواء لطهي الخرفان الكاملة..."
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl p-3 text-stone-200 text-xs outline-none resize-none"
              />
            </div>
          </div>

          {/* 4. FOOTER & ABOUT */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
              <Info className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-bold text-stone-200">نصوص تذييل الصفحة والتعريف بالمتجر (Footer)</h4>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">
                نبذة المتجر في التذييل (Footer Bio):
              </label>
              <textarea
                rows={2}
                value={form.footerBio || ''}
                onChange={(e) => setForm({ ...form, footerBio: e.target.value })}
                placeholder="المشوي المغربي الأصيل - تجربة شواء بلدي فاخر بخرفان الغنمي البلدية والتوابل الملكية."
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl p-3 text-stone-200 text-xs outline-none resize-none"
              />
            </div>
          </div>

          {/* 5. STORE INFO & CONTACTS */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
              <Phone className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-bold text-stone-200">معلومات الاتصال، المتجر، وشريط الإعلانات</h4>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">اسم المتجر / الموقع:</label>
              <input
                type="text"
                value={form.siteTitle || ''}
                onChange={(e) => setForm({ ...form, siteTitle: e.target.value })}
                placeholder="المشوي المغربي الأصيل"
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-300 mb-1">رقم الواتساب للطلبات (مع الرمز الدولي):</label>
                <input
                  type="text"
                  value={form.whatsappPhone || ''}
                  onChange={(e) => setForm({ ...form, whatsappPhone: e.target.value })}
                  placeholder="212600000000"
                  className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 font-mono text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-300 mb-1">رقم الهاتف الظاهر للمكالمات:</label>
                <input
                  type="text"
                  value={form.supportPhone || ''}
                  onChange={(e) => setForm({ ...form, supportPhone: e.target.value })}
                  placeholder="+212 6 00 00 00 00"
                  className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 font-mono text-xs outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1">شريط الإعلانات الترويجي العلوي:</label>
              <input
                type="text"
                value={form.announcement || ''}
                onChange={(e) => setForm({ ...form, announcement: e.target.value })}
                placeholder="توصيل ساخن ومجاني لجميع طلبات الشواء اليوم..."
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-stone-800 flex items-center gap-3">
            <button
              type="submit"
              disabled={isSaving}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-6 py-2.5 rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer text-xs sm:text-sm"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'جاري الحفظ...' : 'حفظ جميع نصوص وإعدادات الصفحة'}</span>
            </button>
            {saveSuccess && (
              <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                <Check className="w-4 h-4" />
                تم الحفظ وتحديث محتوى الموقع بنجاح!
              </span>
            )}
          </div>

        </form>
      </div>
    </div>
  );
}
