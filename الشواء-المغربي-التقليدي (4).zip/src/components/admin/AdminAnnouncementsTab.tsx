import React, { useState, useEffect } from 'react';
import { 
  Megaphone, Save, Check, Sparkles, Eye, ToggleLeft, ToggleRight, 
  Tag, Link2, AlertCircle, ArrowUpRight, Flame, Truck, Award, Clock
} from 'lucide-react';
import { SiteSettings } from '../../types';
import { updateSiteSettings } from '../../firebase';

interface AdminAnnouncementsTabProps {
  siteSettings: SiteSettings;
  onSettingsUpdated?: () => void;
}

export default function AdminAnnouncementsTab({ 
  siteSettings, 
  onSettingsUpdated 
}: AdminAnnouncementsTabProps) {
  const [announcementText, setAnnouncementText] = useState(siteSettings.announcement || '');
  const [isEnabled, setIsEnabled] = useState(siteSettings.announcementEnabled !== false);
  const [badge, setBadge] = useState(siteSettings.announcementBadge || '🔥 عرض خاص');
  const [linkTarget, setLinkTarget] = useState(siteSettings.announcementLink || '#order-meat');
  const [announcementType, setAnnouncementType] = useState<string>(siteSettings.announcementType || 'discount');

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync state when props update
  useEffect(() => {
    setAnnouncementText(siteSettings.announcement || '');
    setIsEnabled(siteSettings.announcementEnabled !== false);
    setBadge(siteSettings.announcementBadge || '🔥 عرض خاص');
    setLinkTarget(siteSettings.announcementLink || '#order-meat');
    setAnnouncementType(siteSettings.announcementType || 'discount');
  }, [siteSettings]);

  const quickBadges = [
    '🔥 عرض خاص',
    '🚚 توصيل مجاني',
    '🎉 باقة المناسبات',
    '⚡ تخفيض محدود',
    '✨ لحم بلدي 100%',
    '⭐ الأكثر طلباً',
    '📣 إعلان هام'
  ];

  const readyTemplates = [
    {
      title: 'عرض التوصيل المجاني للطلبيات',
      badge: '🚚 توصيل مجاني',
      text: 'توصيل ساخن ومجاني لجميع طلبيات المشوي التي تتجاوز 2 كيلوغرام في جميع أنحاء المدينة!',
      link: '#order-meat',
      type: 'discount'
    },
    {
      title: 'عرض مناسبات وأعراس فاخرة',
      badge: '🎉 باقة الأعراس',
      text: 'احجز طاقم الشواء التقليدي البلدي لمناسبتك الفاخرة واستفد من طاجين مقبلات وسلطات مغربية مجاناً!',
      link: '#events-catering',
      type: 'catering'
    },
    {
      title: 'تأكيد الجودة والطهي البلدي',
      badge: '✨ لحم بلدي 100%',
      text: 'لحوم خرفان بلدية معتمدة، مطبوخة ببطء على الجمر الهادئ لأكثر من 6 ساعات - جاهزة للتسليم الساخن فوراً.',
      link: '#order-meat',
      type: 'standard'
    },
    {
      title: 'ساعات العمل وتوفر الشواء الساخن',
      badge: '🔥 شواء ساخن الآن',
      text: 'نستقبل طلباتكم وحجوزاتكم يومياً من 11:30 صباحاً حتى 11:00 ليلاً مع توصيل حراري معقم لبيتك.',
      link: 'whatsapp',
      type: 'urgent'
    }
  ];

  const applyTemplate = (tpl: typeof readyTemplates[0]) => {
    setBadge(tpl.badge);
    setAnnouncementText(tpl.text);
    setLinkTarget(tpl.link);
    setAnnouncementType(tpl.type);
    setIsEnabled(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await updateSiteSettings({
        announcement: announcementText.trim(),
        announcementEnabled: isEnabled,
        announcementBadge: badge.trim(),
        announcementLink: linkTarget,
        announcementType: announcementType as any,
      });

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3500);
      if (onSettingsUpdated) onSettingsUpdated();
    } catch (err) {
      alert('حدث خطأ أثناء حفظ بيانات الإعلان');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6">
      <div className="max-w-4xl bg-stone-900/80 border border-stone-800 rounded-2xl p-6">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-800 pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Megaphone className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-stone-100 flex items-center gap-2">
                <span>تعديل الإعلانات والعروض الترويجية</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full font-sans">
                  Live Banner
                </span>
              </h3>
              <p className="text-xs text-stone-400">
                تحكم في الشريط الترويجي والإعلانات التي تظهر أعلى صفحات المتجر لكافة الزبائن
              </p>
            </div>
          </div>

          {saveSuccess && (
            <div className="bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 text-xs px-4 py-2 rounded-xl font-bold flex items-center gap-2 animate-fade-in">
              <Check className="w-4 h-4" />
              <span>تم تحديث الإعلان على المتجر مباشرة!</span>
            </div>
          )}
        </div>

        {/* Live Preview Box */}
        <div className="mb-8 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-amber-400" />
              <span>معاينة حية لشريط الإعلانات كما يظهر للزبون في أعلى الموقع:</span>
            </span>
            <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold border ${
              isEnabled 
                ? 'bg-emerald-950 text-emerald-400 border-emerald-800' 
                : 'bg-stone-800 text-stone-400 border-stone-700'
            }`}>
              {isEnabled ? '● ظاهر الآن للزوار' : '○ متوقف ومخفي عن الزوار'}
            </span>
          </div>

          <div className="rounded-xl overflow-hidden border border-stone-800 bg-[#060403] p-3 shadow-inner">
            {isEnabled && announcementText.trim() ? (
              <div className="bg-gradient-to-r from-amber-950/90 via-orange-950/80 to-amber-950/90 border border-amber-500/30 rounded-lg py-2 px-4 flex flex-wrap items-center justify-between gap-3 text-center sm:text-right">
                <div className="flex items-center gap-2.5 mx-auto sm:mx-0">
                  <span className="bg-amber-500/20 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-md border border-amber-500/40 shrink-0">
                    {badge || '🔥 إعلان'}
                  </span>
                  <span className="text-xs sm:text-sm text-stone-100 font-medium leading-relaxed">
                    {announcementText}
                  </span>
                </div>
                {linkTarget && (
                  <div className="shrink-0 mx-auto sm:mx-0">
                    <span className="text-[10px] bg-amber-600/30 text-amber-300 hover:bg-amber-600/40 px-2.5 py-1 rounded-md border border-amber-500/40 flex items-center gap-1 font-bold">
                      <span>اطلب الآن</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-4 text-center text-xs text-stone-500 flex items-center justify-center gap-2">
                <AlertCircle className="w-4 h-4 text-stone-600" />
                <span>شريط الإعلانات معطل حالياً ولن يظهر في المتجر حتى تقوم بتفعيله وكتابة النص.</span>
              </div>
            )}
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          
          {/* Toggle Active Switch */}
          <div className="bg-stone-950/80 border border-stone-800 rounded-2xl p-4 flex items-center justify-between">
            <div className="space-y-0.5">
              <h4 className="text-sm font-bold text-stone-200">تفعيل شريط الإعلانات في المتجر</h4>
              <p className="text-xs text-stone-400">
                عند تشغيله، يظهر الشريط فوراً في قمة الصفحة لجميع الزوار ويحفزهم على الشراء.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsEnabled(!isEnabled)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isEnabled
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30'
                  : 'bg-stone-800 text-stone-400 hover:bg-stone-700'
              }`}
            >
              {isEnabled ? (
                <>
                  <ToggleRight className="w-5 h-5 text-white" />
                  <span>مفعل (ظاهر)</span>
                </>
              ) : (
                <>
                  <ToggleLeft className="w-5 h-5 text-stone-400" />
                  <span>معطل (مخفي)</span>
                </>
              )}
            </button>
          </div>

          {/* Announcement Text */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-850 pb-3">
              <h4 className="text-sm font-bold text-stone-200 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>محتوى ونص الإعلان</span>
              </h4>
              <span className="text-[10px] text-stone-400">
                {announcementText.length} حرف
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-300 mb-1.5">
                نص الرسالة الترويجية الظاهرة للزبائن *:
              </label>
              <textarea
                rows={3}
                required={isEnabled}
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                placeholder="مثال: توصيل ساخن ومجاني لجميع طلبات الشواء اليوم التي تتجاوز 2 كلغ..."
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl p-3.5 text-stone-100 text-sm outline-none resize-none leading-relaxed"
              />
            </div>

            {/* Badges selection */}
            <div>
              <label className="block text-xs font-bold text-stone-300 mb-2 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-amber-400" />
                <span>شارة الإعلان (Badge):</span>
              </label>
              <div className="flex flex-wrap gap-2 mb-3">
                {quickBadges.map((qb) => (
                  <button
                    key={qb}
                    type="button"
                    onClick={() => setBadge(qb)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                      badge === qb
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-stone-200 hover:bg-stone-850'
                    }`}
                  >
                    {qb}
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={badge}
                onChange={(e) => setBadge(e.target.value)}
                placeholder="أو اكتب شارة مخصصة مثل: 🔥 عرض العيد"
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2 text-stone-100 text-xs outline-none"
              />
            </div>

            {/* Target Link */}
            <div>
              <label className="block text-xs font-bold text-stone-300 mb-2 flex items-center gap-1.5">
                <Link2 className="w-3.5 h-3.5 text-amber-400" />
                <span>توجيه الزبون عند النقر على الإعلان:</span>
              </label>
              <select
                value={linkTarget}
                onChange={(e) => setLinkTarget(e.target.value)}
                className="w-full bg-stone-900 border border-stone-800 focus:border-amber-500 rounded-xl px-4 py-2.5 text-stone-100 text-xs outline-none cursor-pointer"
              >
                <option value="#order-meat">قسم طلب الشواء بالكيلوغرام (حاسبة اللحم والأطباق)</option>
                <option value="#events-catering">قسم باقات وحجوزات الأعراس والمناسبات</option>
                <option value="whatsapp">محادثة الواتساب المباشرة لخدمة الزبائن</option>
                <option value="#testimonials">قسم آراء وتجارب الزبائن</option>
                <option value="#faqs">قسم الأسئلة الشائعة</option>
                <option value="">بدون رابط (نص ترويجي فقط بدون نقر)</option>
              </select>
            </div>
          </div>

          {/* Quick Ready Moroccan Templates */}
          <div className="bg-stone-950/70 border border-stone-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h4 className="text-sm font-bold text-stone-200">نماذج إعلانات جاهزة بنقرة واحدة</h4>
            </div>
            <p className="text-xs text-stone-400">
              اختر نموذجاً جاهزاً مصمماً خصيصاً لجذب عشاق الشواء المغربي الأصيل:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {readyTemplates.map((tpl, idx) => (
                <div
                  key={idx}
                  onClick={() => applyTemplate(tpl)}
                  className="bg-stone-900 border border-stone-800 hover:border-amber-500/50 rounded-xl p-3.5 cursor-pointer transition-all hover:bg-stone-850/70 group text-right flex flex-col justify-between space-y-2"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-bold text-stone-200 group-hover:text-amber-300 transition-colors">
                        {tpl.title}
                      </span>
                      <span className="text-[10px] bg-stone-800 text-amber-400 px-2 py-0.5 rounded font-mono">
                        {tpl.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-400 line-clamp-2 leading-relaxed">
                      {tpl.text}
                    </p>
                  </div>
                  <span className="text-[10px] text-amber-500/80 group-hover:text-amber-400 font-bold flex items-center justify-end gap-1 pt-1 border-t border-stone-800/60">
                    <span>تطبيق هذا النموذج الآن</span>
                    <Check className="w-3 h-3" />
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-stone-800 flex flex-col sm:flex-row items-center gap-4 justify-between">
            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={isSaving}
                className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold px-7 py-3 rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer text-xs sm:text-sm"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'جاري الحفظ ونشر الإعلان...' : 'حفظ ونشر الإعلان في الصفحة'}</span>
              </button>
            </div>

            {saveSuccess && (
              <span className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>تم نشر التعديلات بنجاح وستظهر فوراً لجميع زوار المتجر!</span>
              </span>
            )}
          </div>

        </form>
      </div>
    </div>
  );
}
