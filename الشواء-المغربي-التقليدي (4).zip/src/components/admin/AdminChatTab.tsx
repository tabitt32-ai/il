import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  Phone, 
  CheckCircle2, 
  Clock, 
  Search, 
  ExternalLink,
  Sparkles,
  ShoppingBag,
  RefreshCw
} from 'lucide-react';
import { ChatConversation, ChatMessage, OrderDetails } from '../../types';
import { subscribeAllChats, subscribeChatMessages, sendChatMessage, markChatAsRead } from '../../firebase';

interface AdminChatTabProps {
  orders: OrderDetails[];
  initialChatId?: string | null;
  onSelectOrder?: (order: OrderDetails) => void;
}

export default function AdminChatTab({ orders, initialChatId, onSelectOrder }: AdminChatTabProps) {
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(initialChatId || null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [replyText, setReplyText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Subscribe to all conversations
  useEffect(() => {
    const unsub = subscribeAllChats((chats) => {
      setConversations(chats);
      if (!selectedChatId && chats.length > 0) {
        setSelectedChatId(chats[0].id);
      }
    });
    return () => unsub();
  }, []);

  // Update selectedChatId if initialChatId prop changes
  useEffect(() => {
    if (initialChatId) {
      setSelectedChatId(initialChatId);
    }
  }, [initialChatId]);

  // Subscribe to active chat messages
  useEffect(() => {
    if (!selectedChatId) {
      setMessages([]);
      return;
    }

    markChatAsRead(selectedChatId, 'admin');

    const unsub = subscribeChatMessages(selectedChatId, (msgs) => {
      setMessages(msgs);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => unsub();
  }, [selectedChatId]);

  const selectedConversation = conversations.find(c => c.id === selectedChatId);
  const linkedOrder = selectedConversation?.orderId 
    ? orders.find(o => o.id === selectedConversation.orderId)
    : orders.find(o => selectedConversation?.customerPhone && o.customerPhone.includes(selectedConversation.customerPhone.slice(-8)));

  const handleSendMessage = async (textToSend: string) => {
    if (!selectedChatId || !textToSend.trim() || isSending) return;

    try {
      setIsSending(true);
      await sendChatMessage(selectedChatId, {
        sender: 'admin',
        senderName: 'المشرف (معلم الشواء)',
        text: textToSend.trim(),
        orderId: selectedConversation?.orderId,
        customerPhone: selectedConversation?.customerPhone
      });
      setReplyText('');
    } catch (error) {
      console.error('Failed to send admin reply:', error);
    } finally {
      setIsSending(false);
    }
  };

  const quickReplies = [
    'مرحباً بك! تم استلام وتأكيد طلبك وجاري تجهيز الشواء على الجمر 🔥',
    'طلبك قيد الشواء في الفرن البلدي التقليدي وسيصلك ساخناً وطازجاً 🍖',
    'التوصيل يستغرق حوالي 45 دقيقة وسيتصل بك السائق عند الاقتراب 🛵',
    'تم تسجيل ملاحظاتكم الإضافية وسنحرص على تطبيقها بدقة 👍',
    'يرجى إرسال إشعار التحويل البنكي CIH هنا أو عبر الواتساب لتأكيد الدفع 💳'
  ];

  const filteredChats = conversations.filter(c => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      c.customerName?.toLowerCase().includes(q) ||
      c.customerPhone?.toLowerCase().includes(q) ||
      c.orderId?.toLowerCase().includes(q) ||
      c.lastMessage?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-4">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 bg-stone-900/60 p-4 rounded-2xl border border-stone-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-amber-500" />
            <span>دردشة الزبائن المباشرة أثناء وبعد الطلب</span>
            {conversations.some(c => (c.unreadByAdmin || 0) > 0) && (
              <span className="bg-amber-500 text-stone-950 font-sans text-xs px-2 py-0.5 rounded-full font-bold">
                جديد!
              </span>
            )}
          </h2>
          <p className="text-xs text-stone-400 mt-1">
            تواصل فوري مع الزبائن للإجابة عن استفسارات اللحم، مدة الشواء، ومتابعة الطلبيات في الوقت الفعلي.
          </p>
        </div>
        <div className="text-xs text-stone-400 font-sans">
          إجمالي المحادثات: <span className="text-amber-400 font-bold">{conversations.length}</span>
        </div>
      </div>

      {/* Main Chat Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[650px] bg-stone-900/40 rounded-2xl border border-stone-800 overflow-hidden">
        
        {/* Left/Right Sidebar: Conversations List */}
        <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-l border-stone-800 flex flex-col h-[280px] lg:h-full bg-stone-950/60">
          {/* Search bar */}
          <div className="p-3 border-b border-stone-800">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث بالاسم، الهاتف، أو رقم الطلب..."
                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 pl-8 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-500"
              />
              <Search className="w-3.5 h-3.5 text-stone-500 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* Conversations Items */}
          <div className="flex-1 overflow-y-auto divide-y divide-stone-900">
            {filteredChats.length === 0 ? (
              <div className="p-8 text-center text-stone-500 text-xs flex flex-col items-center gap-2">
                <MessageSquare className="w-8 h-8 opacity-40 text-amber-500" />
                <span>لا توجد محادثات زبائن حالياً.</span>
                <span className="text-[11px] text-stone-600">ستظهر هنا أي رسالة يرسلها الزبون أثناء تصفحه أو إجرائه للطلب.</span>
              </div>
            ) : (
              filteredChats.map((chat) => {
                const isSelected = chat.id === selectedChatId;
                const hasUnread = (chat.unreadByAdmin || 0) > 0;
                const formattedTime = chat.lastMessageAt 
                  ? new Date(chat.lastMessageAt).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })
                  : '';

                return (
                  <button
                    key={chat.id}
                    onClick={() => setSelectedChatId(chat.id)}
                    className={`w-full text-right p-3.5 transition-colors flex items-start gap-3 cursor-pointer ${
                      isSelected 
                        ? 'bg-amber-500/10 border-r-4 border-amber-500' 
                        : 'hover:bg-stone-900/50'
                    }`}
                  >
                    <div className="relative shrink-0 mt-0.5">
                      <div className="w-10 h-10 rounded-full bg-stone-800 border border-stone-700 flex items-center justify-center text-base font-bold text-amber-400">
                        {chat.customerName ? chat.customerName.charAt(0) : 'ز'}
                      </div>
                      {hasUnread && (
                        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full border-2 border-stone-950 flex items-center justify-center">
                          <span className="w-1.5 h-1.5 bg-stone-950 rounded-full animate-ping"></span>
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <span className={`text-xs font-bold truncate ${hasUnread ? 'text-amber-400 font-bold' : 'text-stone-200'}`}>
                          {chat.customerName || 'زبون شواية الأصالة'}
                        </span>
                        <span className="text-[10px] text-stone-500 font-sans shrink-0">
                          {formattedTime}
                        </span>
                      </div>

                      <p className={`text-xs truncate ${hasUnread ? 'text-stone-200 font-medium' : 'text-stone-400'}`}>
                        {chat.lastMessage || 'بدأ محادثة جديدة...'}
                      </p>

                      {chat.orderId && (
                        <div className="mt-1.5 flex items-center gap-1 text-[10px] text-amber-500/80 bg-amber-500/10 w-fit px-1.5 py-0.5 rounded">
                          <ShoppingBag className="w-2.5 h-2.5" />
                          <span className="font-sans">طلب #{chat.orderId.slice(-6)}</span>
                        </div>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Center/Right: Active Chat Conversation Details */}
        <div className="lg:col-span-8 flex flex-col h-full bg-stone-950/30">
          {selectedChatId && selectedConversation ? (
            <>
              {/* Chat Header */}
              <div className="p-3.5 border-b border-stone-800 bg-stone-900/50 flex flex-wrap justify-between items-center gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-600/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
                    {selectedConversation.customerName ? selectedConversation.customerName.charAt(0) : 'ز'}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{selectedConversation.customerName || 'زبون الموقع'}</span>
                      <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                      <span className="text-[10px] text-emerald-400 font-normal">متصل الآن</span>
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-stone-400 font-sans mt-0.5">
                      {selectedConversation.customerPhone && (
                        <span>الهاتف: {selectedConversation.customerPhone}</span>
                      )}
                      {selectedConversation.orderId && (
                        <span className="text-amber-400 font-bold">
                          طلب رقم: #{selectedConversation.orderId.slice(-6)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {selectedConversation.customerPhone && (
                    <a
                      href={`https://wa.me/${selectedConversation.customerPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('السلام عليكم، شواية الأصالة المغربية تتواصل معكم بخصوص استفساركم أو طلبكم.')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-700/30 hover:bg-emerald-700/50 border border-emerald-600/40 text-emerald-300 text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>واتساب</span>
                    </a>
                  )}

                  {selectedConversation.customerPhone && (
                    <a
                      href={`tel:${selectedConversation.customerPhone}`}
                      className="bg-stone-800 hover:bg-stone-700 border border-stone-700 text-stone-300 text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>اتصال</span>
                    </a>
                  )}

                  {linkedOrder && onSelectOrder && (
                    <button
                      onClick={() => onSelectOrder(linkedOrder)}
                      className="bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>معاينة الطلب</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Linked Order Banner if any */}
              {linkedOrder && (
                <div className="bg-amber-950/20 border-b border-amber-900/30 px-4 py-2 flex items-center justify-between text-xs text-amber-300">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-amber-400" />
                    <span>
                      الزبون لديه طلب نشط: <strong>{linkedOrder.total} د.م.</strong> ({linkedOrder.cartItems.length} عناصر) • الحالة:{' '}
                      <span className="font-bold underline">{linkedOrder.status}</span>
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-400 font-sans">
                    {new Date(linkedOrder.createdAt).toLocaleDateString('ar-MA')}
                  </span>
                </div>
              )}

              {/* Messages Area */}
              <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0B0806]">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-stone-500 text-xs gap-2">
                    <Clock className="w-8 h-8 opacity-40 text-stone-400" />
                    <p>المحادثة فارغة. يمكنك إرسال رسالة ترحيبية للزبون للبدء فوراً.</p>
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isAdmin = msg.sender === 'admin';
                    const timeStr = msg.createdAt 
                      ? new Date(msg.createdAt).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })
                      : '';

                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isAdmin ? 'items-start' : 'items-end'}`}
                      >
                        <div className="flex items-center gap-1.5 mb-1 px-1">
                          <span className="text-[10px] text-stone-400">
                            {isAdmin ? 'أنت (المشرف)' : msg.senderName || 'الزبون'}
                          </span>
                          <span className="text-[9px] text-stone-500 font-sans">{timeStr}</span>
                        </div>

                        <div
                          className={`max-w-[85%] sm:max-w-[70%] p-3 rounded-2xl text-xs leading-relaxed ${
                            isAdmin
                              ? 'bg-amber-600 text-stone-950 font-medium rounded-tr-none shadow-md shadow-amber-950/20'
                              : 'bg-stone-800 text-stone-100 rounded-tl-none border border-stone-700'
                          }`}
                        >
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Canned Replies Bar */}
              <div className="p-2 bg-stone-900 border-t border-stone-800 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-1.5">
                <span className="text-[10px] text-stone-400 flex items-center gap-1 py-1 px-1 shrink-0">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  ردود جاهزة:
                </span>
                {quickReplies.map((r, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(r)}
                    className="text-[11px] bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white px-2.5 py-1 rounded-lg border border-stone-700 transition-colors shrink-0 cursor-pointer"
                  >
                    {r.length > 35 ? r.slice(0, 35) + '...' : r}
                  </button>
                ))}
              </div>

              {/* Message Input Bar */}
              <div className="p-3 bg-stone-950 border-t border-stone-800 flex gap-2 items-center">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(replyText);
                    }
                  }}
                  placeholder="اكتب ردك للزبون هنا (اضغط Enter للإرسال)..."
                  className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  onClick={() => handleSendMessage(replyText)}
                  disabled={!replyText.trim() || isSending}
                  className="bg-amber-600 hover:bg-amber-500 disabled:opacity-30 text-stone-950 font-bold px-4 py-2.5 rounded-xl transition-all flex items-center gap-1.5 text-xs cursor-pointer shadow-md"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال</span>
                </button>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center text-stone-500 text-xs">
              <MessageSquare className="w-12 h-12 text-stone-600 mb-3" />
              <p className="text-sm text-stone-300 font-bold">حدد محادثة من القائمة للبدء في الدردشة</p>
              <p className="text-stone-500 mt-1 max-w-sm">
                يمكنك الرد على جميع رسائل الزبائن واستفساراتهم حول الطلبيات، مدة الشواء، والتوصيل بشكل فوري.
              </p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
