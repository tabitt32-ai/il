import React, { useState } from 'react';
import { Minus, Plus, ShoppingBag, Check, Flame, Award, ShieldCheck } from 'lucide-react';
import { SideItem, CartItem, SiteSettings } from '../types';
import { TRADITIONAL_SIDES } from '../data';
import skewersImage from '../assets/images/moroccan_skewers_grill_1783196840332.jpg';

interface OrderCalculatorProps {
  onAddToCart: (item: CartItem) => void;
  pricePerKg?: number;
  products?: SideItem[];
  siteSettings?: SiteSettings;
}

export default function OrderCalculator({ 
  onAddToCart, 
  pricePerKg = 300,
  products = TRADITIONAL_SIDES,
  siteSettings
}: OrderCalculatorProps) {
  const [kg, setKg] = useState<number>(1);
  const [cooking, setCooking] = useState<string>('well-done');
  const [selectedSeasoning, setSelectedSeasoning] = useState<string[]>(['salt', 'cumin']);
  const [sidesCart, setSidesCart] = useState<{ [sideId: string]: number }>({});
  const [successMsg, setSuccessMsg] = useState(false);

  // Available sides / dishes
  const availableSides = (products && products.length > 0 ? products : TRADITIONAL_SIDES)
    .filter(p => p.isAvailable !== false);

  const cookingOptions = [
    { id: 'well-done', name: 'محمر ومقرمش (Well Done)', desc: 'مطبوخ ببطء مع قشرة خارجية مقرمشة مذهلة' },
    { id: 'medium', name: 'فتي ورطب (Juicy/Medium)', desc: 'مطبوخ بعناية ليحتفظ بلياقتة وعصارته اللذيذة' },
    { id: 'traditional', name: 'على الطريقة الفاسية الأصيلة', desc: 'شواء تقليدي تحت الرماد الساخن للفرن البلدي' },
  ];

  const seasoningOptions = [
    { id: 'salt', name: 'ملح بلدي' },
    { id: 'cumin', name: 'كامون بلدي مطحون باليد' },
    { id: 'traditional-rub', name: 'خلطة البهارات السبعة للشواء' },
    { id: 'chili', name: 'سودانية (فلفل حار مغربي)' },
  ];

  const handleSeasoningToggle = (id: string) => {
    if (selectedSeasoning.includes(id)) {
      setSelectedSeasoning(selectedSeasoning.filter(item => item !== id));
    } else {
      setSelectedSeasoning([...selectedSeasoning, id]);
    }
  };

  const updateSideQty = (sideId: string, delta: number) => {
    const current = sidesCart[sideId] || 0;
    const next = Math.max(0, current + delta);
    setSidesCart({
      ...sidesCart,
      [sideId]: next,
    });
  };

  // Calculations
  const meatTotal = kg * pricePerKg;
  
  const selectedSidesList = Object.keys(sidesCart)
    .map(sideId => {
      const side = availableSides.find(s => s.id === sideId);
      if (!side) return null;
      return { side, quantity: sidesCart[sideId] };
    })
    .filter((item): item is { side: SideItem; quantity: number } => item !== null && item.quantity > 0);

  const sidesTotal = selectedSidesList.reduce(
    (sum, item) => sum + item.side.price * item.quantity,
    0
  );

  const totalOrderPrice = meatTotal + sidesTotal;

  const handleAddClick = () => {
    const cartItem: CartItem = {
      id: `meat_${Date.now()}`,
      name: 'شواء لحم الغنمي البلدي',
      quantityKg: kg,
      pricePerKg,
      cookingPreference: cookingOptions.find(o => o.id === cooking)?.name,
      seasoningPreference: selectedSeasoning.map(
        id => seasoningOptions.find(o => o.id === id)?.name || ''
      ),
      sides: selectedSidesList,
      totalPrice: totalOrderPrice,
    };

    onAddToCart(cartItem);
    setSuccessMsg(true);
    
    // Reset side selection after adding
    setSidesCart({});
    setKg(1);
    
    setTimeout(() => {
      setSuccessMsg(false);
    }, 3000);
  };

  return (
    <section id="order-meat" className="py-20 bg-[#0B0604] border-t border-[#2C1A10] relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-amber-950/10 via-transparent to-transparent opacity-50"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-amber-500 font-bold tracking-widest text-xs uppercase bg-amber-950/30 px-3 py-1.5 rounded-full border border-amber-900/30">شراء مباشر بالكيلوغرام</span>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-100 mt-4 mb-6 leading-tight">
            طلب الشواء الطازج الساخن
          </h2>
          <p className="text-stone-300 text-lg leading-relaxed font-sans">
            نحضر لكم أجود أنواع اللحوم (الغنمي البلدي) الطازجة يومياً ونقوم بشوائها بطريقتنا التقليدية المغربية على الفحم الهادئ. ثمن الكيلوغرام <span className="text-amber-500 font-bold text-2xl font-sans">{pricePerKg} درهم</span> فقط شاملاً الطهي والبهارات والتعبئة الفاخرة الساخنة.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Image and Badges */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-stone-850 group">
              <img
                src={siteSettings?.skewersImageUrl || skewersImage}
                alt="شواء قطبان مغربي على الفحم"
                className="w-full h-[400px] object-cover object-center group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#140E0A] via-[#140E0A]/10 to-transparent"></div>
              
              {/* Floating Price Badge */}
              <div className="absolute top-6 right-6 bg-gradient-to-br from-amber-600 to-orange-600 text-white font-sans font-bold px-5 py-3 rounded-2xl shadow-xl flex flex-col items-center">
                <span className="text-xs tracking-wider">ثمن الكيلو</span>
                <span className="text-2xl font-extrabold leading-none">{pricePerKg} د.م.</span>
              </div>

              {/* Cooking Info Badge */}
              <div className="absolute bottom-6 left-6 right-6 bg-[#18110D]/90 backdrop-blur-md border border-[#2D1B12] p-4 rounded-2xl">
                <div className="flex items-start gap-3">
                  <Flame className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-stone-100 text-sm font-bold">طهي تقليدي أصيل</h4>
                    <p className="text-stone-400 text-xs mt-1">يُشوى اللحم على فحم الكروش الصلب ليعطي نكهة مدخنة رائعة تدوم طويلاً.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quality Seals */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#18110D] border border-[#2D1B12] p-4 rounded-2xl flex items-center gap-3">
                <Award className="w-8 h-8 text-amber-500 flex-shrink-0" />
                <div>
                  <h5 className="text-stone-100 text-sm font-bold">غنمي بلدي 100%</h5>
                  <p className="text-stone-400 text-xs">مذبوح حديثاً بمجازر معتمدة</p>
                </div>
              </div>
              <div className="bg-[#18110D] border border-[#2D1B12] p-4 rounded-2xl flex items-center gap-3">
                <ShieldCheck className="w-8 h-8 text-amber-500 flex-shrink-0" />
                <div>
                  <h5 className="text-stone-100 text-sm font-bold">معايير نظافة صارمة</h5>
                  <p className="text-stone-400 text-xs">جودة وتعبئة صحية آمنة</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Calculator Panel */}
          <div className="lg:col-span-7 bg-[#140E0A] border border-[#2D1B12] p-6 sm:p-8 rounded-3xl shadow-xl relative overflow-hidden">
            
            {/* Customizer Headers */}
            <div className="border-b border-stone-850 pb-6 mb-6">
              <h3 className="font-serif text-2xl font-bold text-stone-100">صمم وجبة الشواء الخاصة بك</h3>
              <p className="text-stone-400 text-xs mt-1">اختر الكمية وطريقة التحضير والمقبلات المغربية المناسبة</p>
            </div>

            {/* Weight selector (KG) */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <label className="text-stone-200 font-bold text-sm">حدد كمية اللحم المطلوب (بالكيلوغرام)</label>
                <span className="flex items-center gap-1 bg-amber-950/30 px-3 py-1 rounded-lg border border-amber-900/30 text-amber-400 font-bold text-lg" dir="rtl">
                  <span className="font-sans text-xl">{kg}</span>
                  <span className="text-sm text-amber-400/80 mr-0.5">كجم</span>
                  <span className="text-stone-500 mx-1.5">=</span>
                  <span className="font-sans text-xl text-amber-400">{meatTotal}</span>
                  <span className="text-sm text-amber-400/80 mr-0.5">درهم</span>
                </span>
              </div>
              
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 bg-[#18110D] p-4 rounded-2xl border border-[#2D1B12]">
                {/* Number input with Plus/Minus */}
                <div className="flex items-center justify-between bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 w-full sm:w-44 h-12">
                  <button
                    type="button"
                    onClick={() => setKg(Math.max(1, parseFloat((kg - 0.5).toFixed(1))))}
                    className="w-8 h-8 rounded-lg bg-stone-850 hover:bg-stone-800 flex items-center justify-center text-stone-300 hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  
                  <div className="flex items-center justify-center gap-1">
                    <input
                      type="number"
                      min="1"
                      step="0.5"
                      value={kg}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        if (!isNaN(val)) {
                          setKg(val < 1 ? 1 : val);
                        } else {
                          setKg(1);
                        }
                      }}
                      onBlur={() => {
                        if (isNaN(kg) || kg < 1) {
                          setKg(1);
                        }
                      }}
                      className="bg-transparent text-center font-sans font-bold text-stone-100 text-lg focus:outline-none w-16"
                    />
                    <span className="text-xs text-stone-400 font-bold">كجم</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setKg(parseFloat((kg + 0.5).toFixed(1)))}
                    className="w-8 h-8 rounded-lg bg-stone-850 hover:bg-stone-800 flex items-center justify-center text-stone-300 hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                
                {/* Visual slider */}
                <div className="flex-1 flex items-center gap-3">
                  <span className="text-[10px] text-stone-500 font-sans font-bold">1 كجم</span>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="0.5"
                    value={kg}
                    onChange={(e) => setKg(parseFloat(parseFloat(e.target.value).toFixed(1)))}
                    className="flex-1 accent-amber-500 h-2 bg-stone-850 rounded-lg cursor-pointer"
                  />
                  <span className="text-[10px] text-stone-500 font-sans font-bold">20 كجم</span>
                </div>
              </div>
              <p className="text-[10px] text-stone-400 mt-2 text-right">
                💡 يمكنك كتابة الكمية بدقة (مثال: 1.5 أو 2.5 كجم) أو استخدام أزرار التحكم والخط المنزلق لتعديل الوزن من 1 كيلو فما فوق.
              </p>
            </div>

            {/* Cooking preference */}
            <div className="mb-8">
              <label className="text-stone-200 font-bold text-sm block mb-3">درجة وطريقة الطهي المطلوبة</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {cookingOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setCooking(opt.id)}
                    className={`p-3 text-right rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      cooking === opt.id
                        ? 'border-amber-500 bg-amber-950/35 text-amber-400'
                        : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                    }`}
                  >
                    <div className="font-bold text-sm">{opt.name}</div>
                    <div className="text-[10px] text-stone-400 mt-1">{opt.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Seasoning preference */}
            <div className="mb-8">
              <label className="text-stone-200 font-bold text-sm block mb-3">البهارات المرفقة أو المتبلة (يمكنك اختيار أكثر من واحد)</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {seasoningOptions.map((opt) => {
                  const isSelected = selectedSeasoning.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleSeasoningToggle(opt.id)}
                      className={`py-2 px-3 text-center rounded-xl border text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-950/35 text-amber-400'
                          : 'border-[#2D1B12] bg-[#18110D] hover:bg-stone-900 text-stone-300'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                      <span>{opt.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sides / Salads / Drinks additions */}
            <div className="mb-8 bg-[#18110D]/50 p-5 rounded-2xl border border-[#2D1B12]">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-stone-200 font-bold text-sm">مقبلات ومشروبات وأطباق إضافية</h4>
                <span className="text-xs text-stone-400">متوفرة للطلب</span>
              </div>

              <div className="space-y-3 max-h-[260px] overflow-y-auto pr-2">
                {availableSides.map((side) => {
                  const qty = sidesCart[side.id] || 0;
                  return (
                    <div key={side.id} className="flex items-center justify-between py-2.5 px-3 bg-[#120B08] rounded-xl border border-stone-850/60 hover:border-amber-900/40 transition-colors gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        {side.image ? (
                          <img 
                            src={side.image} 
                            alt={side.name} 
                            className="w-12 h-12 rounded-xl object-cover border border-amber-900/40 flex-shrink-0 shadow-sm"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-xl bg-amber-950/40 border border-amber-900/40 flex items-center justify-center flex-shrink-0 text-amber-500 text-lg">
                            🥩
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h5 className="text-stone-100 text-xs sm:text-sm font-bold truncate">{side.name}</h5>
                            <span className="text-[9px] text-amber-400 bg-amber-950/60 border border-amber-900/40 px-1.5 py-0.2 rounded font-medium">
                              {side.category === 'meat' ? 'شواء ولحوم' : 
                               side.category === 'platters' ? 'طبق فاخر' : 
                               side.category === 'salads' ? 'سلطة' : 
                               side.category === 'drinks' ? 'مشروب' : 'مقبلات'}
                            </span>
                          </div>
                          <p className="text-stone-400 text-[11px] mt-0.5 line-clamp-1">{side.description}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 flex-shrink-0">
                        <span className="text-amber-400 text-xs font-sans font-bold whitespace-nowrap">
                          {side.price} د.م.
                        </span>
                        
                        <div className="flex items-center gap-1.5 bg-[#140E0A] border border-[#2D1B12] rounded-lg p-1">
                          <button
                            type="button"
                            onClick={() => updateSideQty(side.id, -1)}
                            className="w-6 h-6 flex items-center justify-center rounded-md bg-stone-900 text-stone-300 hover:text-amber-400 hover:bg-stone-850 transition-colors cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-stone-100 font-sans font-bold text-xs w-4 text-center">
                            {qty}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateSideQty(side.id, 1)}
                            className="w-6 h-6 flex items-center justify-center rounded-md bg-stone-900 text-stone-300 hover:text-amber-400 hover:bg-stone-850 transition-colors cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Total Block & Add Button */}
            <div className="bg-[#18110D] border border-[#2D1B12] p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-right w-full sm:w-auto">
                <span className="text-stone-400 text-xs block">المجموع الإجمالي التقريبي</span>
                <span className="text-2xl sm:text-3xl font-sans font-extrabold text-amber-500 mt-1 block">
                  {totalOrderPrice} <span className="text-sm font-sans font-medium text-stone-400">درهم مغربي</span>
                </span>
                {sidesTotal > 0 && (
                  <span className="text-[10px] text-stone-400/85 block mt-1">
                    (لحم: {meatTotal} د.م. + مقبلات: {sidesTotal} د.م.)
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={handleAddClick}
                className="w-full sm:w-auto flex items-center justify-center gap-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold px-8 py-4 rounded-xl shadow-lg shadow-orange-950/40 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
              >
                <ShoppingBag className="w-5 h-5" />
                <span>إضافة الطلب إلى السلة</span>
              </button>
            </div>

            {/* Success feedback */}
            {successMsg && (
              <div className="absolute inset-0 bg-stone-950/98 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-fade-in z-20">
                <div className="w-16 h-16 rounded-full bg-emerald-950/30 border border-emerald-500 flex items-center justify-center text-emerald-400 mb-4 animate-bounce">
                  <Check className="w-8 h-8" />
                </div>
                <h4 className="font-serif text-2xl font-bold text-stone-100">تمت الإضافة بنجاح!</h4>
                <p className="text-stone-300 text-sm mt-2 max-w-sm leading-relaxed">
                  تمت إضافة الشواء ومقبلاتك اللذيذة إلى السلة. يمكنك المتابعة لتحديد طريقة التوصيل والدفع في الأعلى.
                </p>
                <button
                  type="button"
                  onClick={() => setSuccessMsg(false)}
                  className="mt-6 text-xs text-amber-400 hover:underline border border-stone-800 px-4 py-2 rounded-lg bg-stone-900 hover:bg-stone-850 transition-all cursor-pointer"
                >
                  إضافة طلب شواء إضافي
                </button>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
