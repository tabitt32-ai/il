import React, { useState, useEffect, useRef } from 'react';
import { 
  ShoppingBag, Flame, Calendar, Clock, HelpCircle, FileText, Menu, X, 
  Megaphone, Bell, CheckCircle2, MessageSquare, ExternalLink, Trash2, AlertCircle
} from 'lucide-react';
import { CartItem, SiteSettings, AppNotification } from '../types';

interface HeaderProps {
  cart: CartItem[];
  siteSettings?: SiteSettings;
  notifications?: AppNotification[];
  onOpenCart: () => void;
  onOpenReservations: () => void;
  onScrollToSection: (sectionId: string) => void;
  onClearNotifications?: () => void;
  onNotificationAction?: (notification: AppNotification) => void;
}

export default function Header({ 
  cart, 
  siteSettings,
  notifications = [],
  onOpenCart, 
  onOpenReservations, 
  onScrollToSection,
  onClearNotifications,
  onNotificationAction
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [cartTotal, setCartTotal] = useState(0);
  const notifRef = useRef<HTMLDivElement>(null);

  const [isAnnouncementDismissed, setIsAnnouncementDismissed] = useState(false);

  const handleAnnouncementClick = () => {
    if (!siteSettings?.announcementLink) return;
    if (siteSettings.announcementLink === 'whatsapp') {
      const phone = siteSettings.whatsappPhone || '212600000000';
      const clean = phone.replace(/[^0-9]/g, '');
      const text = encodeURIComponent('السلام عليكم، استفسار بخصوص العرض الترويجي المعلن في الموقع');
      window.open(`https://wa.me/${clean}?text=${text}`, '_blank');
    } else if (siteSettings.announcementLink.startsWith('#')) {
      const section = siteSettings.announcementLink.replace('#', '');
      onScrollToSection(section);
    }
  };

  // Calculate cart counts
  useEffect(() => {
    let count = 0;
    let total = 0;
    cart.forEach(item => {
      count += item.quantityKg || item.quantityItem || 0;
      total += item.totalPrice;
    });
    setCartCount(count);
    setCartTotal(total);
  }, [cart]);

  // Handle click outside notification dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotifOpen(false);
      }
    };
    if (isNotifOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isNotifOpen]);

  // Handle scroll shadow
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'hero', name: 'الرئيسية', icon: Clock },
    { id: 'order-meat', name: 'شراء بالكيلوغرام', icon: Flame },
    { id: 'events-catering', name: 'الأعراس والمناسبات', icon: Calendar },
    { id: 'testimonials', name: 'آراء العملاء', icon: FileText },
    { id: 'faqs', name: 'الأسئلة الشائعة', icon: HelpCircle },
  ];

  const handleNavClick = (id: string) => {
    onScrollToSection(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0B0604]/95 backdrop-blur-md shadow-md border-b border-stone-900/80 py-2'
          : 'bg-gradient-to-b from-black/85 to-transparent py-3'
      }`}
    >
      {/* Interactive Announcement Banner */}
      {!isAnnouncementDismissed && siteSettings?.announcement && siteSettings?.announcementEnabled !== false && (
        <div className="bg-gradient-to-r from-amber-950/95 via-orange-950/90 to-amber-950/95 border-b border-amber-500/25 py-1.5 px-3 sm:px-4 text-center relative shadow-sm">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 text-xs">
            <button
              onClick={() => setIsAnnouncementDismissed(true)}
              className="text-stone-400 hover:text-white p-0.5 rounded transition-colors cursor-pointer shrink-0"
              title="إغلاق الإعلان"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            <div 
              onClick={handleAnnouncementClick}
              className={`flex items-center justify-center gap-2 text-stone-100 font-medium mx-auto flex-wrap ${
                siteSettings.announcementLink ? 'cursor-pointer hover:text-amber-300 transition-colors group' : ''
              }`}
            >
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 flex items-center gap-1">
                <Megaphone className="w-3 h-3 text-amber-400 shrink-0 animate-pulse" />
                <span>{siteSettings.announcementBadge || '🔥 عرض خاص'}</span>
              </span>
              <span className="text-[11px] sm:text-xs leading-tight">
                {siteSettings.announcement}
              </span>
              {siteSettings.announcementLink && (
                <span className="text-[10px] text-amber-400 group-hover:underline flex items-center gap-0.5 font-bold">
                  <span>تفاصيل</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </span>
              )}
            </div>

            <div className="w-3.5 shrink-0 hidden sm:block"></div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo Section */}
          <div 
            onClick={() => handleNavClick('hero')} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-tr from-amber-600 to-orange-600 shadow-lg border border-amber-500/20 group-hover:scale-105 transition-transform">
              <Flame className="w-6 h-6 text-white animate-pulse" />
              <div className="absolute -inset-0.5 rounded-full bg-[#D2691E]/20 blur opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>
            <div>
              <h1 className="font-serif text-lg sm:text-2xl font-bold tracking-wide transition-colors text-stone-100">
                {siteSettings?.siteTitle || 'الشواء المغربي الأصيل'}
              </h1>
              <p className="text-[10px] font-sans tracking-widest text-left transition-colors text-amber-500">
                LE MECHOUI MAROCAIN
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3.5 py-2 font-medium rounded-lg text-sm transition-all duration-200 cursor-pointer ${
                  isScrolled 
                    ? 'text-stone-300 hover:text-amber-400 hover:bg-amber-950/20' 
                    : 'text-stone-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* My Bookings History Button */}
            <button
              onClick={onOpenReservations}
              className={`p-2 sm:p-2.5 rounded-full transition-all relative cursor-pointer ${
                isScrolled
                  ? 'text-stone-300 hover:text-amber-400 hover:bg-amber-950/10'
                  : 'text-stone-300 hover:text-white hover:bg-white/5'
              }`}
              title="طلباتي وحجوزاتي"
            >
              <FileText className="w-5 h-5" />
            </button>

            {/* Notification Bell Trigger & Dropdown */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className={`p-2 sm:p-2.5 rounded-full transition-all relative cursor-pointer ${
                  isScrolled
                    ? 'text-stone-300 hover:text-amber-400 hover:bg-amber-950/10'
                    : 'text-stone-300 hover:text-white hover:bg-white/5'
                }`}
                title="تنبيهات الطلبات والواتساب"
              >
                <Bell className="w-5 h-5" />
                {notifications.length > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-stone-950 animate-ping"></span>
                )}
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-amber-500 text-stone-950 font-bold font-sans text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                    {notifications.length}
                  </span>
                )}
              </button>

              {/* Notification Popover Dropdown */}
              {isNotifOpen && (
                <div className="absolute left-0 sm:right-0 sm:left-auto mt-2 w-80 sm:w-96 bg-[#0B0806] border border-[#2D1B12] rounded-2xl shadow-2xl overflow-hidden z-50 animate-fade-in text-right">
                  <div className="p-3.5 bg-[#140E0A] border-b border-[#2D1B12] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                      <h4 className="text-xs font-bold text-stone-100 flex items-center gap-1.5 font-serif">
                        <Bell className="w-3.5 h-3.5 text-amber-400" />
                        <span>تنبيهات الطلبات والواتساب</span>
                      </h4>
                    </div>
                    {notifications.length > 0 && (
                      <button
                        onClick={onClearNotifications}
                        className="text-[10px] text-stone-400 hover:text-stone-200 flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>مسح الكل</span>
                      </button>
                    )}
                  </div>

                  <div className="max-h-72 overflow-y-auto p-2 space-y-2 custom-scrollbar">
                    {notifications.length === 0 ? (
                      <div className="py-8 px-4 text-center">
                        <CheckCircle2 className="w-8 h-8 text-emerald-500/40 mx-auto mb-2" />
                        <p className="text-xs font-bold text-stone-300">لا توجد تنبيهات معلقة</p>
                        <p className="text-[10px] text-stone-500 mt-1 leading-relaxed">
                          ستظهر هنا تنبيهات تأكيد الطلبات فور إتمامها وإشعارات رسائل الواتساب لمنع ضياع أي طلب.
                        </p>
                      </div>
                    ) : (
                      notifications.map((notif) => (
                        <div
                          key={notif.id}
                          className="p-3 rounded-xl bg-[#140E0A] border border-[#2D1B12] hover:border-amber-500/30 transition-all space-y-1.5"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-stone-500">{notif.timestamp}</span>
                            <span className="text-xs font-bold text-stone-100 flex items-center gap-1.5">
                              {notif.title}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-300 leading-relaxed">
                            {notif.message}
                          </p>
                          {notif.actionLabel && (
                            <div className="pt-1 flex justify-end">
                              <button
                                onClick={() => {
                                  onNotificationAction?.(notif);
                                  setIsNotifOpen(false);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                              >
                                <span>{notif.actionLabel}</span>
                                <ExternalLink className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>

                  <div className="p-2.5 bg-[#050302] border-t border-[#2D1B12] text-center">
                    <p className="text-[10px] text-stone-400 flex items-center justify-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      <span>نظام تتبع الطلبات متصل ومحمي من الضياع</span>
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Cart Floating Button */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold px-3.5 py-2 sm:px-5 sm:py-2.5 rounded-full shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-stone-900 text-amber-400 font-sans text-[10px] w-5 h-5 rounded-full flex items-center justify-center border border-amber-500/25 animate-bounce">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline text-sm">السلة</span>
              {cartTotal > 0 && (
                <span className="hidden lg:inline border-r border-white/20 pr-2 mr-1 text-sm font-sans">
                  {cartTotal} د.م.
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`p-2 md:hidden rounded-lg transition-colors cursor-pointer ${
                isScrolled
                  ? 'text-stone-300 hover:text-amber-400 hover:bg-amber-950/10'
                  : 'text-stone-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-stone-950/95 backdrop-blur-lg border-b border-stone-900 px-4 pt-3 pb-6 animate-fade-in">
          <div className="flex flex-col gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className="flex items-center gap-3 px-4 py-3 text-stone-300 hover:text-amber-400 text-right rounded-lg hover:bg-amber-950/20 transition-all text-sm font-medium cursor-pointer"
                >
                  <Icon className="w-4 h-4 text-amber-500" />
                  <span>{item.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
}
