import React from 'react';
import { Flame, Phone, MapPin, Mail, CreditCard, Clock } from 'lucide-react';

interface FooterProps {
  onScrollToSection: (sectionId: string) => void;
  onNavigate?: (path: string) => void;
}

export default function Footer({ onScrollToSection, onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#060403] text-stone-300 font-sans border-t border-[#1a100a]">
      
      {/* Decorative Traditional Border divider */}
      <div className="h-1.5 bg-gradient-to-r from-amber-600 via-[#8B4513] to-orange-600"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-right">
          
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 justify-end">
              <span className="font-serif text-xl font-bold text-stone-100">الشواء المغربي الأصيل</span>
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white font-bold">
                🔥
              </div>
            </div>
            <p className="text-xs leading-relaxed text-stone-400">
              أول منصة مغربية تقليدية تدمج عراقة الطهي البلدي للمشوي والقطبان على الفحم مع سلاسة الطلب والتوصيل الفوري لبيوتكم وأفراحكم في جميع أنحاء المملكة.
            </p>
            <div className="flex items-center gap-2 justify-end text-[10px] text-stone-500">
              <span>توصيل معقم ساخن</span> • <span>لحوم بلدية معتمدة 100%</span>
            </div>
          </div>

          {/* Nav Links Col */}
          <div className="space-y-4">
            <h4 className="text-stone-100 text-sm font-bold border-r-2 border-amber-500 pr-3">روابط سريعة</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onScrollToSection('hero')} className="hover:text-white transition-colors cursor-pointer">
                  الصفحة الرئيسية
                </button>
              </li>
              <li>
                <button onClick={() => onScrollToSection('order-meat')} className="hover:text-white transition-colors cursor-pointer">
                  طلب شواء بالكيلوغرام (300 د.م.)
                </button>
              </li>
              <li>
                <button onClick={() => onScrollToSection('events-catering')} className="hover:text-white transition-colors cursor-pointer">
                  باقات الأعراس والمناسبات الكبرى
                </button>
              </li>
              <li>
                <button onClick={() => onScrollToSection('testimonials')} className="hover:text-white transition-colors cursor-pointer">
                  آراء عملاء المشوي
                </button>
              </li>
              <li>
                <button onClick={() => onScrollToSection('faqs')} className="hover:text-white transition-colors cursor-pointer">
                  الأسئلة الشائعة FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Col */}
          <div className="space-y-4">
            <h4 className="text-stone-100 text-sm font-bold border-r-2 border-amber-500 pr-3">معلومات التواصل</h4>
            <ul className="space-y-3 text-xs">
              <li className="flex items-start gap-2 justify-end">
                <a 
                  href="https://maps.app.goo.gl/b1r8Ry8xqYAi8Jg66" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-stone-300 font-bold hover:text-white hover:underline transition-colors flex items-center gap-1.5"
                >
                  <span>إبن جرير، شارع محمد الخامس</span>
                  <MapPin className="w-4 h-4 text-amber-500 flex-shrink-0" />
                </a>
              </li>
              <li className="flex items-center gap-2 justify-end">
                <a 
                  href="tel:+212717301089" 
                  className="text-stone-300 font-sans hover:text-white hover:underline transition-colors flex items-center gap-1.5"
                  dir="ltr"
                >
                  <span>+212 717 301089</span>
                  <Phone className="w-4 h-4 text-amber-500 flex-shrink-0" />
                </a>
              </li>
              <li className="flex items-center gap-2 justify-end">
                <span className="text-stone-300 font-sans">chouae-alassil@gmail.com</span>
                <Mail className="w-4 h-4 text-amber-500 flex-shrink-0" />
              </li>
            </ul>
          </div>

          {/* Working Hours & Security */}
          <div className="space-y-4">
            <h4 className="text-stone-100 text-sm font-bold border-r-2 border-amber-500 pr-3">ساعات العمل والأمان</h4>
            <div className="space-y-3 text-xs leading-relaxed text-stone-400">
              <div className="flex items-center gap-2 justify-end text-stone-200">
                <span>يومياً: من 11:30 صباحاً إلى 11:00 مساءً</span>
                <Clock className="w-4 h-4 text-amber-500 flex-shrink-0" />
              </div>
              <p>نعمل طيلة أيام الأسبوع لتلبية طلبيات الشواء الساخن وتجهيز الأعراس.</p>
              
              {/* Payment logo simulation */}
              <div className="flex items-center gap-2.5 justify-end pt-2 border-t border-stone-900">
                <span className="text-[10px] text-stone-500">طرق الدفع المدعومة:</span>
                <div className="flex gap-1">
                  <span className="bg-stone-900 border border-stone-850 px-1.5 py-0.5 rounded text-[8px] font-sans text-stone-300">COD</span>
                  <span className="bg-stone-900 border border-stone-850 px-1.5 py-0.5 rounded text-[8px] font-sans text-stone-300">VISA</span>
                  <span className="bg-stone-900 border border-stone-850 px-1.5 py-0.5 rounded text-[8px] font-sans text-stone-300">cmi</span>
                  <span className="bg-stone-900 border border-stone-850 px-1.5 py-0.5 rounded text-[8px] font-sans text-stone-300">RIB</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-stone-900 mt-12 pt-6 text-center text-xs text-stone-500 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>
            تطوير وتصميم بلمسة مغربية أصيلة © {currentYear} • كافة الحقوق محفوظة.
          </p>
          <div className="flex gap-4 items-center">
            <span className="hover:text-white cursor-pointer">شروط الاستخدام</span>
            <span className="hover:text-white cursor-pointer">سياسة الخصوصية</span>
            <span className="hover:text-white cursor-pointer">المصادقة الصحية</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
