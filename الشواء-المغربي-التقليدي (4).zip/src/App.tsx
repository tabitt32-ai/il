import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Flame, Utensils, Compass, Clock, Award, Users, ChevronDown, Check, Star, 
  MessageSquare, Heart, Sparkles, MapPin, PhoneCall, AlertCircle, Shield
} from 'lucide-react';

// Subcomponents
import Header from './components/Header';
import OrderCalculator from './components/OrderCalculator';
import EventBooking from './components/EventBooking';
import CheckoutModal from './components/CheckoutModal';
import MyReservations from './components/MyReservations';
import SupportChat from './components/SupportChat';
import AdminDashboard from './components/AdminDashboard';
import NotificationToaster from './components/NotificationToaster';
import Footer from './components/Footer';

// Static Data & Types
import { CartItem, OrderDetails, EventBookingRequest, CustomerReview, SiteSettings, SideItem, AppNotification } from './types';
import { INITIAL_REVIEWS, FAQS, TRADITIONAL_SIDES } from './data';
import { 
  DEFAULT_SITE_SETTINGS, 
  subscribeSiteSettings, 
  subscribeOrders, 
  subscribeProducts, 
  subscribeBookings,
  createFirestoreOrder,
  createFirestoreBooking
} from './firebase';

// Hero Image
import heroImage from './assets/images/moroccan_mechoui_hero_1783196824771.jpg';

export default function App() {
  // Local state persisted in localStorage & synced with Firebase
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<OrderDetails[]>([]);
  const [products, setProducts] = useState<SideItem[]>(TRADITIONAL_SIDES);
  const [bookings, setBookings] = useState<EventBookingRequest[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);
  const [reviews, setReviews] = useState<CustomerReview[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // Refs to prevent duplicate notifications on initial Firestore fetch
  const isInitialOrdersLoad = useRef(true);
  const isInitialBookingsLoad = useRef(true);
  const prevOrdersCount = useRef<number>(0);

  // UI state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReservationsOpen, setIsReservationsOpen] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  // Routing state for dedicated /admin route
  const getInitialRoute = (): 'home' | 'admin' => {
    if (typeof window === 'undefined') return 'home';
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    if (path === '/admin' || path.startsWith('/admin/') || hash === '#admin' || hash.startsWith('#admin/')) {
      return 'admin';
    }
    return 'home';
  };

  const [currentRoute, setCurrentRoute] = useState<'home' | 'admin'>(getInitialRoute);

  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (path === '/admin' || path.startsWith('/admin/') || hash === '#admin' || hash.startsWith('#admin/')) {
        setCurrentRoute('admin');
      } else {
        setCurrentRoute('home');
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const navigateTo = (path: string) => {
    try {
      window.history.pushState({}, '', path);
    } catch {
      window.location.hash = path.replace(/^\//, '#');
    }
    if (path === '/admin' || path.startsWith('/admin') || path.startsWith('#admin')) {
      setCurrentRoute('admin');
    } else {
      setCurrentRoute('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // New review form state
  const [revName, setRevName] = useState('');
  const [revCity, setRevCity] = useState('الدار البيضاء');
  const [revRating, setRevRating] = useState(5);
  const [revComment, setRevComment] = useState('');
  const [revSuccess, setRevSuccess] = useState(false);

  // Notification management functions
  const addNotification = (notif: AppNotification) => {
    setNotifications(prev => [notif, ...prev.filter(n => n.id !== notif.id)].slice(0, 10));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const handleNotificationAction = (notif: AppNotification) => {
    if (notif.actionType === 'open_whatsapp') {
      const cleanPhone = (siteSettings.whatsappPhone || '212717301089').replace(/[^0-9]/g, '');
      const msg = notif.orderId 
        ? `السلام عليكم، أود تأكيد طلبي رقم #${notif.orderId.slice(-6)} لمنع أي تأخير أو ضياع للطلب.`
        : `السلام عليكم، أود الاستفسار والتأكيد بخصوص الشواء المغربي الأصيل.`;
      window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
    } else if (notif.actionType === 'view_order') {
      setIsReservationsOpen(true);
    }
  };

  // Load initial cart and reviews from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('shw_cart');
    const savedReviews = localStorage.getItem('shw_reviews');

    if (savedCart) setCart(JSON.parse(savedCart));
    
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews));
    } else {
      setReviews(INITIAL_REVIEWS);
      localStorage.setItem('shw_reviews', JSON.stringify(INITIAL_REVIEWS));
    }
  }, []);

  // Subscribe to Firebase Firestore Live Data
  useEffect(() => {
    // 1. Site Settings (Prices, Titles, Payment Methods, RIB)
    const unsubSettings = subscribeSiteSettings((newSettings) => {
      setSiteSettings(newSettings);
    });

    // 2. Orders Collection
    const unsubOrders = subscribeOrders((liveOrders) => {
      if (!isInitialOrdersLoad.current && liveOrders.length > prevOrdersCount.current) {
        const newlyAdded = liveOrders[0];
        if (newlyAdded) {
          addNotification({
            id: `notif_order_${newlyAdded.id}_${Date.now()}`,
            type: 'new_order',
            title: 'طلب شواء جديد في النظام! 🔔',
            message: `طلب جديد من ${newlyAdded.customerName} بقيمة ${newlyAdded.total} د.م. لتفادي أي ضياع للطلب.`,
            timestamp: 'الآن',
            orderId: newlyAdded.id,
            customerName: newlyAdded.customerName,
            actionLabel: 'معاينة الطلب',
            actionType: 'view_order'
          });
        }
      }
      isInitialOrdersLoad.current = false;
      prevOrdersCount.current = liveOrders.length;
      setOrders(liveOrders);
    });

    // 3. Products / Dishes Collection
    const unsubProducts = subscribeProducts((liveProducts) => {
      setProducts(liveProducts);
    });

    // 4. Catering / Events Bookings Collection
    const unsubBookings = subscribeBookings((liveBookings) => {
      if (!isInitialBookingsLoad.current && liveBookings.length > bookings.length) {
        const newBk = liveBookings[0];
        if (newBk) {
          addNotification({
            id: `notif_bk_${newBk.id}_${Date.now()}`,
            type: 'booking_created',
            title: 'حجز مناسبة جديد وارد! 💍',
            message: `حجز مناسبة لـ ${newBk.customerName} (${newBk.guestCount} ضيف).`,
            timestamp: 'الآن',
            actionLabel: 'معاينة الحجوزات',
            actionType: 'view_order'
          });
        }
      }
      isInitialBookingsLoad.current = false;
      setBookings(liveBookings);
    });

    return () => {
      unsubSettings();
      unsubOrders();
      unsubProducts();
      unsubBookings();
    };
  }, []);

  // Sync cart utility
  const saveCartToStorage = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('shw_cart', JSON.stringify(newCart));
  };

  // Cart operations
  const handleAddToCart = (item: CartItem) => {
    const updated = [...cart, item];
    saveCartToStorage(updated);
  };

  const handleRemoveFromCart = (id: string) => {
    const updated = cart.filter(item => item.id !== id);
    saveCartToStorage(updated);
  };

  const handleClearCart = () => {
    saveCartToStorage([]);
  };

  // Save new order to Firebase Firestore
  const handleAddOrder = async (order: OrderDetails) => {
    try {
      await createFirestoreOrder(order);
    } catch (error) {
      console.warn('Saving to local state as fallback for order', error);
    }
    const updated = [order, ...orders];
    setOrders(updated);
    localStorage.setItem('shw_orders', JSON.stringify(updated));
  };

  // Save new event booking to Firebase Firestore
  const handleAddBooking = async (booking: EventBookingRequest) => {
    try {
      await createFirestoreBooking(booking);
    } catch (error) {
      console.warn('Saving booking to local state as fallback', error);
    }
    const updated = [booking, ...bookings];
    setBookings(updated);
    localStorage.setItem('shw_bookings', JSON.stringify(updated));
  };

  // Add customer review
  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!revName || !revComment) {
      alert('المرجو كتابة اسمك وتقييمك لمشاركته مع زوارنا.');
      return;
    }

    const newRev: CustomerReview = {
      id: `rev_${Date.now()}`,
      name: revName,
      city: revCity,
      rating: revRating,
      comment: revComment,
      date: 'الآن',
      verified: true
    };

    const updated = [newRev, ...reviews];
    setReviews(updated);
    localStorage.setItem('shw_reviews', JSON.stringify(updated));

    setRevName('');
    setRevComment('');
    setRevSuccess(true);
    setTimeout(() => {
      setRevSuccess(false), 4000;
    });
  };

  // Smooth scroll handler
  const handleScrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const coreBenefits = [
    {
      icon: Flame,
      title: 'شواء على الفحم البلدي',
      desc: 'نستعمل حصراً فحم أشجار البلوط الطبيعي الصلب ليمنح اللحم نكهة تدخين عميقة وطبخاً متساوياً هادئاً.'
    },
    {
      icon: Award,
      title: 'لحم غنمي بلدي طازج',
      desc: 'ذبائح بلدية ممتازة تُختار بعناية فائقة من مزارع الأطلس الشاسعة وتُذبح تحت إشراف صحي صارم يومياً.'
    },
    {
      icon: Utensils,
      title: 'توابل تقليدية فاسية',
      desc: 'خلطة سرية متوارثة من السمن الحار، الكمون البلدي، والملح الصخري تبرز طراوة اللحم بدون أن تغطي على نكهته.'
    },
    {
      icon: Clock,
      title: 'توصيل ساخن جداً',
      desc: 'حقائب حرارية متطورة تحافظ على المشوي في درجة حرارة الفرن ليوصلك طازجاً يغلي كأنه خرج للتو من المجمر.'
    }
  ];

  // If current route is /admin, render dedicated Admin Portal
  if (currentRoute === 'admin') {
    return (
      <div className="bg-[#030101] text-stone-100 min-h-screen selection:bg-amber-600 selection:text-white flex flex-col font-sans overflow-x-hidden antialiased">
        <AdminDashboard
          isStandalonePage={true}
          onNavigateHome={() => navigateTo('/')}
          orders={orders}
          products={products}
          siteSettings={siteSettings}
          bookings={bookings}
          onNotify={addNotification}
        />

        {/* Real-time notifications remain active in Admin Portal */}
        <NotificationToaster 
          notifications={notifications}
          onDismiss={removeNotification}
          onActionClick={handleNotificationAction}
        />
      </div>
    );
  }

  return (
    <div className="bg-[#030101] text-stone-100 min-h-screen selection:bg-amber-600 selection:text-white flex flex-col font-sans overflow-x-hidden antialiased">
      
      {/* HEADER NAVBAR */}
      <Header 
        cart={cart} 
        siteSettings={siteSettings}
        notifications={notifications}
        onOpenCart={() => setIsCartOpen(true)} 
        onOpenReservations={() => setIsReservationsOpen(true)}
        onScrollToSection={handleScrollToSection}
        onClearNotifications={clearNotifications}
        onNotificationAction={handleNotificationAction}
      />

      {/* HERO SECTION */}
      <section id="hero" className="relative min-h-screen flex items-center justify-center pt-24 pb-16 px-4">
        
        {/* Background Image with Rich overlays */}
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt="المشوي المغربي الفخم على طاولة الزليج" 
            className="w-full h-full object-cover object-center scale-100 animate-[pulse_10s_infinite_alternate]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-[#000]/75"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-[#030101] via-transparent to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-transparent to-black/45"></div>
        </div>

        {/* Content Box */}
        <div className="max-w-7xl mx-auto w-full relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 text-right">
          <div className="lg:col-span-8 flex flex-col justify-center">
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6 bg-stone-950/60 backdrop-blur-md p-6 sm:p-10 rounded-3xl border border-amber-500/25 shadow-[0_0_60px_-10px_rgba(245,158,11,0.25)] ring-1 ring-amber-500/20"
            >
              {/* Premium Moroccan Accent badge */}
              <div className="inline-flex items-center gap-2 bg-amber-950/40 border border-amber-500/30 px-4 py-2 rounded-full text-amber-400 text-xs font-bold leading-none w-fit mr-0 ml-auto shadow-md">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>عراقة الضيافة والأصالة المغربية</span>
              </div>

              {/* Majestic Headline */}
              <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white leading-[1.25] md:leading-[1.3] drop-shadow-2xl">
                المشوي المغربي التقليدي <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 font-extrabold">
                  على أصوله الفاخرة
                </span>
              </h1>

              {/* Descriptive Paragraph */}
              <p className="text-stone-200 text-base sm:text-lg lg:text-xl max-w-2xl leading-[1.8] font-sans drop-shadow-sm font-medium">
                تذوق طعم الفخامة البلدية في بيتك. نحضر لكم أجود خرفان الغنمي البلدية، مطبوخة ببطء على الجمر الهادئ لأكثر من 6 ساعات لتنصهر الدهون وتمنحكم لحماً طرياً يذوب فمك.
              </p>

              {/* Interactive Pricing Summary */}
              <div className="bg-[#140E0A]/90 border border-amber-950/40 p-4 rounded-2xl w-fit mr-0 ml-auto flex items-center gap-6 shadow-2xl shadow-amber-950/20 text-stone-100">
                <div>
                  <span className="text-[10px] text-stone-400 block">ثمن الكيلوغرام الجاهز</span>
                  <span className="text-3xl font-sans font-extrabold text-amber-500 mt-1 block">
                    {siteSettings.pricePerKg} د.م.
                  </span>
                </div>
                <div className="h-10 w-px bg-stone-850"></div>
                <div className="text-right">
                  <span className="text-xs font-bold text-stone-200">توصيل سريع ساخن</span>
                  <span className="text-[10px] text-stone-400 block mt-1">تعبئة فاخرة تحفظ الحرارة</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4 justify-start">
                <button
                  onClick={() => handleScrollToSection('order-meat')}
                  className="px-8 py-4 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl shadow-lg shadow-orange-950/50 transition-all text-sm flex items-center justify-center gap-2 transform hover:-translate-y-0.5 cursor-pointer"
                >
                  <Flame className="w-5 h-5 text-white" />
                  <span>اطلب شواء ساخن بالكيلو ({siteSettings.pricePerKg} د.م.)</span>
                </button>

                <button
                  onClick={() => handleScrollToSection('events-catering')}
                  className="px-8 py-4 bg-stone-900/80 hover:bg-stone-850 text-stone-200 hover:text-white font-bold rounded-xl border border-stone-800 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Utensils className="w-5 h-5 text-amber-500" />
                  <span>حجز الأعراس والمناسبات الكبرى</span>
                </button>
              </div>

            </motion.div>

          </div>
        </div>

        {/* Scroll down indicator */}
        <div 
          onClick={() => handleScrollToSection('benefits')}
          className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-stone-400 hover:text-amber-400 transition-colors cursor-pointer"
        >
          <span className="text-[10px] tracking-wider uppercase font-sans font-bold">اكتشف أسرار النكهة</span>
          <ChevronDown className="w-5 h-5 animate-bounce text-amber-500" />
        </div>

      </section>

      {/* CORE BENEFITS SECTION */}
      <section id="benefits" className="py-24 bg-[#070403] border-t border-[#1C1009] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-amber-500 font-bold text-xs tracking-widest uppercase bg-amber-950/30 px-3 py-1.5 rounded-full border border-amber-900/30">سر المذاق الأصيل</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-100 mt-4 mb-4">
              لماذا يفضلنا عشاق الشواء المغربي؟
            </h2>
            <p className="text-stone-400 text-sm sm:text-base leading-relaxed">
              نلتزم بأدق التقاليد المغربية الأصيلة المتوارثة عن أجدادنا لنضمن لك لحماً غنياً بالنكهات ومطهواً بعناية فائقة.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {coreBenefits.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div 
                  key={idx}
                  className="bg-[#120B08] p-8 rounded-3xl border border-[#26150C] hover:border-amber-900/40 transition-all duration-300 transform hover:-translate-y-1 shadow-lg text-right group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center mb-6 shadow-md shadow-orange-950/50 group-hover:scale-110 transition-transform">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-stone-100 mb-2">{item.title}</h3>
                  <p className="text-stone-400 text-xs sm:text-sm leading-relaxed">{item.desc}</p>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* SECTION 1: ORDER BY KG (ORDER CALCULATOR) */}
      <OrderCalculator 
        onAddToCart={handleAddToCart} 
        pricePerKg={siteSettings.pricePerKg}
        products={products}
      />

      {/* SECTION 2: EVENTS & WEDDINGS CATERING */}
      <EventBooking 
        onAddBooking={handleAddBooking} 
        onNotify={addNotification}
        whatsappPhone={siteSettings.whatsappPhone}
      />

      {/* SECTION 3: REVIEWS & SOCIAL PROOF */}
      <section id="testimonials" className="py-24 bg-[#070403] border-t border-[#1C1009] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-amber-500 font-bold text-xs tracking-widest uppercase bg-amber-950/30 px-3 py-1.5 rounded-full border border-amber-900/30">شهادات حقيقية</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-100 mt-4 mb-4">
              ماذا يقول زبائننا الكرام؟
            </h2>
            <p className="text-stone-400 text-sm">
              أكثر من 1,500 وليمة وعزومة تم تجهيزها في مختلف المدن المغربية بنسبة رضا 99%.
            </p>
          </div>

          {/* Reviews Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {reviews.slice(0, 6).map((rev) => (
              <div 
                key={rev.id}
                className="bg-[#120B08] p-6 rounded-3xl border border-[#26150C] flex flex-col justify-between text-right relative shadow-md"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    {rev.verified && (
                      <span className="text-[10px] bg-emerald-950/50 text-emerald-400 border border-emerald-900/30 px-2 py-0.5 rounded-full">
                        زبون موثق ✓
                      </span>
                    )}
                  </div>
                  <p className="text-stone-300 text-xs sm:text-sm leading-relaxed mb-6 italic">
                    "{rev.comment}"
                  </p>
                </div>

                <div className="border-t border-stone-850 pt-4 flex items-center justify-between text-xs text-stone-400">
                  <div>
                    <h4 className="font-bold text-stone-200">{rev.name}</h4>
                    <span className="text-[10px] text-amber-500">{rev.city}</span>
                  </div>
                  <span className="text-[10px] text-stone-500">{rev.date}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Add Review Form */}
          <div className="max-w-2xl mx-auto bg-[#140E0A] p-8 rounded-3xl border border-[#2D1B12] shadow-xl text-right">
            <h3 className="font-serif text-xl font-bold text-stone-100 mb-2">شاركنا تجربتك ورأيك</h3>
            <p className="text-stone-400 text-xs mb-6">رأيك يهمنا لمواصلة تقديم أرقى مستويات الشواء المغربي الأصيل.</p>

            <form onSubmit={handleAddReview} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-stone-300 text-xs block mb-1 font-bold">الاسم واللقب *</label>
                  <input
                    type="text"
                    required
                    value={revName}
                    onChange={(e) => setRevName(e.target.value)}
                    placeholder="مثال: كريم بنجلون"
                    className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-stone-300 text-xs block mb-1 font-bold">المدينة *</label>
                  <input
                    type="text"
                    required
                    value={revCity}
                    onChange={(e) => setRevCity(e.target.value)}
                    placeholder="مثال: الدار البيضاء"
                    className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-stone-300 text-xs block mb-1 font-bold">التقييم العام</label>
                <div className="flex gap-2 justify-end">
                  {[5, 4, 3, 2, 1].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setRevRating(num)}
                      className={`px-3 py-1.5 rounded-lg border text-xs flex items-center gap-1 cursor-pointer ${
                        revRating === num
                          ? 'bg-amber-500/20 border-amber-500 text-amber-400'
                          : 'bg-stone-900 border-stone-800 text-stone-400'
                      }`}
                    >
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{num} نجوم</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-stone-300 text-xs block mb-1 font-bold">تعليقك وانطباعك عن الشواء *</label>
                <textarea
                  required
                  rows={3}
                  value={revComment}
                  onChange={(e) => setRevComment(e.target.value)}
                  placeholder="حدثنا عن رأيك في طراوة اللحم، بهارات الشواء، والسرعة..."
                  className="w-full bg-stone-900 border border-stone-800 rounded-xl px-4 py-2.5 text-stone-100 text-xs focus:border-amber-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl shadow-lg transition-all text-xs cursor-pointer"
                >
                  إرسال التقييم
                </button>
                {revSuccess && (
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-4 h-4" />
                    شكراً لك! تم نشر رأيك بنجاح.
                  </span>
                )}
              </div>
            </form>
          </div>

        </div>
      </section>

      {/* SECTION 4: FAQS */}
      <section id="faqs" className="py-24 bg-[#0B0604] border-t border-[#2C1A10]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          <div className="text-center mb-16">
            <span className="text-amber-500 font-bold text-xs tracking-widest uppercase bg-amber-950/30 px-3 py-1.5 rounded-full border border-amber-900/30">استفسارات الزوار</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-stone-100 mt-4 mb-4">الأسئلة الشائعة حول المشوي</h2>
            <p className="text-stone-400 text-sm">كل ما تود معرفته عن لحومنا، أوقات الطهي الفائقة، وتجهيز الولائم والأعراس.</p>
          </div>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => {
              const isExpanded = expandedFaq === idx;
              return (
                <div 
                  key={idx}
                  className="bg-[#140E0A] border border-[#2D1B12] rounded-2xl overflow-hidden transition-all duration-300 shadow-sm"
                >
                  <button
                    type="button"
                    onClick={() => setExpandedFaq(isExpanded ? null : idx)}
                    className="w-full p-5 text-right flex justify-between items-center gap-4 hover:bg-stone-900/30 transition-colors cursor-pointer"
                  >
                    <span className="text-amber-500 text-xs transition-transform duration-300 transform" style={{ transform: isExpanded ? 'rotate(180deg)' : 'none' }}>
                      ▼
                    </span>
                    <h3 className="text-stone-100 text-sm sm:text-base font-bold font-serif">{faq.q}</h3>
                  </button>

                  {isExpanded && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-stone-300 leading-relaxed border-t border-stone-850 text-right font-sans">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* FOOTER */}
      <Footer 
        onScrollToSection={handleScrollToSection} 
        onNavigate={navigateTo}
      />

      {/* WHATSAPP FLOATING CHAT */}
      <SupportChat 
        phone={siteSettings.whatsappPhone} 
        onNotify={addNotification}
      />

      {/* SIDE/MODAL SHEETS */}
      <CheckoutModal 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onAddOrder={handleAddOrder}
        siteSettings={siteSettings}
        onNotify={addNotification}
      />

      <MyReservations 
        isOpen={isReservationsOpen}
        onClose={() => setIsReservationsOpen(false)}
        orders={orders}
        bookings={bookings}
      />

      {/* REAL-TIME NOTIFICATION TOASTER FOR ORDERS & WHATSAPP */}
      <NotificationToaster 
        notifications={notifications}
        onDismiss={removeNotification}
        onActionClick={handleNotificationAction}
      />

    </div>
  );
}
