export interface SideItem {
  id: string;
  name: string;
  price: number;
  description: string;
  image?: string;
  category: 'meat' | 'sides' | 'drinks' | 'salads' | 'platters';
  isAvailable?: boolean;
}

export interface CartItem {
  id: string;
  name: string;
  quantityKg?: number; // For main meat orders
  quantityItem?: number; // For sides/drinks
  pricePerKg?: number;
  unitPrice?: number;
  cookingPreference?: string; // 'well-done' | 'medium' | 'juicy'
  seasoningPreference?: string[]; // 'salt' | 'cumin' | 'traditional-rub'
  sides?: { side: SideItem; quantity: number }[];
  totalPrice: number;
}

export type PaymentMethod = 'cod' | 'card' | 'transfer';
export type DeliveryMethod = 'delivery' | 'pickup';
export type OrderStatus = 'pending' | 'confirmed' | 'cooking' | 'out-for-delivery' | 'completed' | 'cancelled';

export interface OrderDetails {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  city: string;
  deliveryMethod: DeliveryMethod;
  paymentMethod: PaymentMethod;
  cartItems: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
  notes?: string;
  transferRef?: string;
}

export interface EventBookingRequest {
  id: string;
  customerName: string;
  customerPhone: string;
  eventType: 'wedding' | 'aqeeqah' | 'family' | 'corporate' | 'other';
  eventDate: string;
  eventLocation: string;
  guestCount: number;
  meatPreference: 'sheep' | 'goat' | 'beef_skewers' | 'mixed';
  estimatedLambsNeeded: number;
  additionalServices: string[]; // 'tent' | 'music' | 'waiters' | 'tea_service'
  notes?: string;
  totalEstimatedPrice: number;
  status: 'pending' | 'contacted' | 'confirmed' | 'cancelled';
  createdAt: string;
}

export interface CustomerReview {
  id: string;
  name: string;
  city: string;
  rating: number;
  comment: string;
  date: string;
  avatar?: string;
  verified: boolean;
}

export interface GalleryImage {
  id: string;
  url: string;
  title: string;
  category?: string;
}

export interface SiteSettings {
  pricePerKg: number;
  siteTitle: string;
  whatsappPhone: string;
  supportPhone: string;
  announcement: string;
  announcementEnabled?: boolean;
  announcementBadge?: string;
  announcementLink?: string;
  announcementType?: 'standard' | 'urgent' | 'discount' | 'catering';
  bankName: string;
  bankBeneficiary: string;
  bankRib: string;
  codEnabled: boolean;
  transferEnabled: boolean;
  cardEnabled: boolean;
  heroBadge?: string;
  heroTitle?: string;
  heroSubtitle?: string;
  benefitsTitle?: string;
  benefitsSubtitle?: string;
  eventsTitle?: string;
  eventsSubtitle?: string;
  footerBio?: string;
  heroImageUrl?: string;
  eventsImageUrl?: string;
  skewersImageUrl?: string;
  galleryImages?: GalleryImage[];
  adminPasscode?: string;
}

export interface AppNotification {
  id: string;
  type: 'order_confirmed' | 'whatsapp_sent' | 'new_order' | 'booking_created' | 'status_updated' | 'info' | 'chat_message';
  title: string;
  message: string;
  timestamp: string;
  orderId?: string;
  customerName?: string;
  actionLabel?: string;
  actionType?: 'view_order' | 'open_whatsapp' | 'open_admin' | 'view_reservations' | 'open_chat';
}

export interface ChatMessage {
  id: string;
  chatId: string;
  sender: 'customer' | 'admin';
  senderName: string;
  text: string;
  createdAt: string;
  orderId?: string;
}

export interface ChatConversation {
  id: string;
  customerName: string;
  customerPhone?: string;
  orderId?: string;
  lastMessage: string;
  lastMessageAt: string;
  unreadByAdmin: number;
  unreadByCustomer: number;
  createdAt: string;
}
