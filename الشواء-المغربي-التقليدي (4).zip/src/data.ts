import { SideItem, CustomerReview } from './types';

export const MOROCCAN_FOOD_PRESETS = [
  {
    name: 'شواء لحم الغنمي البلدي المشوي',
    category: 'meat',
    price: 300,
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    desc: 'لحم غنمي بلدي محمر على الجمر الهادئ مع الكمون والملح'
  },
  {
    name: 'قطبان لحم الغنمي المتبل',
    category: 'meat',
    price: 35,
    url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    desc: 'قطبان طرية متبلة بالبصل، القزبر والشحم البلدي'
  },
  {
    name: 'كتف غنمي محمر باللوز',
    category: 'platters',
    price: 380,
    url: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80',
    desc: 'كتف غنمي بلدي فتي مطهو على مهل بالزعفران الحر واللوز المقلي'
  },
  {
    name: 'طاجين اللحم بالبرقوق والمشماش',
    category: 'platters',
    price: 85,
    url: 'https://images.unsplash.com/photo-1574484284002-952d92456975?auto=format&fit=crop&w=600&q=80',
    desc: 'طاجين مغربي فاخر بلحم الغنمي والبرقوق المعسل والسمسم'
  },
  {
    name: 'طنجية مراكشية تقليدية',
    category: 'meat',
    price: 120,
    url: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80',
    desc: 'طنجية فخارية بلحم الملج، الحامض المصير والسمن الحار والكمون'
  },
  {
    name: 'خبز الدار المغربي بالقمح',
    category: 'sides',
    price: 5,
    url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80',
    desc: 'خبز تقليدي محضر في الفرن البلدي بنخالة القمح'
  },
  {
    name: 'زعلوك وسلطات مغربية',
    category: 'salads',
    price: 20,
    url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    desc: 'باذنجان مشوي وفلفل وتوابل مغربية بزيت الزيتون'
  },
  {
    name: 'براد أتاي مغربي بالنعناع والرزة',
    category: 'drinks',
    price: 30,
    url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80',
    desc: 'شاي مخمر بالنعناع والنعناع العبدي وسبع حبات سكر'
  },
  {
    name: 'زيتون مغربي مشرمل ومقبلات',
    category: 'sides',
    price: 12,
    url: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80',
    desc: 'زيتون بلدي متبل بالهريسة، الثوم، وزيت الزيتون البكر'
  }
];

export const TRADITIONAL_SIDES: SideItem[] = [
  {
    id: 'side_bread',
    name: 'خبز الدار المغربي بالقمح',
    price: 5,
    description: 'خبز تقليدي محضر في الفرن البلدي بنخالة القمح والسميد الناعم',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'side_olives',
    name: 'زيتون مغربي مشرمل',
    price: 10,
    description: 'زيتون أحمر وأخضر متبل بالثوم، الحامض المصير، الهريسة وزيت الزيتون البكر',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'salad_moroccan',
    name: 'السلطة المغربية التقليدية',
    price: 15,
    description: 'طماطم طازجة، خيار، بصل مفروم ناعم مع لمسة من القزبر وزيت الزيتون والكمون',
    category: 'salads',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'salad_zaalouk',
    name: 'زعلوك مغربي مشوي',
    price: 20,
    description: 'سلطة دافئة من الباذنجان والطماطم المشوية المتبلة بالثوم، الكمون والتحميرة',
    category: 'salads',
    image: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'salad_taktouka',
    name: 'تكتوكة بالفلفل المشوي',
    price: 20,
    description: 'فلفل حلو مشوي ومطهو مع الطماطم الطازجة، الثوم والتوابل المغربية الأصيلة',
    category: 'salads',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'drink_tea_small',
    name: 'براد أتاي مغربي بالنعناع (صغير)',
    price: 25,
    description: 'شاي مغربي أصيل مخمر بالنعناع الطازج وسبع حبات سكر للضيافة التقليدية',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'drink_tea_large',
    name: 'براد أتاي مغربي بالنعناع والشبية (كبير)',
    price: 45,
    description: 'براد شاي عائلي للضيافة الفاخرة مخمر بالنعناع والشبية (حسب الفصل)',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80'
  }
];

export const MOROCCAN_CITIES = [
  { id: 'benguerir', name: 'إبن جرير', fee: 15, deliveryTime: '20 - 35 دقيقة' },
  { id: 'casablanca', name: 'الدار البيضاء', fee: 25, deliveryTime: '45 - 60 دقيقة' },
  { id: 'rabat', name: 'الرباط', fee: 30, deliveryTime: '45 - 60 دقيقة' },
  { id: 'salé', name: 'سلا', fee: 30, deliveryTime: '50 - 70 دقيقة' },
  { id: 'temara', name: 'تمارة', fee: 30, deliveryTime: '50 - 60 دقيقة' },
  { id: 'mohammedia', name: 'المحمدية', fee: 35, deliveryTime: '60 - 80 دقيقة' },
  { id: 'marrakech', name: 'مراكش', fee: 35, deliveryTime: '45 - 60 دقيقة' },
  { id: 'tangier', name: 'طنجة', fee: 35, deliveryTime: '50 - 70 دقيقة' },
  { id: 'fes', name: 'فاس', fee: 35, deliveryTime: '50 - 70 دقيقة' },
  { id: 'meknes', name: 'مكناس', fee: 35, deliveryTime: '50 - 70 دقيقة' },
  { id: 'agadir', name: 'أكادير', fee: 40, deliveryTime: '60 - 80 دقيقة' }
];

export const INITIAL_REVIEWS: CustomerReview[] = [
  {
    id: 'rev_1',
    name: 'الحاج أحمد التازي',
    city: 'الدار البيضاء',
    rating: 5,
    comment: 'تبارك الله وصلات ع النبي، الشواء من أرقى ما تذوقت! اللحم فتي بزاف وكيدوب فالفم والتحميرة ياسلام. طلبنا 6 كيلو لضيافة عائلية والكل خرج كيشكر. التوصيل جا سخون فالحين.',
    date: 'منذ يومين',
    verified: true
  },
  {
    id: 'rev_2',
    name: 'للا فاطمة الزهراء العلوي',
    city: 'الرباط',
    rating: 5,
    comment: 'استعنا بخدماتهم في عرس أخي الأسبوع الماضي لطهي 8 خرفان مشوية على الطريقة التقليدية (الفرن البلدي). الخدمة ممتازة، تنظيم احترافي، والنكهة الأصيلة للمشوي المغربي الحقيقي بالملح والكمون كانت حاضرة بقوة. شكراً لكم على بيض وجهنا قدام الضياف!',
    date: 'منذ أسبوع',
    verified: true
  },
  {
    id: 'rev_3',
    name: 'ياسين بنجلون',
    city: 'مراكش',
    rating: 5,
    comment: 'ثمن 300 درهم للكيلو معقول جداً مقارنة بالجودة الاستثنائية واللحم الممتاز والنظافة. القطبان عندهم حتى هما لذاذ بزاف والتتبيلة متوازنة. الدعم الفني فالمستوى، تواصلت معهم على الواتساب وجاوبوني فالحين.',
    date: 'منذ 3 أيام',
    verified: true
  },
  {
    id: 'rev_4',
    name: 'مريم الفيلالي',
    city: 'طنجة',
    rating: 4,
    comment: 'جربت شواء كتف الغنمي عندهم وكان ممتاز جداً ومرفق بالملح والكمون البلدي والخبز الساخن. فقط التوصيل تأخر بـ 10 دقائق لكن المذاق أنساني في الانتظار. أنصح به بشدة!',
    date: 'منذ أسبوعين',
    verified: true
  }
];

export const FAQS = [
  {
    q: 'كم يبلغ سعر الكيلوغرام وكيف يتم تحضيره؟',
    a: 'سعر الكيلوغرام هو 300 درهم مغربي، ويشمل اللحم الطازج الفاخر (غنمي بلدي)، التتبيل بالبهارات المغربية الأصيلة، والشواء التقليدي على الجمر الهادئ أو في الفرن الطيني البلدي للحصول على لحم فتي ومقرمش من الخارج.'
  },
  {
    q: 'هل توفرون التوصيل الساخن لجميع المدن؟',
    a: 'نعم، نوفر خدمة التوصيل الساخن عبر حقائب حرارية مخصصة في المدن الكبرى (الدار البيضاء، الرباط، سلا، تمارة، مراكش، طنجة، فاس، أكادير، إلخ) لضمان وصول الشواء ساخناً كأنه خرج للتو من الفرن.'
  },
  {
    q: 'كيف يمكننا حجز خدمة الشواء للأعراس والمناسبات الكبرى؟',
    a: 'يمكنكم الحجز مباشرة عبر قسم "الأعراس والمناسبات" في الموقع، حيث يتوفر حاسب مخصص لتقدير عدد الخرفان واللحم المطلوب لعدد ضيوفكم مع تفاصيل الأسعار. بعد ملء الاستمارة، يمكنك تأكيد الحجز وإرسال الطلب ليتصل بك منسق الحفلات لدينا عبر الواتساب لتأكيد العربون وتفاصيل الحضور للطهي الميداني.'
  },
  {
    q: 'ما هي طرق الدفع المتاحة لديكم؟',
    a: 'نوفر 3 طرق دفع آمنة: الدفع نقداً عند الاستلام (COD)، الدفع الآمن بالبطاقة البنكية (تأشيرة/مدى)، والتحويل البنكي المباشر (مع إرفاق وصل التحويل لتأكيد الطلب بسرعة).'
  },
  {
    q: 'كيف يمكنني التواصل مع الدعم الفني؟',
    a: 'يمكنك النقر على زر الواتساب العائم في أي وقت للتحدث مباشرة مع معلم الشواء وفريق الدعم للاستفسار، تعديل الطلب، أو متابعة التوصيل على مدار الساعة.'
  }
];
