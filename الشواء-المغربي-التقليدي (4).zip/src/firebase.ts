import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  onSnapshot, 
  updateDoc, 
  deleteDoc,
  getDocFromServer,
  query,
  orderBy
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { 
  OrderDetails, 
  SiteSettings, 
  SideItem, 
  EventBookingRequest, 
  OrderStatus,
  ChatMessage,
  ChatConversation
} from './types';
import { TRADITIONAL_SIDES } from './data';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Test connection on boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is currently offline or connecting...');
    }
  }
}
testConnection();

// Error handler conforming to FirestoreErrorInfo
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  return errInfo;
}

// Default Settings
export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  pricePerKg: 300,
  siteTitle: 'الشواء المغربي الأصيل',
  whatsappPhone: '212600000000',
  supportPhone: '+212 6 00 00 00 00',
  announcement: 'توصيل ساخن ومجاني لجميع الطلبات التي تتجاوز 3 كيلوغرام في الدار البيضاء والرباط',
  announcementEnabled: true,
  announcementBadge: '🔥 عرض خاص',
  announcementLink: '#order-meat',
  announcementType: 'discount',
  bankName: 'CIH BANK',
  bankBeneficiary: 'ش.م.م شواء الأطلس الأصيل',
  bankRib: '230 201 4244758211030701 95',
  codEnabled: true,
  transferEnabled: true,
  cardEnabled: true,
  heroBadge: 'عراقة الضيافة والأصالة المغربية',
  heroTitle: 'المشوي المغربي التقليدي على أصوله الفاخرة',
  heroSubtitle: 'تذوق طعم الفخامة البلدية في بيتك. نحضر لكم أجود خرفان الغنمي البلدية، مطبوخة ببطء على الجمر الهادئ لأكثر من 6 ساعات لتنصهر الدهون وتمنحكم لحماً طرياً يذوب فمك.',
  benefitsTitle: 'لماذا يفضلنا عشاق الشواء المغربي؟',
  benefitsSubtitle: 'نلتزم بأدق التقاليد المغربية الأصيلة المتوارثة عن أجدادنا لنضمن لك لحماً غنياً بالنكهات ومطهواً بعناية فائقة.',
  eventsTitle: 'المشوي المغربي للأعراس والمناسبات',
  eventsSubtitle: 'نجعل مناسباتكم حكايات لا تُنسى. نوفر طاقماً متكاملاً من أمهر معلمي الشواء لطهي الخرفان الكاملة على الطريقة التقليدية (المشوي البلدي) مباشرة في مكان حفلكم أو داخل أفراننا الطينية مع التوصيل الملكي الفاخر.',
  footerBio: 'المتجر الرائد لطلب شواء الغنمي البلدي والولائم الفاخرة في المغرب. جودة أصيلة، طهي تقليدي على الجمر، وتوصيل ساخن وفوري.',
  heroImageUrl: '',
  eventsImageUrl: '',
  skewersImageUrl: '',
  galleryImages: [
    {
      id: 'gal_1',
      url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
      title: 'شواء لحم الغنمي المحمر على الفحم',
      category: 'مشوي بلدي'
    },
    {
      id: 'gal_2',
      url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1200&q=80',
      title: 'قطبان لحم الغنمي المتبل بالبهارات البلدية',
      category: 'قطبان وكباب'
    },
    {
      id: 'gal_3',
      url: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=1200&q=80',
      title: 'ضيافة الأعراس وطهي الخرفان الكاملة',
      category: 'أعراس ومناسبات'
    },
    {
      id: 'gal_4',
      url: 'https://images.unsplash.com/photo-1574484284002-952d92456975?auto=format&fit=crop&w=1200&q=80',
      title: 'طاجين اللحم البلدي المحمر باللوز والبرقوق',
      category: 'أطباق فاخرة'
    }
  ],
  adminPasscode: 'admin123'
};

const SETTINGS_DOC_REF = doc(db, 'site_settings', 'general');

// Subscribe to or fetch site settings
export function subscribeSiteSettings(callback: (settings: SiteSettings) => void) {
  return onSnapshot(SETTINGS_DOC_REF, (snapshot) => {
    if (snapshot.exists()) {
      callback({ ...DEFAULT_SITE_SETTINGS, ...snapshot.data() } as SiteSettings);
    } else {
      // Seed default settings into Firestore
      setDoc(SETTINGS_DOC_REF, DEFAULT_SITE_SETTINGS).catch(err => {
        handleFirestoreError(err, OperationType.WRITE, 'site_settings/general');
      });
      callback(DEFAULT_SITE_SETTINGS);
    }
  }, (err) => {
    handleFirestoreError(err, OperationType.GET, 'site_settings/general');
    callback(DEFAULT_SITE_SETTINGS);
  });
}

// Update Site Settings
export async function updateSiteSettings(settings: Partial<SiteSettings>) {
  try {
    await setDoc(SETTINGS_DOC_REF, settings, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, 'site_settings/general');
    throw error;
  }
}

// Clean undefined and invalid values before sending to Firestore
export function cleanForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return null as any;
  }
  if (Array.isArray(data)) {
    return data.map(item => cleanForFirestore(item)) as any;
  }
  if (typeof data === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined) {
        cleaned[key] = cleanForFirestore(value);
      }
    }
    return cleaned as T;
  }
  return data;
}

// Subscribe to Orders
export function subscribeOrders(callback: (orders: OrderDetails[]) => void) {
  const ordersCol = collection(db, 'orders');
  return onSnapshot(ordersCol, (snapshot) => {
    const list: OrderDetails[] = [];
    snapshot.forEach(docSnap => {
      list.push({ id: docSnap.id, ...docSnap.data() } as OrderDetails);
    });

    // Merge with any offline local orders so orders are never lost
    try {
      const cached = localStorage.getItem('shw_orders');
      if (cached) {
        const localList: OrderDetails[] = JSON.parse(cached);
        localList.forEach(lo => {
          if (!list.some(ro => ro.id === lo.id)) {
            list.push(lo);
          }
        });
      }
    } catch {
      // ignore
    }

    // Sort newest first
    list.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    
    // Update local cache
    try {
      localStorage.setItem('shw_orders', JSON.stringify(list));
    } catch {}

    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, 'orders');
    // Fallback to local storage if Firestore connection errors
    try {
      const cached = localStorage.getItem('shw_orders');
      if (cached) {
        callback(JSON.parse(cached));
      }
    } catch {}
  });
}

// Save New Order
export async function createFirestoreOrder(order: OrderDetails): Promise<void> {
  const sanitized = cleanForFirestore(order);
  try {
    const orderRef = doc(db, 'orders', order.id);
    await setDoc(orderRef, sanitized);
    
    // Sync to local storage immediately
    try {
      const currentCache: OrderDetails[] = JSON.parse(localStorage.getItem('shw_orders') || '[]');
      const updated = [order, ...currentCache.filter(o => o.id !== order.id)];
      localStorage.setItem('shw_orders', JSON.stringify(updated));
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `orders/${order.id}`);
    throw error;
  }
}

// Update Order Status
export async function updateFirestoreOrderStatus(orderId: string, status: OrderStatus, notes?: string) {
  try {
    const orderRef = doc(db, 'orders', orderId);
    const updateData: any = { status };
    if (notes !== undefined) updateData.notes = notes;
    await updateDoc(orderRef, updateData);

    // Update local cache
    try {
      const currentCache: OrderDetails[] = JSON.parse(localStorage.getItem('shw_orders') || '[]');
      const updated = currentCache.map(o => o.id === orderId ? { ...o, status, ...(notes !== undefined ? { notes } : {}) } : o);
      localStorage.setItem('shw_orders', JSON.stringify(updated));
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    throw error;
  }
}

// Delete Order
export async function deleteFirestoreOrder(orderId: string) {
  try {
    const orderRef = doc(db, 'orders', orderId);
    await deleteDoc(orderRef);

    // Update local cache
    try {
      const currentCache: OrderDetails[] = JSON.parse(localStorage.getItem('shw_orders') || '[]');
      const updated = currentCache.filter(o => o.id !== orderId);
      localStorage.setItem('shw_orders', JSON.stringify(updated));
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `orders/${orderId}`);
    throw error;
  }
}

// Subscribe to Products / Dishes
export function subscribeProducts(callback: (products: SideItem[]) => void) {
  const productsCol = collection(db, 'products');
  return onSnapshot(productsCol, (snapshot) => {
    if (snapshot.empty) {
      // Seed initial dishes from TRADITIONAL_SIDES
      TRADITIONAL_SIDES.forEach(item => {
        setDoc(doc(db, 'products', item.id), {
          ...item,
          isAvailable: true,
        }).catch(err => handleFirestoreError(err, OperationType.CREATE, `products/${item.id}`));
      });
      callback(TRADITIONAL_SIDES.map(s => ({ ...s, isAvailable: true })));
    } else {
      const list: SideItem[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as SideItem);
      });
      callback(list);
    }
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, 'products');
    callback(TRADITIONAL_SIDES.map(s => ({ ...s, isAvailable: true })));
  });
}

// Save or Update Product
export async function saveFirestoreProduct(product: SideItem) {
  try {
    const prodRef = doc(db, 'products', product.id);
    await setDoc(prodRef, cleanForFirestore(product), { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `products/${product.id}`);
    throw error;
  }
}

// Delete Product
export async function deleteFirestoreProduct(productId: string) {
  try {
    await deleteDoc(doc(db, 'products', productId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `products/${productId}`);
    throw error;
  }
}

// Subscribe to Bookings
export function subscribeBookings(callback: (bookings: EventBookingRequest[]) => void) {
  const col = collection(db, 'bookings');
  return onSnapshot(col, (snapshot) => {
    const list: EventBookingRequest[] = [];
    snapshot.forEach(docSnap => {
      list.push({ id: docSnap.id, ...docSnap.data() } as EventBookingRequest);
    });
    list.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, 'bookings');
  });
}

// Create Booking
export async function createFirestoreBooking(booking: EventBookingRequest) {
  try {
    const bRef = doc(db, 'bookings', booking.id);
    await setDoc(bRef, cleanForFirestore(booking));
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `bookings/${booking.id}`);
    throw error;
  }
}

// Update Booking Status
export async function updateFirestoreBookingStatus(bookingId: string, status: 'pending' | 'contacted' | 'confirmed' | 'cancelled') {
  try {
    await updateDoc(doc(db, 'bookings', bookingId), { status });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `bookings/${bookingId}`);
    throw error;
  }
}

// Delete Booking
export async function deleteFirestoreBooking(bookingId: string) {
  try {
    await deleteDoc(doc(db, 'bookings', bookingId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `bookings/${bookingId}`);
    throw error;
  }
}

// ==========================================
// LIVE CHAT DURING ORDERING FUNCTIONS
// ==========================================

// Subscribe to messages in a specific chat
export function subscribeChatMessages(chatId: string, callback: (messages: ChatMessage[]) => void) {
  const messagesCol = collection(db, 'chats', chatId, 'messages');
  const q = query(messagesCol, orderBy('createdAt', 'asc'));

  return onSnapshot(q, (snapshot) => {
    const list: ChatMessage[] = [];
    snapshot.forEach(docSnap => {
      list.push({ id: docSnap.id, ...docSnap.data() } as ChatMessage);
    });
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, `chats/${chatId}/messages`);
  });
}

// Subscribe to all customer chat threads (for Admin Dashboard)
export function subscribeAllChats(callback: (chats: ChatConversation[]) => void) {
  const chatsCol = collection(db, 'chats');

  return onSnapshot(chatsCol, (snapshot) => {
    const list: ChatConversation[] = [];
    snapshot.forEach(docSnap => {
      list.push({ id: docSnap.id, ...docSnap.data() } as ChatConversation);
    });
    // Sort newest message first
    list.sort((a, b) => new Date(b.lastMessageAt || 0).getTime() - new Date(a.lastMessageAt || 0).getTime());
    callback(list);
  }, (err) => {
    handleFirestoreError(err, OperationType.LIST, 'chats');
  });
}

// Send a message in a chat thread
export async function sendChatMessage(
  chatId: string, 
  payload: { 
    sender: 'customer' | 'admin'; 
    senderName: string; 
    text: string; 
    customerPhone?: string;
    orderId?: string;
  }
) {
  try {
    const msgId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const nowIso = new Date().toISOString();

    const msgData: ChatMessage = {
      id: msgId,
      chatId,
      sender: payload.sender,
      senderName: payload.senderName || (payload.sender === 'admin' ? 'المشرف (معلم الشواء)' : 'الزبون'),
      text: payload.text.trim(),
      createdAt: nowIso,
      orderId: payload.orderId || ''
    };

    // 1. Save message to subcollection
    const msgRef = doc(db, 'chats', chatId, 'messages', msgId);
    await setDoc(msgRef, cleanForFirestore(msgData));

    // 2. Update parent conversation metadata
    const chatRef = doc(db, 'chats', chatId);
    const updateChatMeta: any = {
      id: chatId,
      lastMessage: payload.text.trim(),
      lastMessageAt: nowIso,
      customerName: payload.sender === 'customer' ? payload.senderName : undefined,
      customerPhone: payload.customerPhone || undefined,
      orderId: payload.orderId || undefined,
    };

    if (payload.sender === 'customer') {
      updateChatMeta.unreadByAdmin = 1; // Flag as unread for admin
    } else {
      updateChatMeta.unreadByCustomer = 1; // Flag as unread for customer
    }

    await setDoc(chatRef, cleanForFirestore(updateChatMeta), { merge: true });
    return msgData;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `chats/${chatId}/messages`);
    throw error;
  }
}

// Mark chat as read
export async function markChatAsRead(chatId: string, asRole: 'customer' | 'admin') {
  try {
    const chatRef = doc(db, 'chats', chatId);
    const updateData = asRole === 'admin' ? { unreadByAdmin: 0 } : { unreadByCustomer: 0 };
    await updateDoc(chatRef, updateData);
  } catch {
    // Non-critical, ignore
  }
}

